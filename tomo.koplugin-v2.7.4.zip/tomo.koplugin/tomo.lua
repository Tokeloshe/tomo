-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- tomo.lua
-- The state orchestrator. All mutable session state lives here.
-- Every other module reads from and writes to this central state table.
-- No other module holds its own mutable session state.
--
-- Responsibilities:
--   - Hold the config (Supabase URL/key, tuning constants)
--   - Hold the session state (user, rooms, current book, season, online flag)
--   - Wire together: Library → presence → API → Cache → UI
--   - Handle network connect/disconnect events
--   - Handle device resume/suspend events
--   - Drive the outbox flush cycle

local Tomo = {}

-- Plugin version. Single source of truth: main.lua, the crash reporter and the
-- OTA updater all read it from here, so a release bump is one edit.
Tomo.VERSION = "2.7.4"

-- ─────────────────────────────────────────────────────────────────────────────
-- Configuration
-- All tunable constants are here. No hardcoded values elsewhere.
-- Supabase credentials are baked in permanently.
-- ─────────────────────────────────────────────────────────────────────────────

Tomo.config = {
    -- Supabase project credentials (baked in permanently).
    supabase_url = "https://flelpiioaeaxwtgfqboa.supabase.co",
    supabase_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZsZWxwaWlvYWVheHd0Z2ZxYm9hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM4NzQ4OTksImV4cCI6MjA4OTQ1MDg5OX0.a_6m4gcYce2aeV7O0NgFTumE4jcGC3qkJDTgUZ-FRU0",

    -- Room blooming threshold: number of readers with the same ISBN needed
    -- for a book room to appear. The Supabase trigger enforces this server-side;
    -- this client-side value is used for UI messaging only.
    book_room_threshold = 2,

    -- Message pagination: number of messages fetched per page.
    message_page_size = 20,

    -- Reader Bridge: minimum minutes between overlay appearances.
    bridge_cooldown_min = 60,

    -- Pen pal delivery delay window (hours).
    penpal_delay_min_h = 6,
    penpal_delay_max_h = 18,

    -- Age (days) after which ink images are removed from Supabase Storage.
    ink_expiry_days = 365,

    -- Outbox: hours before a pending message is marked failed.
    outbox_max_age_h = 24,

    -- Wake sync: minimum seconds between two syncOnWake runs.
    sync_debounce_s = 10,

    -- Wake sync: when the session token could not be refreshed (Wi-Fi not yet
    -- routable after resume), retry the whole sync after this many seconds,
    -- at most this many times per wake.
    sync_reauth_retry_s = 30,
    sync_reauth_max_retries = 3,

    -- Room id resolution: first attempt delay and retry interval (seconds).
    room_resolve_first_s = 10,
    room_resolve_retry_s = 30,
}

-- A Supabase user id: 8-4-4-4-12 hex groups. Anything else coming back from
-- auth is an error string and must not be used as an id.
local UUID_PATTERN = "^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$"

local function isUUID(s)
    return type(s) == "string" and s:match(UUID_PATTERN) ~= nil
end
Tomo._isUUID = isUUID

local function safeLogger()
    local ok, logger = pcall(require, "logger")
    if ok and logger then return logger end
    return { warn = function() end, info = function() end, dbg = function() end }
end

-- Run `fn` and log (never propagate) anything it raises. Used around every
-- stage of a sync so one failing stage cannot abort the stages after it;
-- crash 6872e46b lost the whole wake sync to one failed cache write.
local function guard(label, fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok then
        safeLogger().warn("Tomo: " .. label .. " failed: " .. tostring(err))
    end
    return ok
end
Tomo._guard = guard

-- ─────────────────────────────────────────────────────────────────────────────
-- Session state
-- All fields start nil/false/empty. Populated by init().
-- ─────────────────────────────────────────────────────────────────────────────

Tomo.state = {
    user         = nil,    -- Current user record { id, username, haiku_bio, stylus_user }
    rooms        = {},     -- Active rooms the user has joined: array of room tables
    active_room  = nil,    -- Room ID currently open in screen_room, or nil
    current_book = nil,    -- From KoboReader.sqlite: { title, author, isbn, progress_pct }
    season       = nil,    -- Current sekki table from seasons.lua
    online       = false,  -- True when Supabase is reachable
    has_failed_messages = false,  -- True if any outbox entries are in 'failed' state
    penpal_partner_name = nil,   -- Cached pen pal partner username (nil = no match)
    postcrossing_stats  = nil,   -- { sent = N, received = N } or nil
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Module references (populated by init())
-- ─────────────────────────────────────────────────────────────────────────────

Tomo._cache    = nil  -- Cache instance
Tomo._api      = nil  -- Api instance
Tomo._sync     = nil  -- Sync instance
Tomo._lib_watcher = nil  -- Library.watchForChange handle

-- Init generation counter. KOReader creates one plugin instance per host
-- widget (FileManager, ReaderUI) but this module is a process-wide
-- singleton. Each init() bumps the generation; teardown() from a stale
-- instance (older generation) must not destroy state a newer init owns.
Tomo._generation = 0

-- ─────────────────────────────────────────────────────────────────────────────
-- Initialisation
-- ─────────────────────────────────────────────────────────────────────────────

-- Full plugin initialisation. Called from main.lua on plugin load.
-- 1. Open cache DB
-- 2. Authenticate
-- 3. Load user state
-- 4. Start library watcher
-- 5. Check network and sync if online
function Tomo.init(safe_mode)
    Tomo._safe_mode = safe_mode or false

    -- Reclaim whatever a previous generation owned BEFORE rebuilding.
    -- KOReader can construct the new host widget's plugin instance before
    -- closing the old one; the old instance's teardown is then skipped by
    -- the generation guard, so init() is the only place these get released
    -- (otherwise every FileManager<->ReaderUI switch leaks a sqlite
    -- connection, a recorder fd, and a permanent 2s watcher timer).
    if Tomo._lib_watcher then
        pcall(function() Tomo._lib_watcher:stop() end)
        Tomo._lib_watcher = nil
    end
    if Tomo._sync then
        pcall(function() Tomo._sync:stopRoom() end)
    end
    if Tomo._cache then
        pcall(function() Tomo._cache:close() end)
    end
    if Tomo._room_resolve_fn then
        local ok_ui, UIManager = pcall(require, "ui/uimanager")
        if ok_ui then pcall(UIManager.unschedule, UIManager, Tomo._room_resolve_fn) end
        Tomo._room_resolve_fn = nil
    end
    Tomo:_cancelSyncRetry()

    -- Start session recorder (start() closes any previous session file).
    local Recorder = require("core/recorder")
    guard("recorder start", Recorder.start)
    Tomo._recorder = Recorder

    if safe_mode then
        Recorder.log("LAUNCH", "SAFE MODE -- network operations disabled")
    end

    -- Season is always available (no network required).
    Tomo.state.season = require("core/seasons").current()
    Recorder.log("LAUNCH", "Season: " .. (Tomo.state.season and Tomo.state.season.kanji or "?"))

    -- Open the local cache database. open() never raises: a corrupt file is
    -- recreated, and any other failure leaves a closed instance whose methods
    -- all degrade to no-ops and empty results.
    local Cache = require("core/cache")
    local cache = Cache.new()
    local ok, err = cache:open()
    local logger = require("logger")
    if not ok then
        -- Cache failure is non-fatal: the plugin degrades to read-only/offline.
        -- Log the error to KOReader's logger rather than crashing.
        logger.warn("Tomo: cache open failed: " .. tostring(err))
        Recorder.log("CACHE", "open failed: " .. tostring(err))
    elseif cache.recreated then
        Recorder.log("CACHE", "corrupt database recreated")
    end
    Tomo._cache = cache

    -- Expire any stale outbox messages from a previous session.
    cache:expireStaleOutbox(Tomo.config.outbox_max_age_h)

    -- Check if there are failed messages to surface on the home screen.
    local failed = cache:getFailedMessages()
    Tomo.state.has_failed_messages = #failed > 0

    local Auth = require("core/auth")
    local jwt, user_id

    if Tomo._safe_mode then
        -- Safe mode: use cached credentials only, no network
        Recorder.log("AUTH", "Safe mode, using cached credentials")
        jwt = Auth.loadToken(cache)
        user_id = Auth.loadUserId(cache)
    else
        Recorder.log("AUTH", "Starting authentication")
        local ok_auth, auth_jwt, auth_uid = pcall(Auth.ensureAuthenticated, Tomo.config, cache)
        if ok_auth then
            jwt, user_id = auth_jwt, auth_uid
        else
            -- ensureAuthenticated traps its own transport errors; this only
            -- fires for a defect inside auth.lua itself. Fall back to the
            -- cached session rather than losing the whole init.
            logger.warn("Tomo: ensureAuthenticated raised: " .. tostring(auth_jwt))
            jwt = Auth.loadToken(cache)
            user_id = Auth.loadUserId(cache)
        end
        Recorder.log("AUTH", "Result: jwt=" .. tostring(jwt and "yes" or "no")
            .. " user_id=" .. tostring(type(user_id) == "string" and user_id:sub(1,12) or "nil"))
    end

    -- Validate: if auth failed, user_id is an error string, not a UUID.
    if user_id ~= nil and not isUUID(user_id) then
        logger.warn("Tomo: auth returned invalid user_id (error string), treating as nil: " .. tostring(user_id))
        user_id = nil
    end
    if type(jwt) ~= "string" or jwt == "" then jwt = nil end

    -- Build API and Sync instances.
    local Api  = require("core/api")
    local Sync = require("core/sync")
    local api  = Api.new(Tomo.config, jwt, user_id)

    -- Update last_seen on every session launch (once, pcall-wrapped)
    if user_id and not Tomo._safe_mode then
        pcall(function()
            api:_request("PATCH",
                "/rest/v1/users?id=eq." .. user_id,
                { last_seen = os.date("!%Y-%m-%dT%H:%M:%SZ") },
                { ["Prefer"] = "return=minimal" })
        end)
    end
    local sync = Sync.new(api, cache)
    Tomo._api  = api
    Tomo._sync = sync

    -- Supabase JWTs expire after ~1h. api.lua calls this hook in two places:
    -- proactively from syncOnWake() when the token's exp claim says it is
    -- about to lapse, and reactively when a request comes back 401. Both
    -- re-run the device-hash sign-in; without it, every write after an hour
    -- of reading fails and queued messages get marked failed.
    if not Tomo._safe_mode then
        api.on_auth_expired = function()
            local new_jwt, new_uid = Auth.ensureAuthenticated(Tomo.config, cache)
            if not isUUID(new_uid) then new_uid = nil end
            return new_jwt, new_uid
        end
    end

    -- Check for and report any crashes from the previous session.
    -- Wrapped in its own pcall so the crash reporter itself cannot crash init.
    if not Tomo._safe_mode then
        local ok_cr, CrashReporter = pcall(require, "core/crash_reporter")
        if ok_cr then
            local ok_report, report_err = pcall(function()
                local device_profile = require("core/device").getProfile()
                CrashReporter.checkAndReport(api, device_profile, Tomo.VERSION, user_id, Tomo)
            end)
            if not ok_report then
                local lg = require("logger")
                lg.warn("Tomo: crash reporter error: " .. tostring(report_err))
            end
        end
    else
        Recorder.log("LAUNCH", "Skipping crash reporter (safe mode)")
    end

    if user_id then
        -- Restore username from cache DB first, then LuaSettings as fallback.
        -- Both are outside the plugin directory and survive OTA updates.
        local cached_username = cache:getState("auth_username")
        if not cached_username then
            -- Cache DB might be empty (first launch or wiped). Check LuaSettings.
            -- pcall: LuaSettings:open raises on a truncated settings file.
            pcall(function()
                local LS2 = require("luasettings")
                local DS2 = require("datastorage")
                local ts = LS2:open(DS2:getSettingsDir() .. "/tomo.lua")
                local stored = ts:readSetting("username")
                if type(stored) == "string" and stored ~= "" then
                    cached_username = stored
                end
            end)
        end

        if not cached_username then
            -- Truly first launch: generate a nature-word username.
            local nature_words = {
                "brook", "cedar", "cloud", "coral", "crane", "creek", "dawn",
                "dew", "dusk", "elm", "ember", "fawn", "fern", "finch", "flame",
                "flint", "fog", "frost", "gale", "grove", "hawk", "hazel",
                "heron", "holly", "ivy", "jade", "lake", "lark", "leaf",
                "lily", "linden", "maple", "marsh", "meadow", "mist", "moon",
                "moss", "oak", "orchid", "otter", "pearl", "pine", "plum",
                "pond", "rain", "reed", "ridge", "river", "robin", "sage",
                "shore", "sky", "snow", "sparrow", "stone", "storm", "stream",
                "thistle", "thorn", "vale", "wren", "willow", "wind",
            }
            math.randomseed(os.time())
            local a = nature_words[math.random(#nature_words)]
            local b = nature_words[math.random(#nature_words)]
            local username = a .. "-" .. b

            local device_hash = Auth.deviceHash()
            local Device = require("core/device")
            local profile = Device.getProfile()
            local stylus = profile and profile.has_stylus or false

            api:createUser(user_id, username, device_hash, stylus, function(create_err, _data)
                if not create_err then
                    cache:setState("auth_username", username)
                    -- Mirror to LuaSettings
                    pcall(function()
                        local LS = require("luasettings")
                        local DS = require("datastorage")
                        local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                        ts:saveSetting("username", username)
                        ts:flush()
                    end)
                end
            end)

            Tomo.state.user = {
                id          = user_id,
                username    = username,
                stylus_user = stylus,
            }
        else
            -- Returning user: restore from cache.
            local cached_haiku = cache:getState("auth_haiku_bio")
            if not cached_haiku then
                pcall(function()
                    local LS = require("luasettings")
                    local DS = require("datastorage")
                    local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                    cached_haiku = ts:readSetting("haiku_bio")
                end)
            end
            Tomo.state.user = {
                id          = user_id,
                username    = cached_username,
                haiku_bio   = cached_haiku,
                stylus_user = false,
            }
        end
    end

    -- Start the library watcher. Fires immediately with the current book,
    -- then fires again whenever KoboReader.sqlite changes.
    -- Also try KOReader's ReaderUI API as fallback (works on Kindle).
    -- library.lua handles both sources internally: KoboReader.sqlite on Kobo,
    -- and KOReader's open-document API on Kindle (no Kobo database there).
    local Library = require("core/library")
    local ok_watch, watcher = pcall(Library.watchForChange, function(book)
        Tomo.state.current_book = book
        if Tomo.state.online and user_id and not Tomo._safe_mode then
            guard("presence sync", sync.syncPresence, sync, user_id, book)
        end
    end)
    if ok_watch then
        Tomo._lib_watcher = watcher
    else
        -- No watcher means no automatic presence updates; everything else
        -- (rooms, messages, letters) still works, so init continues.
        logger.warn("Tomo: library watcher failed to start: " .. tostring(watcher))
        Recorder.log("LAUNCH", "library watcher unavailable")
        Tomo._lib_watcher = nil
    end

    -- Check network and kick off initial sync (skip in safe mode).
    if not Tomo._safe_mode then
        if Tomo._networkConnected() then
            Tomo.state.online = true
            guard("initial sync", Tomo.syncOnWake, Tomo, user_id)
        end
    else
        Recorder.log("LAUNCH", "Skipping network sync (safe mode)")
    end

    -- Bump the generation only now that init is complete. If init threw
    -- midway, the OLD generation stays current, so the still-alive older
    -- instance's teardown remains authorised to clean up the partial state.
    Tomo._generation = Tomo._generation + 1

    -- Returned to main.lua so the plugin instance can pass it back to
    -- teardown(); a stale instance closing later must not tear this down.
    return Tomo._generation
end

-- Push a freshly-opened document's book into state. Called from main.lua's
-- onReaderReady handler -- the only reliable book-open signal on Kindle,
-- where KoboReader.sqlite does not exist, the watcher's fallback poll runs
-- only every 5 minutes, and ReaderUI.instance is still nil while plugins
-- initialise. On Kobo this simply front-runs the WAL watcher.
function Tomo.onDocumentReady(document)
    local ok, err = pcall(function()
        local Library = require("core/library")
        local book = Library.bookFromDocument(document)
        if not book then return end
        local prev = Tomo.state.current_book
        if prev and prev.content_id == book.content_id then return end
        Tomo.state.current_book = book
        local user_id = Tomo.state.user and Tomo.state.user.id
        if Tomo.state.online and user_id and Tomo._sync and not Tomo._safe_mode then
            Tomo._sync:syncPresence(user_id, book)
        end
    end)
    if not ok then
        require("logger").warn("Tomo: onDocumentReady error: " .. tostring(err))
    end
end

-- True when KOReader reports a usable connection. Never raises; an
-- unavailable NetworkMgr counts as offline.
function Tomo._networkConnected()
    local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
    if not ok_nm or type(NetworkMgr) ~= "table" then return false end
    local ok_q, connected = pcall(function() return NetworkMgr:isConnected() end)
    return ok_q and connected and true or false
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Network event handlers
-- Registered automatically because Tomo is a WidgetContainer in the widget tree.
-- Each handler is split into a guarded body so a failure in one stage (auth,
-- sync, poll restart) cannot abort the others or reach KOReader's event loop.
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:onNetworkConnected()
    self.state.online = true
    local user_id = self.state.user and self.state.user.id

    -- If we don't have a user yet (auth failed at launch due to no network),
    -- try authenticating now that network is available.
    if not user_id and self._cache and self._api and not self._safe_mode then
        guard("late auth", function()
            local Auth = require("core/auth")
            local logger = require("logger")
            local jwt, uid = Auth.ensureAuthenticated(self.config, self._cache)
            if isUUID(uid) and type(jwt) == "string" and jwt ~= "" then
                logger.warn("Tomo: late auth succeeded, user_id=" .. uid)
                self._api:setJWT(jwt, uid)
                user_id = uid
                self.state.user = {
                    id       = uid,
                    username = self._cache:getState("auth_username") or "reader",
                    stylus_user = false,
                }
            end
        end)
    end

    if user_id then
        guard("reconnect sync", self.syncOnWake, self, user_id)
    end
    -- Restart the room poll if one was paused by suspend/disconnect while
    -- the room screen stayed open.
    if self._sync then
        guard("room poll resume", self._sync.resumeRoom, self._sync)
    end
    return true
end

function Tomo:onNetworkDisconnected()
    self.state.online = false
    self:_cancelSyncRetry()
    -- Pause the active room poll; resumeRoom() restarts it on reconnect.
    if self._sync then
        guard("room poll pause", self._sync.pauseRoom, self._sync)
    end
    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Device lifecycle handlers
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:onResume()
    -- Device woke from sleep. Update season (date may have changed).
    guard("season refresh", function()
        self.state.season = require("core/seasons").current()
    end)

    if Tomo._networkConnected() then
        self.state.online = true
        local user_id = self.state.user and self.state.user.id
        if user_id then
            guard("resume sync", self.syncOnWake, self, user_id)
        end
        -- Restart the room poll paused by onSuspend if the room is still open.
        if self._sync then
            guard("room poll resume", self._sync.resumeRoom, self._sync)
        end
    else
        self.state.online = false
    end
    return true
end

function Tomo:onSuspend()
    -- Device is about to sleep. Pause polling to conserve battery;
    -- onResume restarts it if the room screen is still open.
    self:_cancelSyncRetry()
    if self._sync then
        guard("room poll pause", self._sync.pauseRoom, self._sync)
    end
    -- Update last_seen before sleep. Skipped when the token has already
    -- lapsed: the request would only produce a 401 and a pointless
    -- re-auth attempt while the device is powering down.
    local uid = self.state.user and self.state.user.id
    if uid and self._api and self.state.online and not self._safe_mode
        and not self._api:jwtNeedsRefresh() then
        pcall(self._api._request, self._api, "PATCH",
            "/rest/v1/users?id=eq." .. uid,
            { last_seen = os.date("!%Y-%m-%dT%H:%M:%SZ") },
            { ["Prefer"] = "return=minimal" })
    end
    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Sync helpers
-- ─────────────────────────────────────────────────────────────────────────────

-- Cancel a pending post-wake sync retry (see syncOnWake).
function Tomo:_cancelSyncRetry()
    if self._sync_retry_fn then
        local ok_ui, UIManager = pcall(require, "ui/uimanager")
        if ok_ui then pcall(UIManager.unschedule, UIManager, self._sync_retry_fn) end
        self._sync_retry_fn = nil
    end
end

-- Schedule one more syncOnWake attempt after the token refresh failed.
-- Bounded by sync_reauth_max_retries per wake so a dead network cannot
-- keep the auth endpoint busy indefinitely.
function Tomo:_scheduleSyncRetry(user_id)
    self._sync_retry_count = (self._sync_retry_count or 0) + 1
    if self._sync_retry_count > self.config.sync_reauth_max_retries then
        require("logger").warn("Tomo: giving up on wake sync after "
            .. tostring(self._sync_retry_count - 1) .. " token refresh failures")
        return
    end
    local ok_ui, UIManager = pcall(require, "ui/uimanager")
    if not ok_ui then return end
    self:_cancelSyncRetry()
    self._sync_retry_fn = function()
        self._sync_retry_fn = nil
        if not self.state.online or self._safe_mode then return end
        -- Bypass the debounce: this IS the deferred sync.
        self._last_sync_time = nil
        guard("wake sync retry", self.syncOnWake, self, user_id)
    end
    UIManager:scheduleIn(self.config.sync_reauth_retry_s, self._sync_retry_fn)
end

-- Called on first connect and on every resume-with-network.
-- Refreshes the session token if it is about to expire, then flushes the
-- outbox, refreshes the user profile, and loads rooms. Every stage runs
-- under its own guard, so one failure (a full disk, a 500 from one table)
-- cannot abort the stages after it.
function Tomo:syncOnWake(user_id)
    if not user_id or not self._api or not self._sync or not self._cache then return end
    if self._safe_mode then return end
    -- Debounce: skip if synced within the last few seconds.
    local now = os.time()
    if self._last_sync_time and (now - self._last_sync_time) < self.config.sync_debounce_s then
        return
    end
    self._last_sync_time = now
    local logger = require("logger")

    -- Token first. After an hour of sleep the JWT has lapsed; refreshing it
    -- here means the requests below carry a valid token instead of each
    -- coming back 401 (crash 6872e46b: GET users, GET rooms, POST presence
    -- and the bloom RPC all failed within four seconds of waking). When the
    -- refresh itself fails -- Wi-Fi is up but not yet routable -- the whole
    -- sync is deferred rather than fired into a wall of 401s.
    if self._api:jwtNeedsRefresh() then
        logger.warn("Tomo: session token expired or expiring, refreshing before sync")
        local refreshed = false
        guard("token refresh", function()
            refreshed = self._api:refreshAuth()
        end)
        if not refreshed then
            -- Allow an immediate retry on the next wake/connect event.
            self._last_sync_time = nil
            self:_scheduleSyncRetry(user_id)
            return
        end
    end
    self._sync_retry_count = 0

    -- Flush any queued outbox messages.
    guard("outbox flush", self._sync.flushOutbox, self._sync)

    -- Check if there's a pending profile update that failed in a previous session.
    -- If so, push the cached values TO the server before fetching FROM the server.
    -- This prevents the server's old data from overwriting the user's unsaved edit.
    guard("pending profile update", function()
        local pending = self._cache:getState("pending_profile_update")
        if pending ~= "1" then return end
        local cached_name = self._cache:getState("auth_username")
        local cached_haiku = self._cache:getState("auth_haiku_bio")
        local updates = {}
        if cached_name then updates.username = cached_name end
        if cached_haiku then updates.haiku_bio = cached_haiku end
        if next(updates) then
            logger.warn("Tomo: retrying pending profile update: " .. (cached_name or ""))
            self._api:updateUser(user_id, updates, function(err)
                if not err then
                    self._cache:deleteState("pending_profile_update")
                    logger.warn("Tomo: pending profile update succeeded")
                end
            end)
        end
    end)

    -- Refresh the user profile from the server.
    guard("profile refresh", self._api.getUser, self._api, user_id, function(err, user)
        if err or type(user) ~= "table" or not isUUID(user.id) then return end
        if type(user.username) ~= "string" or user.username == "" then
            -- Keep the name we already have rather than showing nothing.
            user.username = self.state.user and self.state.user.username or "reader"
        end
        if type(user.haiku_bio) ~= "string" then user.haiku_bio = nil end
        if type(user.stylus_user) ~= "boolean" then user.stylus_user = false end
        self.state.user = user
        -- Mirror user data to BOTH cache DB and LuaSettings.
        -- Both are outside the plugin directory, surviving OTA updates.
        self._cache:setState("auth_username", user.username)
        if user.haiku_bio and user.haiku_bio ~= "" then
            self._cache:setState("auth_haiku_bio", user.haiku_bio)
        end
        pcall(function()
            local LS = require("luasettings")
            local DS = require("datastorage")
            local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
            ts:saveSetting("username", user.username)
            if user.haiku_bio and user.haiku_bio ~= "" then
                ts:saveSetting("haiku_bio", user.haiku_bio)
            end
            ts:flush()
        end)
    end)

    -- Load rooms from Supabase. On success, populate state.rooms from server.
    -- On failure (e.g. RLS recursion bug returns HTTP 500), fall back to the
    -- static genre room list so the UI is never empty.
    guard("rooms refresh", self._api.getRooms, self._api, function(err, rooms)
        local fresh = {}
        if not err and type(rooms) == "table" then
            for _, r in ipairs(rooms) do
                -- A room row without a string id or name cannot be opened or
                -- drawn; skip it rather than seeding state with a nil id.
                if type(r) == "table" and type(r.id) == "string" and type(r.name) == "string" then
                    fresh[#fresh + 1] = {
                        id        = r.id,
                        name      = r.name,
                        slug      = type(r.slug) == "string" and r.slug or nil,
                        genre_tag = type(r.genre_tag) == "string" and r.genre_tag or nil,
                        kind      = type(r.kind) == "string" and r.kind or "genre",
                        isbn      = type(r.isbn) == "string" and r.isbn or nil,
                        has_new   = false,
                    }
                end
            end
        end
        if #fresh > 0 then
            self.state.rooms = fresh
        elseif #self.state.rooms == 0 then
            -- Fallback: populate with static genre rooms so the UI shows something.
            -- These have no server ID, so joining/messaging won't work until the
            -- RLS fix is applied (see supabase/migrations/003_fix_rls_recursion.sql).
            local fallback_genres = {
                { name = "Fantasy & Sci-Fi",   genre_tag = "fantasy-scifi" },
                { name = "Romance",            genre_tag = "romance" },
                { name = "Literary Fiction",   genre_tag = "literary" },
                { name = "Thriller & Mystery", genre_tag = "thriller" },
                { name = "Non-Fiction",        genre_tag = "nonfiction" },
                { name = "Horror",             genre_tag = "horror" },
                { name = "Historical Fiction", genre_tag = "historical" },
                { name = "Young Adult",        genre_tag = "ya" },
            }
            for _, g in ipairs(fallback_genres) do
                self.state.rooms[#self.state.rooms + 1] = {
                    id        = nil,
                    name      = g.name,
                    slug      = "genre-" .. g.genre_tag,
                    genre_tag = g.genre_tag,
                    kind      = "genre",
                    isbn      = nil,
                    has_new   = false,
                }
            end
        end
    end)

    -- Sync current reading presence and trigger bloom check.
    if self.state.current_book then
        guard("presence sync", self._sync.syncPresence, self._sync, user_id, self.state.current_book)
        -- Trigger bloom check after presence is reported
        guard("bloom check", self._api.bloomRooms, self._api, self.state.current_book, function(err)
            if not err then
                logger.warn("Tomo: bloom check completed")
            end
        end)
    end

    -- Ensure all genre rooms have real server IDs.
    -- Keeps retrying every 30s until all 8 are resolved.
    guard("room id resolution", self._ensureRoomIds, self)
end

-- Background polling to resolve nil room IDs on fallback genre rooms.
-- Wi-Fi may connect after Tomo launches; this picks up the IDs when available.
function Tomo:_ensureRoomIds()
    -- Check if all rooms already have IDs
    local has_nil = false
    for _, r in ipairs(self.state.rooms) do
        if r.kind == "genre" and not r.id then
            has_nil = true
            break
        end
    end
    if not has_nil then return end  -- all resolved

    local UIManager = require("ui/uimanager")
    local logger = require("logger")
    local retry_s = self.config.room_resolve_retry_s

    -- Cancel any existing timer
    if self._room_resolve_fn then
        pcall(UIManager.unschedule, UIManager, self._room_resolve_fn)
    end

    -- The scheduled body runs straight from KOReader's event loop, so it is
    -- wrapped: a raise inside would otherwise take KOReader down. When the
    -- device is offline the request is skipped (a synchronous HTTP call
    -- would block the UI for the socket timeout) and the timer simply
    -- waits for the next interval.
    local resolve_fn
    resolve_fn = function()
        if self._room_resolve_fn ~= resolve_fn then return end  -- superseded or torn down
        local ok, err = pcall(function()
            if not self.state.online or not self._api then
                UIManager:scheduleIn(retry_s, resolve_fn)
                return
            end
            self._api:getRooms(function(req_err, rooms)
                if not req_err and type(rooms) == "table" and #rooms > 0 then
                    local resolved = 0
                    for _, server_room in ipairs(rooms) do
                        if type(server_room) == "table" and type(server_room.id) == "string" then
                            for _, state_room in ipairs(self.state.rooms) do
                                if state_room.genre_tag ~= nil
                                    and state_room.genre_tag == server_room.genre_tag
                                    and not state_room.id then
                                    state_room.id = server_room.id
                                    resolved = resolved + 1
                                end
                            end
                        end
                    end
                    if resolved > 0 then
                        logger.warn("Tomo: resolved " .. resolved .. " room IDs from server")
                    end
                end
                -- Check if still unresolved
                local still_nil = false
                for _, r in ipairs(self.state.rooms) do
                    if r.kind == "genre" and not r.id then still_nil = true; break end
                end
                if still_nil then
                    UIManager:scheduleIn(retry_s, resolve_fn)
                else
                    logger.warn("Tomo: all room IDs resolved")
                    self._room_resolve_fn = nil
                end
            end)
        end)
        if not ok then
            logger.warn("Tomo: room id resolution failed: " .. tostring(err))
            UIManager:scheduleIn(retry_s, resolve_fn)
        end
    end
    self._room_resolve_fn = resolve_fn

    UIManager:scheduleIn(self.config.room_resolve_first_s, resolve_fn)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Teardown
-- ─────────────────────────────────────────────────────────────────────────────

-- Called from each plugin instance's onCloseWidget with the generation that
-- instance got from init(). KOReader may construct the new host widget's
-- plugin BEFORE closing the old one, so a stale instance's teardown would
-- otherwise destroy the cache and watcher the fresh init just built while
-- the UI is still alive (crash 05c607e2: screen_room indexing nil _cache).
-- Calling with nil skips the guard and tears down unconditionally.
function Tomo.teardown(generation)
    if generation ~= nil and generation ~= Tomo._generation then
        local ok_lg, lg = pcall(require, "logger")
        if ok_lg then
            lg.warn("Tomo: skipping teardown from stale instance (gen "
                .. tostring(generation) .. ", current " .. tostring(Tomo._generation) .. ")")
        end
        return
    end
    -- Every step is guarded: teardown runs from onCloseWidget inside
    -- KOReader's widget lifecycle, and a raise there would leave the rest of
    -- the resources (timers, sqlite connection, recorder fd) leaked.
    if Tomo._room_resolve_fn then
        local ok_ui, UIManager = pcall(require, "ui/uimanager")
        if ok_ui then pcall(UIManager.unschedule, UIManager, Tomo._room_resolve_fn) end
        Tomo._room_resolve_fn = nil
    end
    Tomo:_cancelSyncRetry()
    if Tomo._lib_watcher then
        guard("watcher stop", Tomo._lib_watcher.stop, Tomo._lib_watcher)
        Tomo._lib_watcher = nil
    end
    if Tomo._sync then
        guard("room poll stop", Tomo._sync.stopRoom, Tomo._sync)
    end
    if Tomo._cache then
        -- Close the connection but KEEP the instance. Cache methods all
        -- self-guard on a nil conn and degrade to empty results, so any UI
        -- still alive after teardown (e.g. the updater's "Exit Tomo" path,
        -- which tears down the current generation while KOReader keeps
        -- running) reads an empty cache instead of crashing on nil._cache.
        guard("cache close", Tomo._cache.close, Tomo._cache)
    end
    if Tomo._recorder then
        guard("recorder stop", Tomo._recorder.stop)
    end
end

return Tomo
