-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/canvas_zones.lua
-- Pure hit-zone geometry for the letter canvas. No KOReader dependencies,
-- so the tap classification that once trapped readers on the canvas
-- (Seal and close unreachable by finger) is unit-testable off-device.
--
-- The canvas screen has three horizontal bands:
--   top bar   [0, topbar_h)              -- close (left), Seal (right)
--   canvas    (topbar_h, toolbar_y)      -- ink
--   toolbar   [toolbar_y, screen bottom) -- undo/eraser/width/colour/clear
--
-- `slop` extends both chrome bands into the canvas, because a fingertip
-- aimed at a button reports a centroid a few millimetres low; without the
-- slop those taps silently drew ink dots instead of pressing the button.

local Zones = {}

-- Minimum widths of the close/Seal hit regions in pixels, before the
-- proportional rule takes over. The top bar holds nothing else, so each
-- target may claim 30% of the screen width on any device.
local MIN_DISCARD_W = 100
local MIN_SEAL_W    = 150
local SIDE_FRACTION = 0.30

-- Classify a touch point against the canvas layout.
-- g: { w, topbar_h, toolbar_y, n_btns, slop }
-- Returns: "discard" | "seal" | "topbar" | "toolbar", btn | "canvas"
-- "topbar" is the dead space between close and Seal: consumed, never inked.
function Zones.classify(gx, gy, g)
    local slop = g.slop or 0
    if gy < g.topbar_h + slop then
        if gx < math.max(MIN_DISCARD_W, math.floor(g.w * SIDE_FRACTION)) then
            return "discard"
        end
        if gx > g.w - math.max(MIN_SEAL_W, math.floor(g.w * SIDE_FRACTION)) then
            return "seal"
        end
        return "topbar"
    end
    if gy >= g.toolbar_y - slop then
        local bw = math.max(1, math.floor(g.w / g.n_btns))
        local btn = math.floor(gx / bw) + 1
        if btn < 1 then btn = 1 end
        if btn > g.n_btns then btn = g.n_btns end
        return "toolbar", btn
    end
    return "canvas"
end

return Zones
