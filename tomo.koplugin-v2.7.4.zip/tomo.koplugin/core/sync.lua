-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/sync.lua
-- Message polling and outbox flushing for the active room.
--
-- Realtime strategy: REST polling every 10 seconds while a room is open.
-- Rationale: KOReader has no native WebSocket client. Polling at 10s intervals
-- is within Supabase free tier API limits (see SKILLS.md §6.3 design decision).
-- WebSocket (via bundled websocat) is deferred to Phase 4.
--
-- One active poll at a time. Entering a new room stops the previous poll and
-- starts a fresh one for the new room. Home screen has no background poll.

local Sync = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Constructor
-- ─────────────────────────────────────────────────────────────────────────────

function Sync.new(api, cache)
    local instance = {
        api          = api,
        cache        = cache,
        _active_room = nil,
        _poll_fn     = nil,
        _polling     = false,
        _flushing    = false,
    }
    return setmetatable(instance, { __index = Sync })
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Room polling
-- ─────────────────────────────────────────────────────────────────────────────

-- Begin polling for new messages in `room_id`.
-- `on_message(msg_table)` is called for each new message received.
-- Cancels any previous poll before starting.
-- The poll runs every 10 seconds until stopRoom() is called.
function Sync:enterRoom(room_id, user_id, page_size, on_message)
    -- Stop any existing poll first.
    self:stopRoom()

    -- Remember the parameters so pauseRoom()/resumeRoom() can restart the
    -- poll after suspend or a network drop while the room stays open.
    self._room_params = {
        room_id    = room_id,
        user_id    = user_id,
        page_size  = page_size,
        on_message = on_message,
    }

    self._active_room = room_id
    self._polling = true
    self._poll_fail_count = 0
    self._poll_interval = 10
    self._poll_stopped = false

    local UIManager = require("ui/uimanager")
    local api       = self.api
    local cache     = self.cache
    local logger    = require("logger")

    local last_seen_ts = cache:newestMessageTime(room_id)

    -- The poll body runs straight from KOReader's scheduler. It is wrapped so
    -- that a raise anywhere inside (a malformed message table reaching the
    -- screen's on_message, a cache failure) is logged and counted as one
    -- failed poll instead of ending KOReader.
    local poll_body
    local poll_fn
    poll_fn = function()
        local ok, err = pcall(poll_body)
        if not ok then
            logger.warn("Tomo Poll: error: " .. tostring(err))
            if self._polling and self._active_room == room_id and not self._poll_stopped then
                self._poll_fail_count = (self._poll_fail_count or 0) + 1
                if self._poll_fail_count >= 5 then
                    self._poll_stopped = true
                    return
                end
                self._poll_interval = math.min((self._poll_interval or 10) * 2, 300)
                UIManager:scheduleIn(self._poll_interval, poll_fn)
            end
        end
    end

    poll_body = function()
        if not self._polling or self._active_room ~= room_id then return end
        if self._poll_stopped then return end

        -- Quick gate: skip HTTP if we know we're disconnected
        local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
        local ok_conn, connected = pcall(function() return NetworkMgr:isConnected() end)
        if ok_nm and ok_conn and not connected then
            self._poll_fail_count = (self._poll_fail_count or 0) + 1
            if self._poll_fail_count >= 5 then
                logger.warn("Tomo Sync: 5 failures (offline), stopping poll. Will retry on room reopen.")
                self._poll_stopped = true
                return
            end
            self._poll_interval = math.min((self._poll_interval or 10) * 2, 300)
            logger.warn("Tomo Poll: fail " .. self._poll_fail_count .. "/5, next in " .. self._poll_interval .. "s")
            UIManager:scheduleIn(self._poll_interval, poll_fn)
            return
        end

        api:getMessages(room_id, page_size or 20, last_seen_ts, function(err, msgs)
            if not self._polling or self._active_room ~= room_id then return end

            if err then
                self._poll_fail_count = (self._poll_fail_count or 0) + 1
                if self._poll_fail_count >= 5 then
                    logger.warn("Tomo Sync: 5 failures, stopping poll. Will retry on room reopen.")
                    self._poll_stopped = true
                    return
                end
                self._poll_interval = math.min((self._poll_interval or 10) * 2, 300)
                logger.warn("Tomo Poll: fail " .. self._poll_fail_count .. "/5 (" .. tostring(err) .. "), next in " .. self._poll_interval .. "s")
            elseif type(msgs) == "table" and #msgs > 0 then
                local ordered = {}
                for i = #msgs, 1, -1 do
                    -- Only well-formed rows reach the cache and the screen.
                    local m = msgs[i]
                    if type(m) == "table" and type(m.id) == "string"
                        and type(m.created_at) == "string" then
                        ordered[#ordered + 1] = m
                    end
                end
                if #ordered > 0 then
                    last_seen_ts = ordered[#ordered].created_at
                    cache:storeMessages(room_id, ordered)
                    for _, msg in ipairs(ordered) do
                        local ok_cb, cb_err = pcall(on_message, msg)
                        if not ok_cb then
                            logger.warn("Tomo Poll: on_message error: " .. tostring(cb_err))
                        end
                    end
                end
                -- Reset backoff on success
                self._poll_fail_count = 0
                self._poll_interval = 10
            else
                -- Empty result (no new messages) is also success
                self._poll_fail_count = 0
                self._poll_interval = 10
            end

            if not self._poll_stopped then
                UIManager:scheduleIn(self._poll_interval, poll_fn)
            end
        end)
    end

    self._poll_fn = poll_fn
    UIManager:scheduleIn(0.1, poll_fn)
end

-- Fully stop polling. Called when the room screen closes: the room is no
-- longer open, so pause state is discarded too.
function Sync:stopRoom()
    self._polling = false
    self._active_room = nil
    self._poll_stopped = false
    self._poll_fail_count = 0
    self._poll_interval = 10
    self._room_params = nil
    if self._poll_fn then
        local ok, UIManager = pcall(require, "ui/uimanager")
        if ok then pcall(UIManager.unschedule, UIManager, self._poll_fn) end
        self._poll_fn = nil
    end
end

-- Halt polling but keep the room parameters, so the poll can be restarted
-- when the device resumes or the network returns. Used by tomo.lua's
-- onSuspend/onNetworkDisconnected handlers.
function Sync:pauseRoom()
    if not self._room_params then return end
    local params = self._room_params
    self:stopRoom()
    self._room_params = params
end

-- Restart a paused poll. No-op when no room was open (stopRoom cleared the
-- params) or the poll is already running.
function Sync:resumeRoom()
    if not self._room_params or self._polling then return end
    local p = self._room_params
    self:enterRoom(p.room_id, p.user_id, p.page_size, p.on_message)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Outbox flushing
-- ─────────────────────────────────────────────────────────────────────────────

-- Drain the outbox FIFO by sending each pending message to Supabase.
-- Called by tomo.lua on onNetworkConnected and periodically during a session.
-- Non-blocking: each send is async; flush continues to the next item on success.
-- After 3 retries, a message is marked failed; after 24h, it expires automatically.
function Sync:flushOutbox()
    if self._flushing then return end  -- Prevent concurrent flushes.
    if not self.api or not self.cache then return end
    self._flushing = true

    local api   = self.api
    local cache = self.cache
    local logger = require("logger")

    -- A raise anywhere in the chain below would leave _flushing stuck at
    -- true for the rest of the session, silently disabling every later
    -- flush. processNext is therefore a guarded wrapper around the real
    -- body: on error the item is marked for retry and the flush ends.
    local processBody
    local current_item
    local function processNext()
        local ok, err = pcall(processBody)
        if not ok then
            logger.warn("Tomo Sync: outbox flush error: " .. tostring(err))
            if current_item then
                -- Same retry budget as a failed send, so an item that makes
                -- the pipeline raise every time surfaces as "could not send"
                -- instead of being retried on every flush forever.
                if (current_item.retry_count or 0) >= 2 then
                    cache:markFailed(current_item.id)
                else
                    cache:markRetry(current_item.id)
                end
            end
            self._flushing = false
        end
    end

    processBody = function()
        current_item = nil
        local items = cache:peekOutbox(1)
        if not items or #items == 0 then
            self._flushing = false
            return
        end

        local item = items[1]
        current_item = item
        -- Rows written by an older build could lack the NOT NULL-guarded
        -- fields this code concatenates; such a row can never send.
        if type(item.id) ~= "number" or type(item.room_id) ~= "string" or item.room_id == "" then
            if item.id then cache:markFailed(item.id) end
            self._flushing = false
            return
        end
        if item.retry_count == nil then item.retry_count = 0 end

        -- Ink messages need the file uploaded first, then the message created.
        if item.kind == "ink" and item.ink_path then
            local room_id = item.room_id
            local msg_id  = tostring(item.id)
            local storage_path = room_id .. "/" .. msg_id .. ".png"

            api:uploadInkImage(item.ink_path, storage_path, function(upload_err, storage_key)
                if upload_err then
                    if item.retry_count >= 2 then
                        cache:markFailed(item.id)
                    else
                        cache:markRetry(item.id)
                    end
                    self._flushing = false
                    return
                end

                -- Pen pal letters carry a delivery time (the 6-18h ceremony);
                -- send those via sendInkLetter so delivers_at reaches the
                -- server. Plain ink messages deliver immediately.
                local function afterSend(send_err, _)
                    if send_err then
                        if item.retry_count >= 2 then
                            cache:markFailed(item.id)
                        else
                            cache:markRetry(item.id)
                        end
                    else
                        cache:markSent(item.id)
                        -- Remove the local ink file after successful upload.
                        if item.ink_path then pcall(os.remove, item.ink_path) end
                    end
                    processNext()
                end
                if item.delivers_at then
                    api:sendInkLetter(room_id, storage_key, item.device_ts,
                        item.delivers_at, afterSend)
                else
                    api:sendInkMessage(room_id, storage_key, item.device_ts, afterSend)
                end
            end)
        elseif item.kind == "ink_pc" and item.ink_path then
            -- Postcrossing letter: no room. Upload under the postcrossing
            -- prefix, add to the pool, then claim one in return.
            local msg_id = tostring(item.id)
            local storage_path = "postcrossing/" .. tostring(api.user_id or "anon")
                .. "/" .. msg_id .. ".png"

            api:uploadInkImage(item.ink_path, storage_path, function(upload_err, storage_key)
                if upload_err then
                    if item.retry_count >= 2 then
                        cache:markFailed(item.id)
                    else
                        cache:markRetry(item.id)
                    end
                    self._flushing = false
                    return
                end

                api:sendPostcrossingLetter(storage_key or storage_path, function(send_err, _)
                    if send_err then
                        if item.retry_count >= 2 then
                            cache:markFailed(item.id)
                        else
                            cache:markRetry(item.id)
                        end
                    else
                        cache:markSent(item.id)
                        if item.ink_path then pcall(os.remove, item.ink_path) end
                        -- Sending one letter earns receiving one.
                        api:claimPostcrossingLetter(function() end)
                    end
                    processNext()
                end)
            end)
        elseif item.kind ~= "text" then
            -- Ink row whose PNG path is missing: it can never send. Mark it
            -- failed so it surfaces in the failed-messages flow instead of
            -- being retried (or worse, sent as an empty text message).
            cache:markFailed(item.id)
            processNext()
        else
            -- Text message: send directly.
            api:sendMessage(item.room_id, item.body, item.device_ts, function(err, _)
                if err then
                    if item.retry_count >= 2 then
                        cache:markFailed(item.id)
                    else
                        cache:markRetry(item.id)
                    end
                else
                    cache:markSent(item.id)
                end
                processNext()
            end)
        end
    end

    processNext()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Presence sync
-- ─────────────────────────────────────────────────────────────────────────────

-- Push the current book's presence to Supabase.
-- Called when library.lua detects a book change, and on reconnect.
function Sync:syncPresence(user_id, book)
    if not book or not user_id or not self.api then return end
    self.api:updatePresence(user_id, book, function() end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Unread check (home screen, no Realtime)
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch unread state for a list of room IDs.
-- callback({ [room_id] = true/false })
function Sync:checkUnread(user_id, room_ids, callback)
    if not self.api then callback({}); return end
    self.api:checkUnread(user_id, room_ids, function(err, unread_map)
        if err or type(unread_map) ~= "table" then
            callback({})
        else
            callback(unread_map)
        end
    end)
end

return Sync
