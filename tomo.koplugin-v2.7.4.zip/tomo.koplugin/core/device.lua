-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/device.lua
-- Device detection with 5-tier capability model.
-- Uses KOReader's Device module as the authoritative source.
--
-- TIER 2: Colour + Stylus (Kobo Libra Colour)
-- TIER 3: Stylus, No Colour (Sage, Elipsa, Elipsa 2E, Kindle Scribe)
-- TIER 4: Colour, No Stylus -- finger draw (Clara Colour, Kindle ColorSoft)
-- TIER 5: Finger Draw, B&W (Clara HD/BW, Libra 2, Forma, PW1-6, Oasis, etc.)
-- TIER 6: Text Only -- IR touch (Touch, Mini, Glo, Aura HD, etc.)

local TomoDevice = {}

local _profile = nil

-- Stylus models: Kobo MPP/MPP2 + Kindle Wacom EMR
local STYLUS_MODELS = {
    Kobo_monza   = true,  -- Libra Colour (MPP 2.0)
    Kobo_condor  = true,  -- Elipsa 2E (MPP 2.0)
    Kobo_europa  = true,  -- Elipsa (MPP)
    Kobo_cadmus  = true,  -- Sage (MPP)
}

-- IR touch models: beam-break detection, NOT suitable for drawing.
-- KOReader's Kobo Touch model strings carry hardware-revision suffixes
-- (Kobo_trilogy_A/B/C), and the Aura Edition 2 rev 2 is Kobo_star_r2.
local IR_MODELS = {
    Kobo_trilogy    = true,  -- Touch (base name, older KOReader)
    Kobo_trilogy_A  = true,  -- Touch A
    Kobo_trilogy_B  = true,  -- Touch B
    Kobo_trilogy_C  = true,  -- Touch C
    Kobo_pixie      = true,  -- Mini
    Kobo_kraken     = true,  -- Glo
    Kobo_dragon     = true,  -- Aura HD
    Kobo_dahlia     = true,  -- Aura H2O
    Kobo_pika       = true,  -- Touch 2.0
    Kobo_alyssum    = true,  -- Glo HD
    Kobo_star       = true,  -- Aura Edition 2
    Kobo_star_r2    = true,  -- Aura Edition 2 rev 2
}

-- Build the capability profile, memoised for the session. Every probe of
-- KOReader's Device object is wrapped: a KOReader build whose Device table
-- lacks one of these methods (new or unusual devices) must degrade to the
-- generic finger-draw profile instead of failing plugin init.
function TomoDevice.getProfile()
    if _profile then return _profile end

    local logger = require("logger")
    local ok_probe, profile_or_err = pcall(TomoDevice._probe)
    if ok_probe and type(profile_or_err) == "table" then
        _profile = profile_or_err
    else
        logger.warn("Tomo Device: probe failed (" .. tostring(profile_or_err)
            .. "), using default profile")
        _profile = TomoDevice._buildDefault()
        -- Keep the real model string when it can be read, so crash reports
        -- and the settings screen still identify the hardware.
        local ok_dev, KODevice = pcall(require, "device")
        if ok_dev and type(KODevice) == "table" and type(KODevice.model) == "string" then
            _profile.model_code = KODevice.model
            _profile.name = KODevice.model
        end
    end
    return _profile
end

-- Query KOReader's Device object. Raises on an unexpected API shape; the
-- caller converts that into the default profile.
function TomoDevice._probe()
    local logger = require("logger")
    local ok, KODevice = pcall(require, "device")

    if not ok or type(KODevice) ~= "table" then
        logger.warn("Tomo Device: KOReader Device module not available, using defaults")
        return TomoDevice._buildDefault()
    end

    local model = type(KODevice.model) == "string" and KODevice.model or "unknown"

    -- Colour detection
    local has_color = false
    if type(KODevice.hasColorScreen) == "function" then
        local ok_c, c = pcall(KODevice.hasColorScreen, KODevice)
        has_color = ok_c and c and true or false
    elseif KODevice.hasColorScreen == true then
        has_color = true
    end

    -- Stylus detection. KOReader's Kindle Scribe device inits set
    -- input.wacom_protocol = true (kindle/device.lua); Kobo never sets it,
    -- so the Kobo model table above stays authoritative there. Matching on
    -- the model string ("KindleScribe", "KindleScribe3", ...) is the
    -- fallback for KOReader builds that predate the flag.
    local has_stylus = STYLUS_MODELS[model] or false
    if not has_stylus then
        local ok_wacom, wacom = pcall(function()
            return KODevice.input and KODevice.input.wacom_protocol
        end)
        if (ok_wacom and wacom) or tostring(model):find("Scribe") then
            has_stylus = true
        end
    end
    if os.getenv("TOMO_FORCE_STYLUS") == "1" then has_stylus = true end

    -- Screen dimensions
    local screen_w, screen_h = 1264, 1680
    if KODevice.screen then
        local ok_w, sw = pcall(function() return KODevice.screen:getWidth() end)
        local ok_h, sh = pcall(function() return KODevice.screen:getHeight() end)
        if ok_w and type(sw) == "number" and sw > 0 then screen_w = sw end
        if ok_h and type(sh) == "number" and sh > 0 then screen_h = sh end
    end

    -- Capability predicates are yes/no function constants on KOReader's
    -- device classes. Query one safely, defaulting when absent or failing.
    local function flag(name, default)
        local fn = KODevice[name]
        if type(fn) ~= "function" then return default end
        local ok_f, v = pcall(fn, KODevice)
        if not ok_f then return default end
        return v and true or false
    end

    -- Touch type: capacitive vs IR. KOReader's real capability flag is
    -- isTouchDevice (yes/no function constants on the device class); the
    -- previously-probed hasNoTouchscreen never existed in KOReader, so
    -- keyboard-only Kindles (Kindle 2/3, DXG) were classified as
    -- finger-draw devices and handed an unusable, unclosable canvas.
    local has_touch = flag("isTouchDevice", true)
    local has_capacitive = has_touch and not IR_MODELS[model]
    -- Kindle IR models
    if model == "KindleTouch" or model == "KindleBasic" or model == "KindleBasic2" then
        has_capacitive = false
    end
    -- Kindle 4 has no touch at all
    if model == "Kindle4" then has_touch = false; has_capacitive = false end

    -- Platform flags
    local is_kindle = flag("isKindle", false)
    local is_kobo = flag("isKobo", false)
    local has_keys = flag("hasKeys", false)

    -- Tier assignment
    local tier
    if has_color and has_stylus then        tier = 2
    elseif has_stylus then                  tier = 3
    elseif has_color and has_capacitive then tier = 4
    elseif has_capacitive then              tier = 5
    else                                    tier = 6
    end

    -- Drawing mode
    local can_draw = tier <= 5
    local draw_mode = has_stylus and "stylus" or (can_draw and "finger" or "none")
    local pen_width = has_stylus and 4 or 8

    -- Compact layout flag (tiny screens)
    local compact = (screen_w * screen_h) < (1024 * 758)

    logger.warn(string.format(
        "Tomo Device: model=%s screen=%dx%d tier=%d color=%s stylus=%s cap=%s draw=%s compact=%s",
        model, screen_w, screen_h, tier, tostring(has_color), tostring(has_stylus),
        tostring(has_capacitive), draw_mode, tostring(compact)))

    return {
        model_code         = model,
        name               = model,
        has_color          = has_color,
        has_stylus         = has_stylus,
        has_capacitive     = has_capacitive,
        has_touch          = has_touch,
        has_keys           = has_keys,
        is_kindle          = is_kindle,
        is_kobo            = is_kobo,
        screen_w           = screen_w,
        screen_h           = screen_h,
        tier               = tier,
        can_draw           = can_draw,
        draw_mode          = draw_mode,
        pen_width          = pen_width,
        compact            = compact,
    }
end

function TomoDevice._buildDefault()
    return {
        model_code     = "unknown",
        name           = "Unknown",
        has_color      = false,
        has_stylus     = false,
        has_capacitive = true,
        has_touch      = true,
        has_keys       = false,
        is_kindle      = false,
        is_kobo        = false,
        screen_w       = 1264,
        screen_h       = 1680,
        tier           = 5,
        can_draw       = true,
        draw_mode      = "finger",
        pen_width      = 8,
        compact        = false,
    }
end

function TomoDevice.resetCache()
    _profile = nil
end

return TomoDevice
