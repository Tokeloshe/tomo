-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/cache.lua
-- Manages tomo_cache.db -- Tomo™'s only local write database.
-- This is not a replica of the server. It is a staging area:
--   outbox    → messages waiting to be sent (FIFO queue)
--   msg_cache → recent messages per room (LRU, max 100 per room)
--   user_state → JWT, user_id, username, and other session scalars
--
-- KoboReader.sqlite is NEVER touched here. That database is read-only.
-- This module is the sole writer to tomo_cache.db.
--
-- SQLite access uses lua-ljsqlite3 (KOReader's bundled binding). That
-- binding reports every SQLite failure by RAISING a Lua error ("database or
-- disk is full", "database is locked", "file is not a database"). Nothing in
-- this module lets such an error escape: every write returns false and logs
-- a warning, every read returns an empty result. The cache is disposable by
-- design (CLAUDE.md §2), so losing a write is always preferable to aborting
-- the caller -- crash 6872e46b aborted an entire wake sync because setState
-- raised on a full disk.

local Cache = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Schema migrations
-- Each entry is a SQL block to execute when upgrading from version (i-1) to i.
-- Migrations are idempotent: safe to run twice (IF NOT EXISTS guards throughout).
-- The schema_version table tracks which migrations have been applied.
-- ─────────────────────────────────────────────────────────────────────────────

local MIGRATIONS = {}

MIGRATIONS[1] = [[
    CREATE TABLE IF NOT EXISTS schema_version (
        version INTEGER NOT NULL
    );
    INSERT INTO schema_version (version) SELECT 0
        WHERE NOT EXISTS (SELECT 1 FROM schema_version);

    CREATE TABLE IF NOT EXISTS outbox (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        room_id     TEXT NOT NULL,
        kind        TEXT NOT NULL DEFAULT 'text',
        body        TEXT,
        ink_path    TEXT,
        device_ts   TEXT NOT NULL,
        retry_count INTEGER DEFAULT 0,
        status      TEXT NOT NULL DEFAULT 'pending',
        created_at  TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS msg_cache (
        id          TEXT PRIMARY KEY,
        room_id     TEXT NOT NULL,
        user_id     TEXT,
        username    TEXT,
        kind        TEXT NOT NULL DEFAULT 'text',
        body        TEXT,
        ink_url     TEXT,
        created_at  TEXT NOT NULL,
        delivers_at TEXT,
        cached_at   TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_msg_cache_room
        ON msg_cache(room_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS user_state (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
]]

-- delivers_at rides along in the outbox so delayed pen pal letters keep
-- their delivery ceremony even when they are sent via a later flush
-- (offline seal -> reconnect) instead of immediately.
MIGRATIONS[2] = [[
    ALTER TABLE outbox ADD COLUMN delivers_at TEXT;
]]

-- Messages per room kept in msg_cache (LRU cap).
local MSG_CACHE_PER_ROOM = 100

-- Milliseconds to wait on SQLITE_BUSY before giving up.
local BUSY_TIMEOUT_MS = 3000

-- Default outbox peek size.
local DEFAULT_PEEK_LIMIT = 10

-- Default page size for getMessages.
local DEFAULT_MESSAGE_LIMIT = 20

-- Default age after which pending outbox rows are marked failed.
local DEFAULT_OUTBOX_MAX_AGE_H = 24

-- ─────────────────────────────────────────────────────────────────────────────
-- Internal helpers
-- ─────────────────────────────────────────────────────────────────────────────

local function logWarn(msg)
    local ok, logger = pcall(require, "logger")
    if ok and logger then logger.warn("Tomo Cache: " .. tostring(msg)) end
end

-- Escape a string for safe inclusion in SQL literals.
local function sqlEscape(s)
    if s == nil then return "NULL" end
    return "'" .. tostring(s):gsub("'", "''") .. "'"
end

-- Sanitize a value for SQLite bind parameters.
-- rapidjson decodes JSON null as rapidjson.null (userdata), which LJSQLite3
-- cannot bind. Convert any non-string/number/nil value to nil (SQL NULL).
local function sqlBind(v)
    local t = type(v)
    if t == "string" or t == "number" or t == "nil" then return v end
    if t == "boolean" then return v and 1 or 0 end
    return nil
end

-- Run `fn` against the open connection. Any SQLite error is logged with
-- `label` and swallowed: writes report false, reads report nil. This is the
-- single choke point that keeps SQLite failures out of KOReader's event loop.
local function guarded(self, label, fn)
    if not self.conn then return false, "cache closed" end
    local ok, result, extra = pcall(fn, self.conn)
    if not ok then
        logWarn(label .. " failed: " .. tostring(result))
        return false, tostring(result)
    end
    return true, result, extra
end

-- Close a prepared statement without letting a second error mask the first.
local function closeStmt(stmt)
    if stmt then pcall(stmt.close, stmt) end
end

-- Prepare, bind, step and finalise a single write statement. The statement
-- handle is closed on every path so a failed step cannot leak it.
local function runStatement(conn, sql, ...)
    local stmt = conn:prepare(sql)
    local args = { ... }
    local nargs = select("#", ...)
    local ok, err = pcall(function()
        if nargs > 0 then stmt:bind(unpack(args, 1, nargs)) end
        stmt:step()
    end)
    closeStmt(stmt)
    if not ok then error(err, 0) end
end

-- Build an array of row tables from an ljsqlite3 column-oriented result set.
-- `fields` maps output key -> { column_name, converter }.
local function rowsFromResult(results, fields, key_col)
    local items = {}
    if not results or not results[key_col] then return items end
    for i = 1, #results[key_col] do
        local row = {}
        for key, spec in pairs(fields) do
            local col, convert = spec[1], spec[2]
            local v = results[col] and results[col][i]
            if convert then v = convert(v) end
            row[key] = v
        end
        items[#items + 1] = row
    end
    return items
end

local function toNumber(v) return tonumber(v) end
local function toCount(v) return tonumber(v) or 0 end

-- SQLite error strings that mean the file on disk is not a usable database.
-- When open() hits one of these the cache is recreated: it holds only
-- disposable staging data, and a corrupt file would otherwise disable the
-- outbox and session restore for every future launch.
local CORRUPT_PATTERNS = {
    "file is not a database",
    "database disk image is malformed",
    "unsupported file format",
    "file is encrypted",
}

local function looksCorrupt(err)
    local s = tostring(err or ""):lower()
    for _, pat in ipairs(CORRUPT_PATTERNS) do
        if s:find(pat, 1, true) then return true end
    end
    return false
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

-- Resolve the on-disk path. `_db_path` may be set before open() (tests, or a
-- caller that needs a scratch database); production uses KOReader's settings
-- directory so the file survives plugin updates.
function Cache:dbPath()
    if self._db_path then return self._db_path end
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if not ok_ds then return nil, "datastorage not available" end
    local ok_dir, dir = pcall(function() return DataStorage:getSettingsDir() end)
    if not ok_dir or type(dir) ~= "string" or dir == "" then
        return nil, "settings directory unavailable"
    end
    return dir .. "/tomo_cache.sqlite3"
end

-- Open the file at `path` and run migrations. Returns (true) or (false, err).
-- Leaves self.conn nil on failure.
function Cache:_openAt(SQ3, path)
    local ok_open, conn = pcall(SQ3.open, path)
    if not ok_open or not conn then
        return false, "Cannot open tomo_cache.db: " .. tostring(conn)
    end
    self.conn = conn

    -- WAL mode gives better concurrent read/write without blocking. Both
    -- pragmas are best-effort: a read-only or full filesystem can refuse the
    -- journal switch, and the cache still works in the default journal mode.
    local ok_wal, wal_err = pcall(conn.exec, conn, "PRAGMA journal_mode=WAL;")
    if not ok_wal then logWarn("WAL pragma failed: " .. tostring(wal_err)) end
    pcall(conn.set_busy_timeout, conn, BUSY_TIMEOUT_MS)

    local ok_mig, err = self:migrate()
    if not ok_mig then
        pcall(conn.close, conn)
        self.conn = nil
        return false, err
    end
    return true
end

-- Open tomo_cache.db and run any pending migrations.
-- Returns true on success, false + error string on failure.
-- The caller (tomo.lua) holds the Cache instance for the session lifetime.
-- A corrupt database file is deleted and recreated once; every other
-- failure leaves the instance in its closed state, where all methods
-- degrade to no-ops and empty results.
function Cache:open()
    if self.conn then return true end

    local ok_sq3, SQ3 = pcall(require, "lua-ljsqlite3/init")
    if not ok_sq3 then
        return false, "lua-ljsqlite3 not available"
    end

    local path, path_err = self:dbPath()
    if not path then return false, path_err end
    self._resolved_path = path

    local ok, err = self:_openAt(SQ3, path)
    if ok then return true end

    if looksCorrupt(err) then
        logWarn("database unusable (" .. tostring(err) .. "), recreating")
        Cache.removeFiles(path)
        ok, err = self:_openAt(SQ3, path)
        if ok then
            self.recreated = true
            return true
        end
    end
    return false, err
end

-- Delete a cache database and its WAL/SHM side files.
function Cache.removeFiles(path)
    if type(path) ~= "string" then return end
    for _, suffix in ipairs({ "", "-wal", "-shm", "-journal" }) do
        pcall(os.remove, path .. suffix)
    end
end

function Cache:close()
    if self.conn then
        local ok, err = pcall(self.conn.close, self.conn)
        if not ok then logWarn("close failed: " .. tostring(err)) end
        self.conn = nil
    end
end

-- True when a usable connection is open.
function Cache:isOpen()
    return self.conn ~= nil
end

-- Apply any migrations with index > current schema_version.
function Cache:migrate()
    if not self.conn then return false, "cache closed" end
    -- Determine current schema version. pcall because schema_version
    -- may not exist yet on the very first run.
    local current_version = 0
    local ok, version = pcall(self.conn.rowexec, self.conn,
        "SELECT version FROM schema_version LIMIT 1")
    if ok and version then
        current_version = tonumber(version) or 0
    end

    -- Apply each pending migration in sequence.
    for v = current_version + 1, #MIGRATIONS do
        local ok_exec, err = pcall(self.conn.exec, self.conn, MIGRATIONS[v])
        -- "duplicate column name" means an ALTER already ran (e.g. the
        -- schema_version row was lost but the schema survived). SQLite has
        -- no IF NOT EXISTS for ADD COLUMN, so treat it as already applied.
        if not ok_exec and not tostring(err):find("duplicate column") then
            return false, string.format("Migration %d failed: %s", v, tostring(err))
        end
        local ok_ver, ver_err = pcall(self.conn.exec, self.conn, string.format(
            "UPDATE schema_version SET version = %d", v
        ))
        if not ok_ver then
            return false, string.format("Migration %d version stamp failed: %s",
                v, tostring(ver_err))
        end
    end

    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- user_state: key-value store for JWT, user_id, username, etc.
-- ─────────────────────────────────────────────────────────────────────────────

-- Store a scalar. Returns true on success, false when the cache is closed or
-- the write failed (full disk, locked database). Never raises.
function Cache:setState(key, value)
    if key == nil then return false, "key is nil" end
    local ok = guarded(self, "setState(" .. tostring(key) .. ")", function(conn)
        runStatement(conn,
            "INSERT OR REPLACE INTO user_state (key, value) VALUES (?, ?)",
            tostring(key), tostring(value))
    end)
    return ok
end

function Cache:getState(key)
    if not self.conn or key == nil then return nil end
    local ok, val = pcall(self.conn.rowexec, self.conn,
        "SELECT value FROM user_state WHERE key = " .. sqlEscape(key) .. " LIMIT 1")
    if ok and val ~= nil then return val end
    return nil
end

-- Returns true on success, false on failure. Never raises.
function Cache:deleteState(key)
    if key == nil then return false, "key is nil" end
    local ok = guarded(self, "deleteState(" .. tostring(key) .. ")", function(conn)
        conn:exec("DELETE FROM user_state WHERE key = " .. sqlEscape(key))
    end)
    return ok
end

-- ─────────────────────────────────────────────────────────────────────────────
-- outbox: FIFO queue of unsent messages
-- ─────────────────────────────────────────────────────────────────────────────

-- Add a message to the outbox. Returns the new row id, or nil on error.
-- `kind` is "text", "ink", or "ink_pc" (postcrossing letter -- room_id holds
-- the sentinel 'postcrossing'). `ink_path` is a local filesystem path (for
-- ink messages only); it is uploaded to Supabase Storage on flush.
-- `delivers_at` is an optional ISO 8601 delivery time for pen pal letters.
function Cache:enqueue(room_id, kind, body, ink_path, device_ts, delivers_at)
    if not self.conn then return nil end
    if not room_id or room_id == "" then
        logWarn("enqueue skipped, room_id is nil")
        return nil
    end
    if not device_ts then
        device_ts = os.date("!%Y-%m-%dT%H:%M:%SZ")
    end
    local ok, row_id = guarded(self, "enqueue", function(conn)
        runStatement(conn, [[
            INSERT INTO outbox (room_id, kind, body, ink_path, device_ts, delivers_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ]], sqlBind(room_id), sqlBind(kind) or "text", sqlBind(body),
            sqlBind(ink_path), sqlBind(device_ts), sqlBind(delivers_at))
        return tonumber(conn:rowexec("SELECT last_insert_rowid()"))
    end)
    if not ok then return nil end
    return row_id
end

local OUTBOX_FIELDS = {
    id          = { "id", toNumber },
    room_id     = { "room_id" },
    kind        = { "kind" },
    body        = { "body" },
    ink_path    = { "ink_path" },
    device_ts   = { "device_ts" },
    retry_count = { "retry_count", toCount },
    delivers_at = { "delivers_at" },
}

-- Return up to `limit` pending outbox messages in FIFO order.
-- This is a read; it does not dequeue anything. Returns {} on any failure.
function Cache:peekOutbox(limit)
    local ok, results = guarded(self, "peekOutbox", function(conn)
        return conn:exec(string.format([[
            SELECT id, room_id, kind, body, ink_path, device_ts, retry_count, delivers_at
            FROM outbox
            WHERE status = 'pending'
            ORDER BY id ASC
            LIMIT %d
        ]], tonumber(limit) or DEFAULT_PEEK_LIMIT))
    end)
    if not ok then return {} end
    return rowsFromResult(results, OUTBOX_FIELDS, "id")
end

-- Run a single-row outbox update by id. Shared by the mark* methods.
-- outbox_id can be nil when enqueue() ran against a degraded cache;
-- string.format("%d", nil) would throw, so the id is validated first.
function Cache:_outboxUpdate(label, sql_template, outbox_id)
    outbox_id = tonumber(outbox_id)
    if not outbox_id then return false, "outbox_id is nil" end
    local ok = guarded(self, label, function(conn)
        conn:exec(string.format(sql_template, outbox_id))
    end)
    return ok
end

-- Remove a successfully sent message from the outbox. Returns true/false.
function Cache:markSent(outbox_id)
    return self:_outboxUpdate("markSent",
        "DELETE FROM outbox WHERE id = %d", outbox_id)
end

-- Increment retry_count for a failed send attempt. Returns true/false.
function Cache:markRetry(outbox_id)
    return self:_outboxUpdate("markRetry",
        "UPDATE outbox SET retry_count = retry_count + 1 WHERE id = %d", outbox_id)
end

-- Mark a message as permanently failed (shown to user with "try again/let it go").
function Cache:markFailed(outbox_id)
    return self:_outboxUpdate("markFailed",
        "UPDATE outbox SET status = 'failed' WHERE id = %d", outbox_id)
end

-- Mark outbox entries as failed if they are older than max_age_hours.
-- Called on app open to surface stale unsent messages. Returns true/false.
function Cache:expireStaleOutbox(max_age_hours)
    local hours = tonumber(max_age_hours) or DEFAULT_OUTBOX_MAX_AGE_H
    local ok = guarded(self, "expireStaleOutbox", function(conn)
        conn:exec(string.format([[
            UPDATE outbox SET status = 'failed'
            WHERE status = 'pending'
              AND created_at < datetime('now', '-%d hours')
        ]], hours))
    end)
    return ok
end

local FAILED_FIELDS = {
    id        = { "id", toNumber },
    room_id   = { "room_id" },
    kind      = { "kind" },
    body      = { "body" },
    device_ts = { "device_ts" },
}

-- Return all failed outbox entries so the UI can show "some messages couldn't send."
-- Returns {} on any failure.
function Cache:getFailedMessages()
    local ok, results = guarded(self, "getFailedMessages", function(conn)
        return conn:exec([[
            SELECT id, room_id, kind, body, device_ts
            FROM outbox
            WHERE status = 'failed'
            ORDER BY id ASC
        ]])
    end)
    if not ok then return {} end
    return rowsFromResult(results, FAILED_FIELDS, "id")
end

-- Re-queue a failed message so the next flush attempt picks it up again.
function Cache:retryFailed(outbox_id)
    return self:_outboxUpdate("retryFailed",
        "UPDATE outbox SET status = 'pending', retry_count = 0 WHERE id = %d", outbox_id)
end

-- Permanently remove a failed message. The user chose "let it go."
function Cache:discardFailed(outbox_id)
    return self:_outboxUpdate("discardFailed",
        "DELETE FROM outbox WHERE id = %d", outbox_id)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- msg_cache: LRU cache of received messages per room (max 100 per room)
-- ─────────────────────────────────────────────────────────────────────────────

-- Store a batch of messages from the server. Enforces the 100-per-room LRU
-- cap after insertion by deleting the oldest rows beyond the limit.
-- `messages` is an array of message tables from api.lua.
-- Returns true when every row was written, false otherwise. Never raises.
function Cache:storeMessages(room_id, messages)
    if type(messages) ~= "table" or #messages == 0 then return true end
    if not room_id then return false, "room_id is nil" end

    local ok = guarded(self, "storeMessages", function(conn)
        local stmt = conn:prepare([[
            INSERT OR REPLACE INTO msg_cache
                (id, room_id, user_id, username, kind, body, ink_url, created_at, delivers_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]])
        local ok_rows, err = pcall(function()
            for _, msg in ipairs(messages) do
                if type(msg) == "table" and sqlBind(msg.id) ~= nil
                    and sqlBind(msg.created_at) ~= nil then
                    stmt:bind(
                        sqlBind(msg.id),
                        sqlBind(msg.room_id) or room_id,
                        sqlBind(msg.user_id),
                        sqlBind(msg.username),
                        sqlBind(msg.kind) or "text",
                        sqlBind(msg.body),
                        sqlBind(msg.ink_url),
                        sqlBind(msg.created_at),
                        sqlBind(msg.delivers_at)
                    )
                    stmt:step()
                    stmt:clearbind():reset()
                end
            end
        end)
        closeStmt(stmt)
        if not ok_rows then error(err, 0) end

        -- Enforce LRU cap: keep only the newest rows per room.
        local escaped = sqlEscape(room_id)
        conn:exec(string.format([[
            DELETE FROM msg_cache
            WHERE room_id = %s
              AND id NOT IN (
                SELECT id FROM msg_cache
                WHERE room_id = %s
                ORDER BY created_at DESC
                LIMIT %d
              )
        ]], escaped, escaped, MSG_CACHE_PER_ROOM))
    end)
    return ok
end

local MESSAGE_FIELDS = {
    id          = { "id" },
    room_id     = { "room_id" },
    user_id     = { "user_id" },
    username    = { "username" },
    kind        = { "kind" },
    body        = { "body" },
    ink_url     = { "ink_url" },
    created_at  = { "created_at" },
    delivers_at = { "delivers_at" },
}

-- Return cached messages for a room, newest first, up to `limit`.
-- `before_ts` is an optional ISO 8601 timestamp for pagination (load older).
-- Only returns messages where delivers_at IS NULL OR delivers_at <= now(),
-- so delayed pen pal letters are not shown before their delivery time.
-- Returns {} on any failure.
function Cache:getMessages(room_id, limit, before_ts)
    if not room_id then return {} end

    -- delivers_at comes from the server in ISO 8601 ("2026-07-02T10:00:00+00:00")
    -- while datetime('now') yields "2026-07-02 10:00:00". Compared as raw
    -- strings, 'T' > ' ' makes every same-day delivery look future-dated, so
    -- both sides go through datetime() to normalise the format first.
    local sql = string.format([[
        SELECT id, room_id, user_id, username, kind, body, ink_url,
               created_at, delivers_at
        FROM msg_cache
        WHERE room_id = %s
          AND (delivers_at IS NULL OR datetime(delivers_at) <= datetime('now'))
    ]], sqlEscape(room_id))

    if before_ts then
        sql = sql .. " AND created_at < " .. sqlEscape(before_ts)
    end
    sql = sql .. " ORDER BY created_at DESC LIMIT "
        .. tostring(tonumber(limit) or DEFAULT_MESSAGE_LIMIT)

    local ok, results = guarded(self, "getMessages", function(conn)
        return conn:exec(sql)
    end)
    if not ok then return {} end
    return rowsFromResult(results, MESSAGE_FIELDS, "id")
end

-- Return the created_at timestamp of the newest cached message in a room.
-- Used by sync.lua to fetch only messages newer than the cache.
function Cache:newestMessageTime(room_id)
    if not self.conn or not room_id then return nil end
    local ok, ts = pcall(self.conn.rowexec, self.conn, string.format(
        "SELECT created_at FROM msg_cache WHERE room_id = %s ORDER BY created_at DESC LIMIT 1",
        sqlEscape(room_id)
    ))
    if ok and ts then return ts end
    return nil
end

-- Update the username for all cached messages from a given user_id.
-- Called when the user changes their display name so old messages show the new name.
function Cache:updateCachedUsername(user_id, new_username)
    if not user_id or not new_username then return false, "missing argument" end
    local ok = guarded(self, "updateCachedUsername", function(conn)
        conn:exec(string.format(
            "UPDATE msg_cache SET username = %s WHERE user_id = %s",
            sqlEscape(new_username), sqlEscape(user_id)
        ))
    end)
    return ok
end

-- Remove a single cached message by id. Used to clean up the optimistic
-- "pending-" row once the server-confirmed copy (with its real UUID) is
-- stored, so the same message is not rendered twice on the next room open.
function Cache:deleteMessage(msg_id)
    if msg_id == nil then return false, "msg_id is nil" end
    local ok = guarded(self, "deleteMessage", function(conn)
        conn:exec("DELETE FROM msg_cache WHERE id = " .. sqlEscape(msg_id))
    end)
    return ok
end

-- Remove all cached messages for a room. Called on room leave if the cache
-- grows stale (e.g. after a long offline period on a device with low storage).
function Cache:clearRoomCache(room_id)
    if room_id == nil then return false, "room_id is nil" end
    local ok = guarded(self, "clearRoomCache", function(conn)
        conn:exec("DELETE FROM msg_cache WHERE room_id = " .. sqlEscape(room_id))
    end)
    return ok
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Factory: return a new Cache instance.
-- Caller must call :open() before using any other method.
-- ─────────────────────────────────────────────────────────────────────────────

function Cache.new()
    return setmetatable({}, { __index = Cache })
end

return Cache
