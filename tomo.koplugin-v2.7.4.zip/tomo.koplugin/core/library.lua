-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/library.lua
-- Read-only access to KoboReader.sqlite -- the Kobo's own reading database.
-- This module NEVER writes to the device database. Not one byte.
-- The architecture non-negotiable is: Tomo™ is a guest in this database.
--
-- Three public functions:
--   Library.getCurrentBook()          → current/most-recent book or nil
--   Library.getShelfCandidates(limit) → top-N books by reading time
--   Library.watchForChange(callback)  → event-driven change detection
--
-- SQLite access uses lua-ljsqlite3 (KOReader's bundled binding).
-- All queries are SELECT-only. Read-only safety is enforced by never
-- running INSERT/UPDATE/DELETE against this database.

local Library = {}

local KOBO_DB_PATH  = "/mnt/onboard/.kobo/KoboReader.sqlite"
local KOBO_WAL_PATH = "/mnt/onboard/.kobo/KoboReader.sqlite-wal"

-- Module-level flag to avoid redefining inotify FFI symbols.
-- LuaJIT raises an error if ffi.cdef sees the same symbol twice.
local _inotify_defs_loaded = false

-- ─────────────────────────────────────────────────────────────────────────────
-- Internal helpers
-- ─────────────────────────────────────────────────────────────────────────────

-- Open KoboReader.sqlite via ljsqlite3.
-- Returns (conn, nil) on success or (nil, error_string) on failure.
-- Callers are responsible for calling conn:close() when done.
local function openDB()
    local ok, SQ3 = pcall(require, "lua-ljsqlite3/init")
    if not ok then
        return nil, "lua-ljsqlite3 module not available"
    end

    -- _db_path_override lets tests point at a fixture database.
    -- Production always reads the real Kobo path.
    local path = Library._db_path_override or KOBO_DB_PATH

    -- "ro" (SQLITE_OPEN_READONLY) is load-bearing: ljsqlite3 defaults to
    -- "rwc", which would (a) CREATE a stray KoboReader.sqlite if the file
    -- is missing and (b) make Tomo's close() the last writer able to
    -- checkpoint and delete Nickel's WAL. This is Nickel's database; Tomo
    -- is a guest in it and never opens it writable.
    local ok_open, conn = pcall(SQ3.open, path, "ro")
    if not ok_open or not conn then
        return nil, "Cannot open KoboReader.sqlite: " .. tostring(conn)
    end
    return conn, nil
end

-- Normalise an ISBN value from KoboReader.sqlite.
-- Returns nil for empty strings and whitespace-only values --
-- the Kobo database stores empty string rather than SQL NULL for missing ISBNs.
-- Separator characters (hyphens, spaces) are stripped so the same edition
-- matches across devices regardless of how the metadata hyphenates the ISBN.
local function normaliseISBN(raw)
    if not raw then return nil end
    local cleaned = raw:gsub("[%s%-]", "")
    if cleaned == "" then return nil end
    return cleaned
end

-- Compute a stable hash from normalized title+author.
-- Available for EVERY book (unlike ISBN which is missing for sideloaded ePubs).
-- Uses djb2 algorithm -- no external dependency, deterministic, collision-adequate.
local function computeBookHash(title, author)
    local function norm(s)
        if s == nil then return "" end
        if type(s) ~= "string" then s = tostring(s) end
        s = s:lower()
        s = s:gsub("^the%s+", ""):gsub("^a%s+", ""):gsub("^an%s+", "")
        s = s:gsub("[^%w%s]", ""):gsub("%s+", " ")
        return s:match("^%s*(.-)%s*$") or ""
    end
    local key = norm(title) .. "|" .. norm(author)
    local hash = 5381
    for i = 1, #key do
        hash = ((hash * 33) + key:byte(i)) % 0xFFFFFFFF
    end
    return string.format("%08x", hash)
end

-- Expose as module function for use by api.lua and tests.
Library.computeBookHash = computeBookHash
Library._normaliseISBN = normaliseISBN

-- Extract an ISBN from KOReader's document props. The real metadata key is
-- `identifiers` (plural), a newline-separated list like "isbn:97812345678"
-- (frontend/document/document.lua); `props.isbn` never exists, so ISBN
-- room blooming from non-Kobo readers silently never happened.
-- Returns a bare 10/13-digit string, or nil.
local function isbnFromProps(props)
    local ids = props and props.identifiers
    if type(ids) ~= "string" then return nil end
    for line in (ids .. "\n"):gmatch("(.-)\n") do
        local digits = line:gsub("[%s%-:%a]", "")
        if #digits == 13 or #digits == 10 then
            return digits
        end
    end
    return nil
end
Library._isbnFromProps = isbnFromProps

-- Build a Tomo book table from a KOReader document object (ReaderUI's
-- self.document, or ui.document inside an onReaderReady handler -- the
-- ReaderUI.instance global is NOT yet assigned when ReaderReady fires).
-- Returns nil when there is no usable document.
function Library.bookFromDocument(document)
    local book
    pcall(function()
        if document and document.getProps then
            local props = document:getProps()
            if props and props.title and props.title ~= "" then
                book = {
                    content_id   = document.file or props.title,
                    title        = props.title,
                    author       = props.authors or "",
                    isbn         = isbnFromProps(props),
                    progress_pct = 0,
                    book_hash    = computeBookHash(props.title, props.authors or ""),
                }
            end
        end
    end)
    return book
end

-- ─────────────────────────────────────────────────────────────────────────────
-- inotify helpers (LuaJIT FFI)
-- ─────────────────────────────────────────────────────────────────────────────

-- Declare the POSIX symbols needed to drive inotify from LuaJIT.
-- Called at most once per process; the flag prevents double-declaration errors.
-- Returns true if the declarations succeeded, false if inotify is unavailable.
local function loadInotifyDefs(ffi)
    if _inotify_defs_loaded then return true end

    -- Attempt the full declaration. If read/close/fcntl are already defined
    -- by KOReader internals, the entire block fails and we try a minimal set.
    local ok = pcall(ffi.cdef, [[
        int inotify_init(void);
        int inotify_add_watch(int fd, const char *pathname, uint32_t mask);
        int inotify_rm_watch(int fd, int wd);
        int read(int fd, void *buf, size_t count);
        int close(int fd);
        int fcntl(int fd, int cmd, ...);
    ]])

    if not ok then
        -- Some symbols already defined by KOReader. Declare only the
        -- inotify-specific calls; read/close/fcntl are already available.
        ok = pcall(ffi.cdef, [[
            int inotify_init(void);
            int inotify_add_watch(int fd, const char *pathname, uint32_t mask);
            int inotify_rm_watch(int fd, int wd);
        ]])
    end

    if ok then
        _inotify_defs_loaded = true
    end
    return _inotify_defs_loaded
end

-- Attempt to create an inotify watcher for the WAL file.
-- `on_change` is called synchronously each time a write event is detected.
-- Returns a watcher object { poll(), stop() } or nil if inotify is unavailable.
--
-- Design: we set the inotify fd to non-blocking mode so that poll() returns
-- immediately when there are no events. UIManager schedules poll() every 2
-- seconds -- cheap when quiet, reactive within 2s of any database write.
local function tryInotifyUnsafe(on_change)
    local ok, ffi = pcall(require, "ffi")
    if not ok then return nil end

    if not loadInotifyDefs(ffi) then return nil end

    local IN_MODIFY  = 0x00000002
    local O_NONBLOCK = 2048
    local F_GETFL    = 3
    local F_SETFL    = 4
    local C = ffi.C

    local fd = C.inotify_init()
    if fd < 0 then return nil end

    -- Set non-blocking so read() returns immediately with -1 when empty.
    -- This makes poll() safe to call on a UIManager schedule without stalling.
    local flags = C.fcntl(fd, F_GETFL)
    C.fcntl(fd, F_SETFL, ffi.cast("int", bit.bor(flags, O_NONBLOCK)))

    local wd = C.inotify_add_watch(fd, KOBO_WAL_PATH, IN_MODIFY)
    if wd < 0 then
        C.close(fd)
        return nil
    end

    local buf     = ffi.new("char[4096]")
    local stopped = false

    return {
        -- Read any pending inotify events. Calls on_change once if any arrived.
        -- Several events in a single read collapse into one notification;
        -- we only care that *something* changed, not how many times.
        poll = function()
            if stopped then return end
            local n = C.read(fd, buf, 4096)
            if n > 0 then
                on_change()
            end
        end,

        stop = function()
            if stopped then return end
            stopped = true
            C.inotify_rm_watch(fd, wd)
            C.close(fd)
        end,
    }
end

-- The FFI calls above resolve libc symbols lazily: on a platform whose libc
-- lacks inotify (or exports it under another name) the first C.inotify_init
-- raises instead of returning -1. Treat any raise as "inotify unavailable"
-- so the caller falls back to mtime polling.
local function tryInotify(on_change)
    local ok, watcher = pcall(tryInotifyUnsafe, on_change)
    if ok then return watcher end
    local ok_log, logger = pcall(require, "logger")
    if ok_log then
        logger.warn("Tomo Library: inotify unavailable (" .. tostring(watcher) .. "), using mtime polling")
    end
    return nil
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Public API
-- ─────────────────────────────────────────────────────────────────────────────

-- Return the book the reader is currently reading (or most recently read).
-- "Currently reading" means ReadStatus IN (1, 2) -- started or finished,
-- with a last-read timestamp, ordered most-recent first.
--
-- Returned table:
--   content_id   (string)  ContentID from KoboReader.sqlite (the epub file path)
--   title        (string)  Book title
--   author       (string)  Author (Attribution column)
--   isbn         (string|nil) ISBN-13 if available, nil for sideloaded books
--   progress_pct (number)  Reading progress 0 -- 100
--
-- Returns nil if no book has been read or if the database is unavailable.
function Library.getCurrentBook()
    local conn = openDB()
    if not conn then return nil end

    local result = nil
    local ok, results = pcall(conn.exec, conn, [[
        SELECT ContentID, Title, Attribution, ISBN,
               CAST(___PercentRead AS REAL) AS progress_pct
        FROM content
        WHERE ContentType = 6
          AND ReadStatus IN (1, 2)
          AND DateLastRead IS NOT NULL
        ORDER BY DateLastRead DESC
        LIMIT 1
    ]])

    if ok and results and results.ContentID and results.ContentID[1] then
        local title  = results.Title and results.Title[1]
        local author = results.Attribution and results.Attribution[1]
        result = {
            content_id   = results.ContentID[1],
            title        = title,
            author       = author,
            isbn         = normaliseISBN(results.ISBN and results.ISBN[1]),
            progress_pct = tonumber(results.progress_pct and results.progress_pct[1]) or 0,
            book_hash    = computeBookHash(title, author),
        }
    end

    pcall(conn.close, conn)
    return result
end

-- Return up to `limit` books sorted by total reading time, descending.
-- This gives the most-read books, which is the best proxy for "books the
-- reader cares enough about to put on their shelf."
-- Sideloaded books without ISBNs are included -- their isbn field will be nil.
--
-- Each entry in the returned array:
--   content_id   (string)  ContentID
--   title        (string)  Book title
--   author       (string)  Author
--   isbn         (string|nil)
--   progress_pct (number)  0 -- 100
--   time_spent_s (integer) Total seconds of active reading
--
-- Returns an empty table (never nil) if the database is unavailable.
function Library.getShelfCandidates(limit)
    limit = (type(limit) == "number" and limit > 0) and math.floor(limit) or 10

    local conn = openDB()
    if not conn then return {} end

    local results_out = {}
    local ok, results = pcall(conn.exec, conn, string.format([[
        SELECT ContentID, Title, Attribution, ISBN,
               CAST(___PercentRead AS REAL) AS progress_pct,
               TimeSpentReading
        FROM content
        WHERE ContentType = 6
          AND TimeSpentReading > 0
        ORDER BY TimeSpentReading DESC
        LIMIT %d
    ]], limit))

    if ok and results and results.ContentID then
        for i = 1, #results.ContentID do
            results_out[#results_out + 1] = {
                content_id   = results.ContentID[i],
                title        = results.Title and results.Title[i],
                author       = results.Attribution and results.Attribution[i],
                isbn         = normaliseISBN(results.ISBN and results.ISBN[i]),
                progress_pct = tonumber(results.progress_pct and results.progress_pct[i]) or 0,
                time_spent_s = tonumber(results.TimeSpentReading and results.TimeSpentReading[i]) or 0,
            }
        end
    end

    pcall(conn.close, conn)
    return results_out
end

-- Set up event-driven detection of book changes.
-- Watches the KoboReader.sqlite WAL file for writes. When Nickel or KOReader
-- updates the database (page turn, book open, etc.) the WAL changes. Tomo™
-- re-queries the current book and fires `callback(new_book)` only when the
-- book identity (ContentID) has actually changed. The callback is also fired
-- immediately on startup to populate the initial state.
--
-- Strategy:
--   1. Try inotify via LuaJIT FFI -- polls every 2s, reacts within 2s.
--   2. Fall back to lfs mtime polling every 5 minutes if inotify is absent.
--      Documented as a known compromise (battery vs. reactivity trade-off).
--
-- Returns a watcher object. Call watcher:stop() when Tomo™ is unloaded or
-- when watching is no longer needed, to cancel the UIManager schedule.
--
-- `callback` signature: callback(book_or_nil)
--   book_or_nil -- the new current book table, or nil if no book is active
function Library.watchForChange(callback)
    -- UIManager is required here because this function installs a recurring
    -- scheduled task into KOReader's event loop. This is appropriate: the
    -- file-watch lifecycle is tied to the plugin's active session.
    local UIManager = require("ui/uimanager")

    -- The last ContentID we reported to the caller.
    -- Starts as a sentinel that cannot match any real ContentID.
    local last_content_id = false   -- false ≠ nil; distinguishes "not yet checked"

    -- Kindle (and the KOReader emulator) have no KoboReader.sqlite, so fall
    -- back to KOReader's open-document API. Giving the fallback a content_id
    -- (the document file path) lets the change-detection dedup below work
    -- for it too -- otherwise book changes after launch are invisible on
    -- devices without the Kobo database.
    local function readerUIBook()
        local book
        pcall(function()
            local ReaderUI = require("apps/reader/readerui")
            local instance = ReaderUI.instance
            if instance and instance.document then
                book = Library.bookFromDocument(instance.document)
            end
        end)
        return book
    end

    -- Re-query the database and fire the callback if the book changed.
    -- Fires on startup (initial population) and again whenever the WAL changes.
    -- Runs from KOReader's scheduler, so the whole body is protected.
    local function checkForBookChange()
        local ok_q, book = pcall(function()
            return Library.getCurrentBook() or readerUIBook()
        end)
        if not ok_q then
            local ok_log, logger = pcall(require, "logger")
            if ok_log then logger.warn("Tomo Library: book query failed: " .. tostring(book)) end
            return
        end
        local current_id = book and book.content_id or nil

        if current_id ~= last_content_id then
            last_content_id = current_id
            pcall(callback, book)   -- protect the caller from crashing the loop
        end
    end

    -- Attempt inotify first. on_change = checkForBookChange so each WAL event
    -- triggers an immediate re-query. The 2s poll keeps memory pressure near zero.
    local inotify = tryInotify(checkForBookChange)

    -- The returned handle. _stopped gates both the inotify fd and the schedule.
    local handle = { _stopped = false }

    local poll_fn

    if inotify then
        -- inotify path: call poll() every 2 seconds.
        -- poll() reads the non-blocking fd and fires on_change if events exist.
        poll_fn = function()
            if handle._stopped then return end
            pcall(inotify.poll, inotify)
            UIManager:scheduleIn(2, poll_fn)
        end
    else
        -- Fallback: compare WAL mtime every 5 minutes.
        -- Less responsive but battery-safe when inotify syscall is missing.
        -- SKILLS.md §3.4 documents this as the accepted fall-back behaviour.
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if not ok_lfs then
            -- lfs also unavailable -- we cannot watch at all on this build.
            -- Return a no-op handle so callers do not need to nil-check.
            handle.stop = function() end
            -- Still do the initial check so the caller gets an initial value.
            checkForBookChange()
            return handle
        end

        local last_mtime = 0
        poll_fn = function()
            if handle._stopped then return end
            local ok_attr, attr = pcall(lfs.attributes, KOBO_WAL_PATH)
            if not ok_attr then attr = nil end
            if attr and type(attr.modification) == "number" and attr.modification > last_mtime then
                last_mtime = attr.modification
                checkForBookChange()
            elseif not attr then
                -- No WAL file on this device (Kindle, emulator). The mtime
                -- gate can never fire, so re-check directly -- the ReaderUI
                -- fallback inside checkForBookChange picks up book changes.
                checkForBookChange()
            end
            UIManager:scheduleIn(300, poll_fn)
        end
    end

    function handle:stop()
        if self._stopped then return end
        self._stopped = true
        pcall(UIManager.unschedule, UIManager, poll_fn)
        if inotify then
            pcall(inotify.stop, inotify)
        end
    end

    -- Fire immediately so the caller has a current book value before the first
    -- WAL change. This is the synchronous initial population.
    checkForBookChange()

    -- Start the recurring poll.
    UIManager:scheduleIn(inotify and 2 or 300, poll_fn)

    return handle
end

return Library
