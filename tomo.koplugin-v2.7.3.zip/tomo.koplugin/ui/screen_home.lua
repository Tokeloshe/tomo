-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_home.lua
-- v2.0 -- The ONE home screen. No scrolling. Everything visible at once.
--
-- Layout (1264×1680 display, ~1600px usable):
--   友 tomo    春分 · Vernal equinox    [shelf]     ~60px
--   ─────────────────────────────────────────       ~6px
--   READING NOW                                     ~18px
--   Book Title                                      ~22px
--   Author Name                                     ~18px
--   Others are here → (if book room)                ~18px
--   ─────────────────────────────────────────       ~6px
--   ◎ Fantasy & Sci-Fi    ·                         ~36px × 8 = 288px
--   ◎ Romance
--   ◎ Literary Fiction
--   ◎ Thriller & Mystery
--   ◎ Non-Fiction
--   ◎ Horror
--   ◎ Historical Fiction
--   ◎ Young Adult
--   ─────────────────────────────────────────       ~6px  (if book rooms)
--   BOOK ROOMS
--   ◎ Dune · a few readers                          ~36px × N
--   ─────────────────────────────────────────
--   ✦ Pen pal → (stylus only)                       ~36px
--
-- Total: ~60+6+18+22+18+6+288+6+36 ≈ 460px. Fits easily.
-- Navigation: tap room → open room. [shelf] → profile dialog. Swipe right → close.

local InputContainer    = require("ui/widget/container/inputcontainer")
local FrameContainer    = require("ui/widget/container/framecontainer")
local CenterContainer   = require("ui/widget/container/centercontainer")
local VerticalGroup     = require("ui/widget/verticalgroup")
local TextWidget        = require("ui/widget/textwidget")
local Button            = require("ui/widget/button")
local GestureRange      = require("ui/gesturerange")
local Geom              = require("ui/geometry")
local UIManager         = require("ui/uimanager")
local Device            = require("device")
local Screen            = Device.screen
local Blitbuffer        = require("ffi/blitbuffer")
local VerticalSpan      = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")
local Seasons    = require("core/seasons")

local ScreenHome = InputContainer:extend{
    name  = "tomo_home",
    dimen = nil,
    tomo  = nil,
}

function ScreenHome:init()
    self.dimen = Screen:getSize()
    local device_profile = require("core/device").getProfile()
    self._device = device_profile
    self._width  = self.dimen.w - Theme.space.md * 2

    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

function ScreenHome:_build()
    local tomo   = self.tomo
    local state  = tomo.state
    local w      = self._width
    local dw     = self.dimen.w
    local dh     = self.dimen.h

    -- Background
    local bg = Theme.pageBg(self._device, state.season and state.season.season)
        or Blitbuffer.COLOR_WHITE

    -- Detect book room for current book
    self._book_room = nil
    if state.current_book and state.current_book.isbn then
        for _, r in ipairs(state.rooms) do
            if r.kind == "book" and r.isbn == state.current_book.isbn then
                self._book_room = r
                break
            end
        end
    end

    -- ── Header (one line: logo + sekki + shelf) ──────────────────────────────
    local greeting = state.season and Seasons.greeting() or ""
    local header = Components.homeHeader(function()
        self:_openProfile()
    end, dw, greeting, function()
        self:_showSekkiPopup()
    end)

    -- ── One-page fit, NO scrolling, on every device ──────────────────────────
    -- The home is a single still page: no scrollbars, nothing off-screen.
    -- Three spacing profiles are tried in order; the first whose measured
    -- stack fits the screen wins. Book rooms are appended only while they
    -- fit -- the Conservatory holds the full list, that is what it is for.
    local PROFILES = {
        { link_pad = Theme.tap.pad,   row_pad = Theme.scaled(4), div_pad = 3 },
        { link_pad = Theme.scaled(4), row_pad = Theme.scaled(2), div_pad = 2 },
        { link_pad = Theme.scaled(1), row_pad = 0,               div_pad = 1 },
    }

    local function makeDivider(m)
        return FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_right = Theme.space.md,
            padding_top = m.div_pad,
            padding_bottom = m.div_pad,
            Components.divider(w, self._device),
        }
    end

    local function widgetH(widget)
        local ok, size = pcall(function() return widget:getSize() end)
        return (ok and size and size.h) or 0
    end

    local function sumH(list)
        local h = 0
        for _, widget in ipairs(list) do h = h + widgetH(widget) end
        return h
    end

    -- Build the fixed skeleton (everything except book rooms) plus the
    -- book-room candidates for one spacing profile. Fresh widgets per call.
    local function buildParts(m)
        local parts = {}
        parts[#parts + 1] = header
        parts[#parts + 1] = makeDivider(m)
        parts[#parts + 1] = self:_buildBookSection(state.current_book, w, m)
        parts[#parts + 1] = makeDivider(m)
        parts[#parts + 1] = self:_buildGenreRooms(state.rooms, w, m)
        parts[#parts + 1] = makeDivider(m)
        parts[#parts + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Button:new{
                text           = "Conservatory",
                text_font_face = "cfont",
                text_font_size = Theme.font.size.body,
                bordersize     = 0,
                padding        = 0,
                padding_v      = m.link_pad,
                align          = "left",
                callback       = function() self:_openConservatory() end,
            },
        }
        if self._device.can_draw then
            parts[#parts + 1] = makeDivider(m)
            parts[#parts + 1] = self:_buildPenpalSection(w, m)
            parts[#parts + 1] = FrameContainer:new{
                bordersize = 0,
                padding_left = Theme.space.md,
                Button:new{
                    text           = "Letters received",
                    text_font_face = "cfont",
                    text_font_size = Theme.font.size.small,
                    bordersize     = 0,
                    padding        = 0,
                    padding_v      = m.link_pad,
                    align          = "left",
                    callback       = function() self:_openMessages() end,
                },
            }
        end
        if state.has_failed_messages then
            parts[#parts + 1] = VerticalSpan:new{ width = Theme.space.sm }
            parts[#parts + 1] = FrameContainer:new{
                bordersize = 0,
                padding_left = Theme.space.md,
                Components.failedNotice(function()
                    self:_openFailedMessages()
                end, w, m.link_pad),
            }
        end

        -- Book-room candidates: [1] is the divider+section header, the rest
        -- are one row each. Included greedily by the fit loop below.
        local book_parts = self:_buildBookRoomParts(state.rooms, w, m)
        return parts, book_parts
    end

    local content
    for pass = 1, #PROFILES do
        local m = PROFILES[pass]
        local parts, book_parts = buildParts(m)
        local base_h = sumH(parts)

        if base_h <= dh or pass == #PROFILES then
            -- Add book rooms only while the page still fits. The header
            -- piece goes in only when at least one row made it.
            if #book_parts > 1 then
                local budget = dh - base_h - widgetH(book_parts[1])
                local rows = {}
                for i = 2, #book_parts do
                    local rh = widgetH(book_parts[i])
                    if budget - rh < 0 then break end
                    budget = budget - rh
                    rows[#rows + 1] = book_parts[i]
                end
                if #rows > 0 then
                    -- Insert after the genre section (position 5 = genre
                    -- rooms; header piece carries its own divider).
                    local insert_at = 6
                    table.insert(parts, insert_at, book_parts[1])
                    for i, row in ipairs(rows) do
                        table.insert(parts, insert_at + i, row)
                    end
                end
            end

            content = VerticalGroup:new{ align = "left" }
            for _, part in ipairs(parts) do
                content[#content + 1] = part
            end
            break
        end
    end

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        content,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Book section: title + author on compact lines
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenHome:_buildBookSection(book, w, m)
    local group = VerticalGroup:new{ align = "left" }

    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        Components.sectionHeader("Reading now", w),
    }

    if book then
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.xs,
            TextWidget:new{
                text      = book.title or "",
                face      = Theme.face(Theme.font.size.room),
                bold      = true,
                max_width = w,
            },
        }
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.xs,
            TextWidget:new{
                text      = book.author or "",
                face      = Theme.face(Theme.font.size.small),
                max_width = w,
                fgcolor   = Theme.blitColor(Theme.color.text_secondary),
            },
        }

        if self._book_room then
            group[#group + 1] = FrameContainer:new{
                bordersize = 0,
                padding_left = Theme.space.md,
                padding_top  = Theme.space.xs,
                Components.othersHere(function()
                    self:_openRoom(self._book_room)
                end, w, m and m.link_pad),
            }
        end
    else
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.xs,
            TextWidget:new{
                text      = "Nothing open yet.",
                face      = Theme.face(Theme.font.size.body),
                max_width = w,
                fgcolor   = Theme.blitColor(Theme.color.text_whisper),
            },
        }
    end

    return group
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Genre rooms: all 8, always visible, compact 36px rows
-- ─────────────────────────────────────────────────────────────────────────────

-- Static genre room list (canonical order from MASTERPLAN.md).
local GENRE_ROOMS = {
    { name = "Fantasy & Sci-Fi",   genre_tag = "fantasy-scifi" },
    { name = "Romance",            genre_tag = "romance"        },
    { name = "Literary Fiction",   genre_tag = "literary"       },
    { name = "Thriller & Mystery", genre_tag = "thriller"       },
    { name = "Non-Fiction",        genre_tag = "nonfiction"     },
    { name = "Horror",             genre_tag = "horror"         },
    { name = "Historical Fiction", genre_tag = "historical"     },
    { name = "Young Adult",        genre_tag = "ya"             },
}

function ScreenHome:_buildGenreRooms(rooms, w, m)
    local group = VerticalGroup:new{ align = "left" }

    -- Section header
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        padding_bottom = Theme.space.xs,
        Components.sectionHeader("Rooms", w),
    }

    for _, gr in ipairs(GENRE_ROOMS) do
        -- Find matching room in state by genre_tag
        local room_id = nil
        local has_new = false
        local room_data = nil
        for _, r in ipairs(rooms) do
            if r.genre_tag == gr.genre_tag then
                room_id = r.id
                has_new = r.has_new or false
                room_data = r
                break
            end
        end

        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Components.roomRow{
                name           = gr.name,
                slug           = gr.genre_tag,
                genre_tag      = gr.genre_tag,
                has_new        = has_new,
                is_joined      = room_id ~= nil,
                width          = w,
                pad_v          = m and m.row_pad,
                device_profile = self._device,
                on_tap         = function()
                    self:_openRoom(room_data or {
                        id        = room_id,
                        name      = gr.name,
                        slug      = "genre-" .. gr.genre_tag,
                        genre_tag = gr.genre_tag,
                        kind      = "genre",
                    })
                end,
            },
        }
    end

    return group
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Book rooms: dynamic, shown below genre rooms
-- ─────────────────────────────────────────────────────────────────────────────

-- Returns an array for the fit loop in _build: [1] is the divider plus
-- section header, each following element is one tappable room row. Empty
-- when no book rooms are active. The caller includes only what fits; the
-- Conservatory screen lists every book room regardless.
function ScreenHome:_buildBookRoomParts(rooms, w, m)
    local book_rooms = {}
    for _, r in ipairs(rooms) do
        if r.kind == "book" then
            book_rooms[#book_rooms + 1] = r
        end
    end
    if #book_rooms == 0 then return {} end

    local parts = {}
    parts[1] = VerticalGroup:new{
        align = "left",
        FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_right = Theme.space.md,
            padding_top = m.div_pad,
            padding_bottom = m.div_pad,
            Components.divider(w, self._device),
        },
        FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_bottom = Theme.space.xs,
            Components.sectionHeader("Book rooms", w),
        },
    }

    for _, room in ipairs(book_rooms) do
        parts[#parts + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Components.roomRow{
                name           = room.name or "Book room",
                slug           = room.slug,
                has_new        = room.has_new or false,
                is_joined      = true,
                width          = w,
                pad_v          = m and m.row_pad,
                device_profile = self._device,
                on_tap         = function()
                    self:_openRoom(room)
                end,
            },
        }
    end

    return parts
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Pen pal section: shows matched pen pal or "find a pen pal" link
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenHome:_buildPenpalSection(w, m)
    local group = VerticalGroup:new{ align = "left" }

    -- Section header
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        padding_bottom = Theme.space.xs,
        Components.sectionHeader("Pen Pal", w),
    }

    local partner_name = self.tomo.state.penpal_partner_name

    if partner_name then
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Button:new{
                text           = partner_name,
                text_font_face = "cfont",
                text_font_bold = false,
                text_font_size = Theme.font.size.room,
                bordersize     = 0,
                padding        = 0,
                padding_v      = (m and m.link_pad) or Theme.tap.pad,
                align          = "left",
                callback       = function() self:_openPenpal() end,
            },
        }
    else
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Button:new{
                text           = "Find a reader to write to",
                text_font_face = "cfont",
                text_font_size = Theme.font.size.body,
                bordersize     = 0,
                padding        = 0,
                padding_v      = (m and m.link_pad) or Theme.tap.pad,
                align          = "left",
                callback       = function() self:_openPenpal() end,
            },
        }
    end

    -- Postcrossing
    local pc_stats = self.tomo.state.postcrossing_stats
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        Button:new{
            text           = "Send a letter to a stranger",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 0,
            padding        = 0,
            padding_v      = (m and m.link_pad) or Theme.tap.pad,
            align          = "left",
            callback       = function() self:_openPostcrossingCanvas() end,
        },
    }
    if pc_stats and (pc_stats.sent > 0 or pc_stats.received > 0) then
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md + Theme.space.lg,
            TextWidget:new{
                text      = "Letters sent: " .. tostring(pc_stats.sent)
                    .. "  ·  Letters received: " .. tostring(pc_stats.received),
                face      = Theme.face(Theme.font.size.whisper),
                fgcolor   = Theme.blitColor(Theme.color.text_whisper),
                max_width = w - Theme.space.lg,
            },
        }
    end

    return group
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Data loading
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenHome:_refreshUnread()
    local tomo  = self.tomo
    local state = tomo.state
    if not state.online or not state.user then return end

    local room_ids = {}
    for _, room in ipairs(state.rooms) do
        if room.id then
            room_ids[#room_ids + 1] = room.id
        end
    end
    if #room_ids == 0 then return end

    tomo._sync:checkUnread(state.user.id, room_ids, function(unread_map)
        local changed = false
        for _, room in ipairs(state.rooms) do
            if room.id then
                local new_val = unread_map[room.id] or false
                if room.has_new ~= new_val then
                    room.has_new = new_val
                    changed = true
                end
            end
        end
        if changed then
            self:_rebuild()
        end
    end)
end

-- Load pen pal bond state (for home screen display)
function ScreenHome:_loadPenpalState()
    if not self._device.has_stylus then return end
    local tomo = self.tomo
    if not tomo.state.online or not tomo.state.user then return end

    tomo._api:getPenpalBond(tomo.state.user.id, function(err, bond)
        if err or not bond then
            tomo.state.penpal_partner_name = nil
            return
        end
        local partner_id = bond.user_a == tomo.state.user.id and bond.user_b or bond.user_a
        tomo._api:getUserProfile(partner_id, function(err2, profile)
            if not err2 and profile then
                tomo.state.penpal_partner_name = profile.username
                self:_rebuild()
            end
        end)
    end)
end

-- Load postcrossing stats
function ScreenHome:_loadPostcrossingStats()
    if not self._device.has_stylus then return end
    local tomo = self.tomo
    if not tomo.state.online or not tomo.state.user then return end

    tomo._api:getPostcrossingStats(function(err, stats)
        if not err and stats then
            tomo.state.postcrossing_stats = stats
            self:_rebuild()
        end
    end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Widget lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenHome:onShow()
    -- Update season in case the app was open across midnight.
    self.tomo.state.season = Seasons.current()

    -- Rebuild if rooms count changed.
    local current_rooms = self.tomo.state.rooms or {}
    if #current_rooms ~= (self._last_rooms_count or 0) then
        self._last_rooms_count = #current_rooms
        self:_build()
    end

    self:_refreshUnread()
    self:_loadPenpalState()
    self:_loadPostcrossingStats()

    -- Debug: log rendered positions of all buttons in the widget tree
    if os.getenv("TOMO_AUTO_TEST") == "1" then
        UIManager:scheduleIn(0.5, function()
            local ok, err = pcall(function()
                if not self or not self[1] then return end
                local logger = require("logger")
                local function findButtons(w, depth)
                    if type(w) ~= "table" or depth > 8 then return end
                    if w.text and w.callback and w.dimen then
                        logger.warn(string.format("TAPTEST_BTN: '%s' dimen=(%d,%d,%d,%d)",
                            tostring(w.text):sub(1, 40),
                            w.dimen.x or 0, w.dimen.y or 0,
                            w.dimen.w or 0, w.dimen.h or 0))
                    end
                    for i = 1, 40 do
                        if w[i] then findButtons(w[i], depth + 1) else break end
                    end
                end
                findButtons(self, 0)
            end)
            if not ok then
                local logger = require("logger")
                logger.warn("Tomo: scheduled callback error: " .. tostring(err))
            end
        end)
    end

    UIManager:setDirty(self, "full")
    return true
end

function ScreenHome:onCloseWidget()
    -- Nothing to clean up: library watcher is managed by tomo.lua.
end

-- Guard against suspend/resume destroying widget state.
-- If self[1] is nil after resume, the widget tree is broken and ipairs(self)
-- in KOReader's InputContainer:handleEvent will crash with "table expected, got nil".
function ScreenHome:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo Home: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenHome:onSwipe(_, ges)
    local direction = ges.direction
    -- Swipe right or down from Home → close Tomo entirely, return to KOReader.
    if direction == "east" or direction == "south" then
        self:onClose()
        return true
    end
end

function ScreenHome:onClose()
    local Recorder = require("core/recorder")
    Recorder.log("NAV", "Closing Tomo from home screen")
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    return true
end

function ScreenHome:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Navigation
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenHome:_openRoom(room)
    if not room then return end
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "room '" .. tostring(room.name) .. "'")
    Recorder.log("NAV", "opened room")

    local ScreenRoom = require("ui/screen_room")
    UIManager:show(ScreenRoom:new{
        tomo      = self.tomo,
        room_id   = room.id,
        genre_tag = room.genre_tag,
        _room     = room,
    })

    -- Auto-join the room in background
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if room.id and user_id and self.tomo.state.online then
        UIManager:scheduleIn(0.1, function()
            local ok, err = pcall(function()
                if not self or not self.tomo then return end
                self.tomo._api:joinRoom(room.id, user_id, function() end)
            end)
            if not ok then
                local logger = require("logger")
                logger.warn("Tomo: scheduled callback error: " .. tostring(err))
            end
        end)
    end
end

function ScreenHome:_openProfile()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "[shelf]")
    Recorder.log("NAV", "opened profile dialog")

    local ScreenProfile = require("ui/screen_profile")
    UIManager:show(ScreenProfile:new{ tomo = self.tomo })
end

function ScreenHome:_openPenpal()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "pen pal")
    local ScreenPenpal = require("ui/screen_penpal")
    UIManager:show(ScreenPenpal:new{ tomo = self.tomo })
end

function ScreenHome:_showSekkiPopup()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "sekki greeting")
    local ctx = Seasons.getContext()
    if not ctx then return end

    local MONTH_NAMES = {
        "January","February","March","April","May","June",
        "July","August","September","October","November","December",
    }

    local TextBoxWidget = require("ui/widget/textboxwidget")

    local dw = self.dimen.w
    local dh = self.dimen.h
    local card_w = math.floor(dw * 0.75)
    -- The interior width must match the card's actual padding, or the
    -- content renders wider than the padded frame.
    local card_pad = Theme.scaled(24)
    local inner_w = card_w - card_pad * 2

    local function sekkiBlock(label, s, is_current)
        local face_label = Theme.face(Theme.font.size.whisper)
        local face_kanji = Theme.face(Theme.font.size.room)
        local face_detail = Theme.face(Theme.font.size.body)
        local grey = Theme.blitColor(Theme.color.text_whisper)
        local blk = nil  -- default (black)

        local block = VerticalGroup:new{ align = "left" }
        -- Breathing room before each section
        block[#block + 1] = VerticalSpan:new{ width = Theme.space.xl }
        block[#block + 1] = TextWidget:new{
            text = label, face = face_label,
            fgcolor = is_current and blk or grey,
            bold = is_current,
        }
        block[#block + 1] = TextWidget:new{
            text = s.kanji .. " " .. s.romaji,
            face = face_kanji, bold = is_current,
        }
        block[#block + 1] = TextWidget:new{
            text = s.english, face = face_detail,
            fgcolor = is_current and blk or grey,
        }
        block[#block + 1] = TextWidget:new{
            text = "~ " .. (MONTH_NAMES[s.month] or tostring(s.month)) .. " " .. tostring(s.day),
            face = Theme.face(Theme.font.size.whisper),
            fgcolor = grey,
        }
        return block
    end

    -- Header slots follow the measured text height. Fixed 28-30px slots
    -- are shorter than the scaled text everywhere above 600x800, and
    -- CenterContainer overdraws its neighbours when the child is taller.
    local kanji_tw = TextWidget:new{
        text = "\xE4\xBA\x8C\xE5\x8D\x81\xE5\x9B\x9B\xE7\xAF\x80\xE6\xB0\x97",
        face = Theme.face(Theme.font.size.room),
    }
    local title_tw = TextWidget:new{
        text = "The 24 Sekki",
        face = Theme.face(Theme.font.size.title), bold = true,
    }

    local content = VerticalGroup:new{ align = "center" }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.md }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = inner_w, h = kanji_tw:getSize().h },
        kanji_tw,
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.lg }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = inner_w, h = title_tw:getSize().h },
        title_tw,
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.lg }
    content[#content + 1] = TextBoxWidget:new{
        text = "Tomo follows the ancient Japanese\ncalendar of 24 micro-seasons, each\nmarking a shift in the natural world.",
        face = Theme.face(Theme.font.size.small),
        width = inner_w,
        alignment = "center",
        fgcolor = Theme.blitColor(Theme.color.text_whisper),
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.md }
    content[#content + 1] = Components.divider(inner_w, self._device)
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.md }
    content[#content + 1] = sekkiBlock("Previous", ctx.prev, false)
    content[#content + 1] = sekkiBlock("Current", ctx.current, true)
    content[#content + 1] = sekkiBlock("Next", ctx.next, false)

    local card = FrameContainer:new{
        width      = card_w,
        bordersize = 1,
        padding    = card_pad,
        background = Blitbuffer.COLOR_WHITE,
        content,
    }

    -- Full-screen overlay that dismisses on any tap.
    -- CRITICAL: Must use InputContainer:new (not :extend) so self[1] is set
    -- on the INSTANCE, not on a class table. :extend creates a class without
    -- copying numeric keys, so ipairs(self) gets nil and crashes at
    -- inputcontainer.lua:257.
    local overlay = FrameContainer:new{
        width = dw, height = dh, bordersize = 0, padding = 0,
        background = Blitbuffer.Color8(0xCC),
        CenterContainer:new{
            dimen = Geom:new{ w = dw, h = dh },
            card,
        },
    }
    local popup = InputContainer:new{
        name  = "tomo_sekki_popup",
        dimen = Geom:new{ w = dw, h = dh },
    }
    popup[1] = overlay
    popup.ges_events = {
        Tap = { GestureRange:new{ ges = "tap", range = popup.dimen } },
    }
    function popup:onTap()
        UIManager:close(self)
        UIManager:setDirty(nil, "ui")
        return true
    end

    UIManager:show(popup)
    UIManager:setDirty(popup, "flashui")
end

function ScreenHome:_openConservatory()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "conservatory")
    local ScreenConservatory = require("ui/screen_conservatory")
    UIManager:show(ScreenConservatory:new{ tomo = self.tomo })
end

function ScreenHome:_openMessages()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "messages inbox")
    local ScreenMessages = require("ui/screen_messages")
    UIManager:show(ScreenMessages:new{ tomo = self.tomo })
end

function ScreenHome:_openPostcrossingCanvas()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "postcrossing")
    local ScreenCanvas = require("ui/screen_canvas")
    UIManager:show(ScreenCanvas:new{
        tomo            = self.tomo,
        room_id         = nil,
        partner_name    = nil,
        is_postcrossing = true,
        on_send         = function()
            -- Refresh postcrossing stats
            self:_loadPostcrossingStats()
        end,
    })
end

function ScreenHome:_openFailedMessages()
    local ConfirmBox = require("ui/widget/confirmbox")
    local failed = self.tomo._cache:getFailedMessages()
    if #failed == 0 then return end

    local item = failed[1]
    -- utf8Truncate: a byte-boundary :sub can split a multi-byte character
    -- and hand the text stack an invalid UTF-8 sequence.
    local preview = item.body and Components.utf8Truncate(item.body, 60) or "[ink letter]"

    UIManager:show(ConfirmBox:new{
        text = "Could not send: \"" .. preview .. "\"\n\nTry again or let it go?",
        ok_text = "Try again",
        cancel_text = "Let it go",
        ok_callback = function()
            self.tomo._cache:retryFailed(item.id)
            if self.tomo.state.online then
                self.tomo._sync:flushOutbox()
            end
        end,
        cancel_callback = function()
            self.tomo._cache:discardFailed(item.id)
            local remaining = self.tomo._cache:getFailedMessages()
            self.tomo.state.has_failed_messages = #remaining > 0
            self:_rebuild()
        end,
    })
end

return ScreenHome
