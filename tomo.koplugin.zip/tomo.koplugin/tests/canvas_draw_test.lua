-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- tests/canvas_draw_test.lua
-- v2.7.0 -- Static canvas architecture tests.
-- Validates throttle logic, dirty rect accumulation, nil guards, and colour
-- helpers by checking the source code patterns and running pure-Lua simulations.
-- Does NOT require KOReader runtime -- runs with plain Lua 5.3.

local pass, fail = 0, 0
local function PASS(msg) pass = pass + 1; print("CANVAS TEST PASS: " .. msg) end
local function FAIL(msg) fail = fail + 1; print("CANVAS TEST FAIL: " .. msg) end

print("=== TOMO v2.7.0 CANVAS DRAW TESTS ===")

-- Helper: read a file
local function readFile(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local c = f:read("*a"); f:close()
    return c
end

local canvas_src = readFile("plugin/ui/screen_canvas.lua")
local cache_src = readFile("plugin/core/cache.lua")
local room_src = readFile("plugin/ui/screen_room.lua")
local api_src = readFile("plugin/core/api.lua")

if not canvas_src then print("ERROR: cannot read screen_canvas.lua"); os.exit(1) end

-- TEST 1: THROTTLED REFRESH COUNT
-- Simulate 1000 pan events at 1ms intervals. With 16ms throttle, expect ~62 refreshes.
do
    local REFRESH_INTERVAL = 0.008
    local refresh_count = 0
    local last_refresh_time = 0
    local pending = nil

    for i = 1, 1000 do
        local now = i * 0.001  -- 1ms per event
        -- Expand pending (simulate _expandPendingRefresh)
        pending = pending or { x = 0, y = 0, w = 10, h = 10 }
        -- Throttle check (simulate _doThrottledRefresh)
        if (now - last_refresh_time) >= REFRESH_INTERVAL then
            if pending then
                refresh_count = refresh_count + 1
                pending = nil
            end
            last_refresh_time = now
        end
    end

    if refresh_count <= 150 then
        PASS("T1: throttle count=" .. refresh_count .. " (expected <=150, got <=150)")
    else
        FAIL("T1: throttle count=" .. refresh_count .. " (expected <=150, too many)")
    end
    if refresh_count >= 30 then
        PASS("T1b: throttle count=" .. refresh_count .. " (expected >=30, not too few)")
    else
        FAIL("T1b: throttle count=" .. refresh_count .. " (expected >=30, too few)")
    end
end

-- TEST 2: DIRTY RECT ACCUMULATION
-- Simulate 10 points within one throttle window. Verify bounding box covers all.
do
    local points = {
        {100, 200}, {120, 210}, {130, 195}, {140, 220}, {150, 200},
        {160, 230}, {170, 190}, {180, 215}, {190, 205}, {200, 210},
    }
    local pending = nil
    for _, p in ipairs(points) do
        local sx1, sy1, sx2, sy2 = p[1] - 5, p[2] - 5, p[1] + 5, p[2] + 5
        if not pending then
            pending = { x = sx1, y = sy1, w = sx2 - sx1, h = sy2 - sy1 }
        else
            local nx1 = math.min(pending.x, sx1)
            local ny1 = math.min(pending.y, sy1)
            local nx2 = math.max(pending.x + pending.w, sx2)
            local ny2 = math.max(pending.y + pending.h, sy2)
            pending.x = nx1; pending.y = ny1; pending.w = nx2 - nx1; pending.h = ny2 - ny1
        end
    end
    -- Check: rect must contain all points (with 5px margin)
    local all_covered = true
    for _, p in ipairs(points) do
        if p[1] - 5 < pending.x or p[2] - 5 < pending.y
            or p[1] + 5 > pending.x + pending.w or p[2] + 5 > pending.y + pending.h then
            all_covered = false
        end
    end
    if all_covered then
        PASS("T2: dirty rect covers all 10 points: ("
            .. pending.x .. "," .. pending.y .. "," .. pending.w .. "," .. pending.h .. ")")
    else
        FAIL("T2: dirty rect does NOT cover all points")
    end
end

-- TEST 3: PEN LIFT FLUSHES PENDING
-- Verify onPanRelease source has both refreshFast (flush pending) and refreshPartial (colour).
do
    local rel_start = canvas_src:find("function ScreenCanvas:onPanRelease", 1, true)
    local rel_end = canvas_src:find("\nend", rel_start + 100, true)
    local rel_body = canvas_src:sub(rel_start, rel_end + 4)
    local has_flush = rel_body:find("pending_refresh", 1, true) and rel_body:find("refreshFast", 1, true)
    local has_colour = rel_body:find("refreshPartial", 1, true) and rel_body:find("true", 1, true)
    if has_flush and has_colour then
        PASS("T3: onPanRelease flushes pending (refreshFast) AND does colour (refreshPartial+dither)")
    else
        FAIL("T3: onPanRelease missing flush=" .. tostring(has_flush) .. " colour=" .. tostring(has_colour))
    end
end

-- TEST 4: STROKE SEPARATION
-- Verify NEW_STROKE_DIST_SQ and distance gap logic exists in onPan.
do
    if canvas_src:find("NEW_STROKE_DIST_SQ", 1, true) then
        PASS("T4: stroke separation by distance gap exists")
    else
        FAIL("T4: NEW_STROKE_DIST_SQ not found")
    end
end

-- TEST 5: NIL ROOM_ID SAFETY
-- Verify cache.lua:enqueue has nil room_id guard.
do
    local pos = cache_src:find("function Cache:enqueue", 1, true)
    local chunk = cache_src:sub(pos, pos + 300)
    if chunk:find("not room_id") then
        PASS("T5: cache:enqueue has nil room_id guard")
    else
        FAIL("T5: cache:enqueue missing nil room_id guard")
    end
    -- Also verify screen_room:_sendMessage has guard
    local spos = room_src:find("function ScreenRoom:_sendMessage", 1, true)
    local schunk = room_src:sub(spos, spos + 300)
    if schunk:find("not self.room_id") then
        PASS("T5b: screen_room:_sendMessage has nil room_id guard")
    else
        FAIL("T5b: screen_room:_sendMessage missing nil room_id guard")
    end
end

-- TEST 6: COLOUR SWATCH RENDERING
-- Verify paintTo paints a real coloured rectangle for the swatch.
do
    if canvas_src:find("swatch_color", 1, true) and canvas_src:find("ColorRGB32(sr, sg, sb", 1, true) then
        PASS("T6: paintTo paints real RGB swatch rectangle")
    else
        FAIL("T6: paintTo missing swatch_color RGB paint")
    end
    -- Verify colour refresh is triggered for swatch
    if canvas_src:find("_swatch_rect", 1, true) then
        PASS("T6b: swatch colour refresh scheduled via _swatch_rect")
    else
        FAIL("T6b: missing _swatch_rect colour refresh")
    end
end

-- TEST 7: SCREEN.BB DIRECT WRITE
-- Verify onPan writes to both _canvas_bb AND screen_bb.
do
    local pan_start = canvas_src:find("function ScreenCanvas:onPan", 1, true)
    local pan_end = canvas_src:find("\nend", pan_start + 100, true)
    local pan_body = canvas_src:sub(pan_start, pan_end)
    if pan_body:find("self._canvas_bb") and pan_body:find("screen_bb") then
        PASS("T7: onPan writes to both _canvas_bb and screen_bb")
    else
        FAIL("T7: onPan missing dual-buffer writes")
    end
end

-- TEST 8: FULL STROKE LIFECYCLE
-- Verify: _redrawCanvas replays strokes, _getContentBounds works, _exportToPNG exists.
do
    local has_redraw = canvas_src:find("function ScreenCanvas:_redrawCanvas", 1, true) ~= nil
    local has_bounds = canvas_src:find("function ScreenCanvas:_getContentBounds", 1, true) ~= nil
    local has_export = canvas_src:find("function ScreenCanvas:_exportToPNG", 1, true) ~= nil
    if has_redraw and has_bounds and has_export then
        PASS("T8: full lifecycle: _redrawCanvas + _getContentBounds + _exportToPNG all exist")
    else
        FAIL("T8: missing lifecycle methods: redraw=" .. tostring(has_redraw)
            .. " bounds=" .. tostring(has_bounds) .. " export=" .. tostring(has_export))
    end
end

-- TEST 9: THROTTLE CONSTANT AND METHOD EXIST IN SOURCE
do
    if canvas_src:find("REFRESH_INTERVAL", 1, true) then
        PASS("T9: REFRESH_INTERVAL constant exists")
    else
        FAIL("T9: REFRESH_INTERVAL missing")
    end
    if canvas_src:find("_doThrottledRefresh", 1, true) then
        PASS("T9b: _doThrottledRefresh method exists")
    else
        FAIL("T9b: _doThrottledRefresh missing")
    end
end

-- TEST 10: ALL API ROOM_ID GUARDS
do
    local funcs = {"joinRoom", "markRead", "getMessages", "getOlderMessages",
                   "sendMessage", "sendInkMessage", "getDeliveredLetters",
                   "hasLettersInTransit", "sendInkLetter"}
    local all_ok = true
    for _, fn in ipairs(funcs) do
        local pos = api_src:find("function Api:" .. fn, 1, true)
        if pos then
            local chunk = api_src:sub(pos, pos + 200)
            if not chunk:find("room_id is nil") then
                all_ok = false
                print("  MISSING guard: Api:" .. fn)
            end
        end
    end
    if all_ok then
        PASS("T10: all 9 api.lua room_id guards present")
    else
        FAIL("T10: some api.lua room_id guards missing")
    end
end

-- TEST 11: VERSION
do
    local main_src = readFile("plugin/main.lua")
    if main_src:find('"2.7.0"', 1, true) then
        PASS("T11: version is 2.7.0")
    else
        FAIL("T11: version is NOT 2.7.0")
    end
end

-- TEST 12: COPYRIGHT HEADERS
do
    local files = {
        "plugin/ui/screen_canvas.lua", "plugin/core/api.lua",
        "plugin/core/cache.lua", "plugin/ui/screen_room.lua", "plugin/main.lua",
    }
    local all_ok = true
    for _, path in ipairs(files) do
        local c = readFile(path)
        if not c or not c:find("2026 James Edward Honiball", 1, true) then
            all_ok = false; print("  MISSING copyright: " .. path)
        end
    end
    if all_ok then PASS("T12: all files have copyright")
    else FAIL("T12: missing copyrights") end
end

print("")
print("========================================")
print("RESULTS: " .. pass .. " PASS, " .. fail .. " FAIL")
print("========================================")
os.exit(fail > 0 and 1 or 0)
