-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- tests/tap_test.lua
-- v2.1.5 -- Automated tap test with pen pal flow + canvas/colour/timestamp tests.
-- Uses internal KOReader Gesture simulation.

local UIManager = require("ui/uimanager")
local Screen    = require("device").screen
local Geom      = require("ui/geometry")
local Event     = require("ui/event")
local logger    = require("logger")

local TapTest = {}

local function log(msg) logger.warn("TAPTEST: " .. msg) end

local function sendTap(x, y, label)
    log("TAP at (" .. x .. ", " .. y .. ") -- " .. label)
    UIManager:sendEvent(Event:new("Gesture", {
        ges = "tap",
        pos = Geom:new{ x = x, y = y, w = 1, h = 1 },
        time = { sec = os.time(), usec = 0 },
    }))
end

local function sendSwipe(x, y, direction, label)
    log("SWIPE " .. direction .. " at (" .. x .. ", " .. y .. ") -- " .. label)
    UIManager:sendEvent(Event:new("Gesture", {
        ges = "swipe",
        pos = Geom:new{ x = x, y = y, w = 1, h = 1 },
        direction = direction,
        time = { sec = os.time(), usec = 0 },
    }))
end

local function logStack()
    local stack = UIManager._window_stack or {}
    local names = {}
    for i, entry in ipairs(stack) do
        local w = entry.widget or entry
        local name = type(w) == "table" and (w.name or tostring(w)) or "?"
        names[#names + 1] = tostring(i) .. ":" .. name
    end
    log("STACK: [" .. table.concat(names, ", ") .. "]")
end

local function isOnStack(name)
    for _, entry in ipairs(UIManager._window_stack or {}) do
        local w = entry.widget or entry
        if type(w) == "table" and w.name == name then return true end
    end
    return false
end

-- Find all buttons and log their positions
local function dumpButtons(root_name)
    for _, entry in ipairs(UIManager._window_stack or {}) do
        local w = entry.widget or entry
        if type(w) == "table" and w.name == root_name then
            local function find(widget, depth)
                if type(widget) ~= "table" or depth > 8 then return end
                if widget.text and widget.callback and widget.dimen then
                    log(string.format("  BTN[%s]: '%s' dimen=(%d,%d,%d,%d)",
                        root_name, tostring(widget.text):sub(1, 40),
                        widget.dimen.x or 0, widget.dimen.y or 0,
                        widget.dimen.w or 0, widget.dimen.h or 0))
                end
                for i = 1, 40 do
                    if widget[i] then find(widget[i], depth + 1) else break end
                end
            end
            find(w, 0)
            break
        end
    end
end

local SW, SH = 1264, 1680

function TapTest.run(tomo_state)
    log("========================================")
    log("TOMO v2.1.5 TAP TEST")
    log("========================================")

    local t = 0
    local step = 0
    local pass_count = 0
    local fail_count = 0

    local function PASS(msg) pass_count = pass_count + 1; log("PASS: " .. msg) end
    local function FAIL(msg) fail_count = fail_count + 1; log("FAIL: " .. msg) end

    local function at(delay, fn)
        t = t + delay
        step = step + 1
        local s = step
        UIManager:scheduleIn(t, function()
            log("--- STEP " .. s .. " ---")
            fn()
        end)
    end

    -- STEP 1: Home screen up + dump buttons
    at(0.5, function()
        logStack()
        if isOnStack("tomo_home") then PASS("Home screen on stack")
        else FAIL("Home NOT on stack") end
        dumpButtons("tomo_home")
    end)

    -- STEP 2: Tap [shelf] button
    at(1.0, function()
        sendTap(1208, 49, "[shelf]")
    end)

    -- STEP 3: Check profile dialog
    at(0.5, function()
        if isOnStack("tomo_profile") then PASS("[shelf] → profile opened")
        else FAIL("[shelf] → profile NOT opened") end
        -- Dismiss
        sendTap(20, 20, "dismiss profile")
    end)

    -- STEP 4: Check dismissed
    at(0.5, function()
        if not isOnStack("tomo_profile") then PASS("Profile dismissed")
        else FAIL("Profile still open") end
    end)

    -- STEP 5: Tap first genre room (Fantasy)
    -- From v2.0 test: Fantasy at dimen=(15,269,1248,62) → center y=300
    at(0.5, function()
        sendTap(300, 300, "Fantasy & Sci-Fi")
    end)

    -- STEP 6: Check room opened
    at(0.5, function()
        if isOnStack("tomo_room") then PASS("Fantasy room opened")
        else FAIL("Fantasy room NOT opened") end
    end)

    -- STEP 7: Back button in room
    at(0.3, function()
        if isOnStack("tomo_room") then
            sendTap(80, 30, "← Back in room")
        end
    end)

    -- STEP 8: Check back worked
    at(0.5, function()
        if isOnStack("tomo_home") and not isOnStack("tomo_room") then
            PASS("Back button → home")
        else
            FAIL("Back button failed")
            if isOnStack("tomo_room") then
                sendSwipe(SW/2, SH/2, "east", "swipe fallback")
            end
        end
    end)

    -- STEP 9: Test pen pal section (if stylus device)
    -- Find the pen pal button by looking at button dump
    at(1.0, function()
        log("Dumping home buttons for pen pal section...")
        dumpButtons("tomo_home")
    end)

    -- STEP 10: Tap the pen pal / "Find a reader" button
    -- Based on layout: pen pal section is after 8 genre rooms + book rooms
    -- Genre rooms end at ~y=1073 (YA at 1011+62). Pen pal section starts ~y=1100
    at(0.5, function()
        -- Search for the actual button positions
        local penpal_y = nil
        for _, entry in ipairs(UIManager._window_stack or {}) do
            local w = entry.widget or entry
            if type(w) == "table" and w.name == "tomo_home" then
                local function find(widget, depth)
                    if type(widget) ~= "table" or depth > 8 then return end
                    if widget.text and widget.callback and widget.dimen then
                        local txt = tostring(widget.text)
                        if txt:find("pen pal") or txt:find("Pen pal") or txt:find("Find a reader")
                            or txt:find("kiri") or txt:find("stranger") then
                            penpal_y = widget.dimen.y + math.floor(widget.dimen.h / 2)
                            log("Found pen pal button at y=" .. penpal_y .. " text='" .. txt:sub(1,40) .. "'")
                        end
                    end
                    for i = 1, 40 do
                        if widget[i] then find(widget[i], depth + 1) else break end
                    end
                end
                find(w, 0)
                break
            end
        end

        if penpal_y then
            sendTap(300, penpal_y, "pen pal button")
        else
            log("WARN: Could not find pen pal button, trying y=1120")
            sendTap(300, 1120, "pen pal estimated")
        end
    end)

    -- STEP 11: Check if pen pal screen opened
    at(0.5, function()
        if isOnStack("tomo_penpal") then
            PASS("Pen pal screen opened")
            dumpButtons("tomo_penpal")
        elseif isOnStack("tomo_canvas") then
            PASS("Canvas opened (postcrossing button hit)")
        else
            FAIL("Neither penpal nor canvas opened")
            logStack()
        end
    end)

    -- STEP 12: Back from pen pal
    at(0.5, function()
        if isOnStack("tomo_penpal") then
            sendSwipe(SW/2, SH/2, "east", "swipe back from penpal")
        elseif isOnStack("tomo_canvas") then
            -- Canvas has ✕ discard button at top-left
            sendTap(30, 30, "✕ discard canvas")
        end
    end)

    -- STEP 13: Back to home
    at(1.0, function()
        if isOnStack("tomo_home") then PASS("Returned to home from pen pal")
        else FAIL("Not back at home"); logStack() end
    end)

    -- STEP 14: Test postcrossing button
    at(0.5, function()
        -- Find the "Send a letter to a stranger" button
        local stranger_y = nil
        for _, entry in ipairs(UIManager._window_stack or {}) do
            local w = entry.widget or entry
            if type(w) == "table" and w.name == "tomo_home" then
                local function find(widget, depth)
                    if type(widget) ~= "table" or depth > 8 then return end
                    if widget.text and widget.callback and widget.dimen then
                        if tostring(widget.text):find("stranger") then
                            stranger_y = widget.dimen.y + math.floor(widget.dimen.h / 2)
                            log("Found postcrossing button at y=" .. stranger_y)
                        end
                    end
                    for i = 1, 40 do
                        if widget[i] then find(widget[i], depth + 1) else break end
                    end
                end
                find(w, 0)
                break
            end
        end

        if stranger_y then
            sendTap(300, stranger_y, "postcrossing button")
        else
            log("WARN: postcrossing button not found")
        end
    end)

    -- STEP 15: Check canvas opened for postcrossing
    at(0.5, function()
        if isOnStack("tomo_canvas") then
            PASS("Canvas opened for postcrossing")
            dumpButtons("tomo_canvas")
        else
            FAIL("Canvas NOT opened for postcrossing")
            logStack()
        end
    end)

    -- STEP 16: Discard canvas
    at(0.5, function()
        if isOnStack("tomo_canvas") then
            sendTap(30, 30, "✕ discard canvas")
        end
    end)

    -- STEP 17: Check back at home
    at(1.0, function()
        if isOnStack("tomo_home") and not isOnStack("tomo_canvas") then
            PASS("Canvas discarded, back at home")
        else
            FAIL("Not at home after canvas discard")
            logStack()
        end
    end)

    -- STEP 18: Canvas buffer type matches Screen.bb type
    at(0.5, function()
        log("--- NEW TEST: Canvas buffer type ---")
        local ok_bb, Blitbuffer = pcall(require, "ffi/blitbuffer")
        local ok_screen, DeviceModule = pcall(require, "device")
        if ok_bb and ok_screen then
            local ScreenObj = DeviceModule.screen
            local screen_type = ScreenObj.bb:getType()
            -- Create a test canvas the way screen_canvas does
            local test_bb = Blitbuffer.new(100, 100, screen_type)
            local canvas_type = test_bb:getType()
            test_bb:free()
            if canvas_type == screen_type then
                PASS("Canvas bb type (" .. canvas_type .. ") matches Screen.bb type (" .. screen_type .. ")")
            else
                FAIL("Canvas bb type (" .. canvas_type .. ") != Screen.bb type (" .. screen_type .. ")")
            end
        else
            FAIL("Could not load Blitbuffer/Screen for buffer type test")
        end
    end)

    -- STEP 19: Canvas toolbar_y < screen height
    at(0.3, function()
        log("--- NEW TEST: Canvas toolbar visibility ---")
        local TOPBAR_H_T  = 48
        local TOOLBAR_H_T = 80
        local ok_d, DevMod = pcall(require, "device")
        if ok_d then
            local sh = DevMod.screen:getHeight()
            local toolbar_y = sh - TOOLBAR_H_T
            if toolbar_y > 0 and toolbar_y < sh then
                PASS("toolbar_y=" .. toolbar_y .. " is within screen (h=" .. sh .. ")")
            else
                FAIL("toolbar_y=" .. toolbar_y .. " out of bounds (h=" .. sh .. ")")
            end
        else
            FAIL("Could not load Device for toolbar test")
        end
    end)

    -- STEP 20: Colour helper returns RGB on RGB buffer
    at(0.3, function()
        log("--- NEW TEST: Colour helper RGB ---")
        local ok_bb, Blitbuffer = pcall(require, "ffi/blitbuffer")
        if ok_bb then
            -- Simulate _makeColor logic for RGB32 buffer
            local r, g, b = 0x6B, 0x7F, 0xA3
            local color = Blitbuffer.ColorRGB32(r, g, b, 0xFF)
            -- Verify it's not just grey
            local rgb = color:getColorRGB32()
            if rgb.r == r and rgb.g == g and rgb.b == b then
                PASS("ColorRGB32 preserves channels: r=" .. rgb.r .. " g=" .. rgb.g .. " b=" .. rgb.b)
            else
                FAIL("ColorRGB32 lost channels: r=" .. rgb.r .. " g=" .. rgb.g .. " b=" .. rgb.b)
            end
        else
            FAIL("Could not load Blitbuffer for colour test")
        end
    end)

    -- STEP 21: Haiku edit with nil value doesn't crash
    at(0.3, function()
        log("--- NEW TEST: Haiku nil guard ---")
        -- Simulate the guard from screen_profile.lua:300-301
        local test_values = { nil, false, 0, "", "valid haiku" }
        local all_ok = true
        for _, v in ipairs(test_values) do
            local result = v
            if type(result) ~= "string" then result = "" end
            if type(result) ~= "string" then
                all_ok = false
                log("Haiku guard failed for: " .. tostring(v))
            end
        end
        -- Also test rapidjson.null equivalent (userdata)
        local ok_rj, rapidjson = pcall(require, "rapidjson")
        if ok_rj and rapidjson.null then
            local v = rapidjson.null
            local result = v
            if type(result) ~= "string" then result = "" end
            if type(result) ~= "string" then all_ok = false end
        end
        if all_ok then PASS("Haiku nil/null guard works for all types")
        else FAIL("Haiku nil guard failed") end
    end)

    -- STEP 22: All timestamps use Z not +00:00
    at(0.3, function()
        log("--- NEW TEST: Timestamp format ---")
        local ts = os.date("!%Y-%m-%dT%H:%M:%SZ")
        if ts:match("Z$") then
            PASS("os.date timestamp ends with Z: " .. ts)
        else
            FAIL("os.date timestamp does NOT end with Z: " .. ts)
        end
        -- Also verify cleanTimestamp from api.lua
        local ok_api, Api = pcall(require, "core/api")
        -- cleanTimestamp is local, so test the pattern directly
        local test_ts = "2026-03-19T21:35:47.909894+00:00"
        local cleaned = test_ts:gsub("(%d%d:%d%d:%d%d)%.%d+", "%1"):gsub("%+00:00$", "Z")
        if cleaned == "2026-03-19T21:35:47Z" then
            PASS("cleanTimestamp converts +00:00 to Z: " .. cleaned)
        else
            FAIL("cleanTimestamp failed: " .. cleaned)
        end
    end)

    -- STEP 23: Swipe right to close Tomo
    at(0.5, function()
        if isOnStack("tomo_home") then
            sendSwipe(SW/2, SH/2, "east", "close Tomo")
        end
    end)

    -- STEP 24: Verify closed
    at(0.5, function()
        if not isOnStack("tomo_home") then PASS("Tomo closed")
        else FAIL("Tomo still open") end
        logStack()
    end)

    -- STEP 25: Summary
    at(0.5, function()
        log("========================================")
        log("RESULTS: " .. pass_count .. " PASS, " .. fail_count .. " FAIL")
        log("========================================")
    end)
end

return TapTest
