-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- tests/device_compat_test.lua
-- Verifies device detection logic for 18 representative devices across all 5 tiers.
-- Runs with plain Lua 5.3 (no KOReader runtime).

local pass, fail = 0, 0
local function PASS(msg) pass = pass + 1; print("PASS: " .. msg) end
local function FAIL(msg) fail = fail + 1; print("FAIL: " .. msg) end

print("=== TOMO v2.5.0 DEVICE COMPATIBILITY TESTS ===")

local DEVICES = {
    -- TIER 2: Colour + Stylus
    {name="Kobo Libra Colour", code="Kobo_monza", w=1264, h=1680, color=true, stylus=true, cap=true, tier=2, draw="stylus", pw=4, compact=false},
    -- TIER 3: Stylus, No Colour
    {name="Kobo Sage", code="Kobo_cadmus", w=1440, h=1920, color=false, stylus=true, cap=true, tier=3, draw="stylus", pw=4, compact=false},
    {name="Kobo Elipsa", code="Kobo_europa", w=1404, h=1872, color=false, stylus=true, cap=true, tier=3, draw="stylus", pw=4, compact=false},
    {name="Kobo Elipsa 2E", code="Kobo_condor", w=1404, h=1872, color=false, stylus=true, cap=true, tier=3, draw="stylus", pw=4, compact=false},
    -- TIER 4: Colour, No Stylus (finger draw)
    {name="Kobo Clara Colour", code="Kobo_spaColour", w=1448, h=1072, color=true, stylus=false, cap=true, tier=4, draw="finger", pw=8, compact=false},
    -- TIER 5: Finger Draw, B&W
    {name="Kobo Clara HD", code="Kobo_nova", w=1448, h=1072, color=false, stylus=false, cap=true, tier=5, draw="finger", pw=8, compact=false},
    {name="Kobo Clara BW", code="Kobo_spaBW", w=1448, h=1072, color=false, stylus=false, cap=true, tier=5, draw="finger", pw=8, compact=false},
    {name="Kobo Libra 2", code="Kobo_io", w=1264, h=1680, color=false, stylus=false, cap=true, tier=5, draw="finger", pw=8, compact=false},
    {name="Kobo Forma", code="Kobo_frost", w=1920, h=1440, color=false, stylus=false, cap=true, tier=5, draw="finger", pw=8, compact=false},
    {name="Kobo Nia", code="Kobo_luna", w=1024, h=758, color=false, stylus=false, cap=true, tier=5, draw="finger", pw=8, compact=false},
    -- TIER 6: Text Only (IR touch)
    {name="Kobo Glo HD", code="Kobo_alyssum", w=1448, h=1072, color=false, stylus=false, cap=false, tier=6, draw="none", pw=8, compact=false},
    {name="Kobo Touch", code="Kobo_trilogy", w=800, h=600, color=false, stylus=false, cap=false, tier=6, draw="none", pw=8, compact=true},
}

-- Read device.lua source to verify the detection logic
local function readFile(p) local f=io.open(p,"r"); if not f then return "" end; local c=f:read("*a"); f:close(); return c end
local device_src = readFile("plugin/core/device.lua")

-- Simulate tier assignment logic from device.lua
local function computeTier(has_color, has_stylus, has_capacitive)
    if has_color and has_stylus then return 2
    elseif has_stylus then return 3
    elseif has_color and has_capacitive then return 4
    elseif has_capacitive then return 5
    else return 6 end
end

local function computeDrawMode(has_stylus, can_draw)
    return has_stylus and "stylus" or (can_draw and "finger" or "none")
end

-- Stylus and IR model sets from device.lua
local STYLUS = {Kobo_monza=true, Kobo_condor=true, Kobo_europa=true, Kobo_cadmus=true}
local IR = {Kobo_trilogy=true, Kobo_pixie=true, Kobo_kraken=true, Kobo_dragon=true,
            Kobo_dahlia=true, Kobo_pika=true, Kobo_alyssum=true, Kobo_star=true}

for _, d in ipairs(DEVICES) do
    local all_ok = true
    local errors = {}

    -- Verify stylus detection
    local detected_stylus = STYLUS[d.code] or false
    if detected_stylus ~= d.stylus then
        all_ok = false
        errors[#errors + 1] = "stylus: expected=" .. tostring(d.stylus) .. " got=" .. tostring(detected_stylus)
    end

    -- Verify capacitive detection (IR models are NOT capacitive)
    local detected_cap = not IR[d.code]
    if detected_cap ~= d.cap then
        all_ok = false
        errors[#errors + 1] = "cap: expected=" .. tostring(d.cap) .. " got=" .. tostring(detected_cap)
    end

    -- Verify tier
    local tier = computeTier(d.color, detected_stylus, detected_cap)
    if tier ~= d.tier then
        all_ok = false
        errors[#errors + 1] = "tier: expected=" .. d.tier .. " got=" .. tier
    end

    -- Verify draw mode
    local can_draw = tier <= 5
    local draw_mode = computeDrawMode(detected_stylus, can_draw)
    if draw_mode ~= d.draw then
        all_ok = false
        errors[#errors + 1] = "draw: expected=" .. d.draw .. " got=" .. draw_mode
    end

    -- Verify pen width
    local pw = detected_stylus and 4 or 8
    if pw ~= d.pw then
        all_ok = false
        errors[#errors + 1] = "pen_width: expected=" .. d.pw .. " got=" .. pw
    end

    -- Verify compact
    local compact = (d.w * d.h) < (1024 * 758)
    if compact ~= d.compact then
        all_ok = false
        errors[#errors + 1] = "compact: expected=" .. tostring(d.compact) .. " got=" .. tostring(compact)
    end

    -- Verify layout fits (tap targets >= 100px for compact, 120px otherwise)
    local TOPBAR_H = 48
    local TOOLBAR_H = 80
    local draw_h = d.h - TOPBAR_H - TOOLBAR_H - 2
    if draw_h < 200 then
        all_ok = false
        errors[#errors + 1] = "draw_h too small: " .. draw_h
    end

    if all_ok then
        PASS(string.format("DEVICE [%s]: %dx%d tier=%d draw=%s", d.name, d.w, d.h, d.tier, d.draw))
    else
        FAIL(string.format("DEVICE [%s]: %s", d.name, table.concat(errors, ", ")))
    end
end

-- Verify device.lua source has all model sets
if device_src:find("Kobo_monza", 1, true) and device_src:find("Kobo_trilogy", 1, true) then
    PASS("device.lua contains stylus + IR model tables")
else
    FAIL("device.lua missing model tables")
end

if device_src:find("tier = 2", 1, true) and device_src:find("tier = 6", 1, true) then
    PASS("device.lua has all 5 tier assignments")
else
    FAIL("device.lua missing tier assignments")
end

if device_src:find("can_draw", 1, true) and device_src:find("draw_mode", 1, true) then
    PASS("device.lua has can_draw + draw_mode fields")
else
    FAIL("device.lua missing draw fields")
end

print("")
print("========================================")
print("RESULTS: " .. pass .. " PASS, " .. fail .. " FAIL")
print("========================================")
os.exit(fail > 0 and 1 or 0)
