-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/components.lua
-- Reusable UI primitives for Tomo™ v2.0.
-- All components follow the KOReader widget convention:
--   Component.method(props) → Widget instance ready to embed in a layout.
-- No component holds mutable state; state lives in tomo.lua.

local Components = {}

local FrameContainer    = require("ui/widget/container/framecontainer")
local CenterContainer   = require("ui/widget/container/centercontainer")
local VerticalGroup     = require("ui/widget/verticalgroup")
local HorizontalGroup   = require("ui/widget/horizontalgroup")
local HorizontalSpan    = require("ui/widget/horizontalspan")
local TextWidget        = require("ui/widget/textwidget")
local TextBoxWidget     = require("ui/widget/textboxwidget")
local LineWidget        = require("ui/widget/linewidget")
local Button            = require("ui/widget/button")
local Geom              = require("ui/geometry")
local Blitbuffer        = require("ffi/blitbuffer")
local Theme             = require("ui/theme")
local Screen            = require("device").screen

-- ─────────────────────────────────────────────────────────────────────────────
-- Divider
-- ─────────────────────────────────────────────────────────────────────────────

function Components.divider(width, device_profile)
    local color
    if device_profile and device_profile.has_color then
        color = Theme.blitColor(Theme.color.divider)
    else
        color = Blitbuffer.Color8(0xCC)
    end
    return LineWidget:new{
        dimen      = Geom:new{ w = width or Screen:getWidth(), h = 1 },
        background = color,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Seasonal greeting line
-- ─────────────────────────────────────────────────────────────────────────────

function Components.seasonLine(greeting_text, width)
    return TextWidget:new{
        text    = greeting_text,
        face    = Theme.face(Theme.font.size.whisper),
        width   = width or Screen:getWidth() - Theme.space.md * 2,
        fgcolor = Theme.blitColor(Theme.color.text_whisper),
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Section header
-- ─────────────────────────────────────────────────────────────────────────────

function Components.sectionHeader(text, width)
    return TextWidget:new{
        text    = text:upper(),
        face    = Theme.face(Theme.font.size.whisper),
        width   = width or Screen:getWidth() - Theme.space.md * 2,
        fgcolor = Theme.blitColor(Theme.color.text_secondary),
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Compact room row (36px target height for v2.0 home screen)
-- ─────────────────────────────────────────────────────────────────────────────

-- Props:
--   name           (string)  Room display name
--   slug           (string)  Room slug (genre accent colour lookup)
--   genre_tag      (string)  Genre tag for accent colour (optional, falls back to slug)
--   has_new        (bool)    Show unread dot
--   is_joined      (bool)    Show ◎ prefix
--   on_tap         (fn)      Tap callback
--   width          (int)     Row width
--   device_profile (table)   Device capabilities
function Components.roomRow(props)
    local width   = props.width or Screen:getWidth() - Theme.space.md * 2
    local has_new = props.has_new or false

    -- Clean text with optional unread dot and member count.
    local name_text = props.name or ""
    if props.member_desc and props.member_desc ~= "" then
        name_text = name_text .. " " .. Theme.glyph.dot .. " " .. props.member_desc
    end
    if has_new then
        name_text = name_text .. " " .. Theme.glyph.dot
    end

    -- Compact row: reduced padding (6px top, 2px bottom) to fit all content
    -- on a single e-ink screen without scrolling.
    local room_btn = Button:new{
        text           = name_text,
        text_font_face = "cfont",
        text_font_bold = false,
        text_font_size = Theme.font.size.room,
        bordersize     = 0,
        padding        = 0,
        padding_top    = 6,
        padding_bottom = 2,
        width          = width,
        align          = "left",
        callback       = props.on_tap or function() end,
    }

    -- No accent bars, no icons. Clean text only.
    return room_btn
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Message block (v2.0: stone-like blocks with 1px border)
-- ─────────────────────────────────────────────────────────────────────────────

-- Vague relative timestamp from an ISO 8601 string.
local function relativeTime(iso_ts)
    if not iso_ts then return "" end
    local y, mo, d, h, mi, s = iso_ts:match(
        "(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d):(%d%d)"
    )
    if not y then return "" end

    local msg_time = os.time{
        year  = tonumber(y),
        month = tonumber(mo),
        day   = tonumber(d),
        hour  = tonumber(h),
        min   = tonumber(mi),
        sec   = tonumber(s),
    }
    local diff = os.time() - msg_time

    if diff < 300        then return "just now"
    elseif diff < 3600   then return "recently"
    elseif diff < 86400  then return "a while ago"
    elseif diff < 172800 then return "yesterday"
    elseif diff < 604800 then return "a few days ago"
    elseif diff < 2592000 then return "last week"
    else                      return "last month"
    end
end

-- A single message entry styled as a stone-like block.
-- Props:
--   username        (string)
--   body            (string)  nil for ink messages
--   kind            (string)  "text" or "ink"
--   created_at      (string)  ISO 8601 timestamp
--   is_own          (bool)    True = sent by current user (right-aligned)
--   is_pending      (bool)    True = message in outbox
--   width           (int)
function Components.messageBubble(props)
    local width = props.width or Screen:getWidth() - Theme.space.md * 2
    local msg_width = math.floor(width * 0.85)

    -- Header: username bold + timestamp in whisper
    local ts_str = relativeTime(props.created_at)
    local header = VerticalGroup:new{
        align = "left",
        TextWidget:new{
            text  = props.username or "reader",
            face  = Theme.face(Theme.font.size.small),
            bold  = true,
            max_width = msg_width - Theme.space.md * 2,
        },
    }
    if ts_str ~= "" then
        header[#header + 1] = TextWidget:new{
            text    = ts_str,
            face    = Theme.face(Theme.font.size.whisper),
            fgcolor = Theme.blitColor(Theme.color.text_whisper),
        }
    end

    -- Body
    local body_widget
    if props.kind == "ink" then
        body_widget = TextWidget:new{
            text  = "[ink letter]",
            face  = Theme.face(Theme.font.size.body),
            max_width = msg_width - Theme.space.md * 2,
        }
    else
        body_widget = TextBoxWidget:new{
            text      = props.body or "",
            face      = Theme.face(Theme.font.size.body),
            width     = msg_width - Theme.space.md * 2,
            alignment = "left",
        }
    end

    -- Stone-like block: 1px border, no background fill (e-ink friendly)
    local block = FrameContainer:new{
        width      = msg_width,
        bordersize = 1,
        padding    = Theme.space.md,
        background = Blitbuffer.COLOR_WHITE,
        VerticalGroup:new{
            align = "left",
            header,
            FrameContainer:new{
                bordersize = 0, padding_top = Theme.space.sm,
                body_widget,
            },
        },
    }

    -- Alignment: sent messages right-aligned, received left-aligned
    if props.is_own then
        -- Right-align using a spacer
        local spacer_w = width - msg_width
        return FrameContainer:new{
            width      = width,
            bordersize = 0,
            padding    = 0,
            padding_bottom = Theme.space.lg,
            HorizontalGroup:new{
                align = "top",
                HorizontalSpan:new{ width = spacer_w },
                block,
            },
        }
    else
        return FrameContainer:new{
            width      = width,
            bordersize = 0,
            padding    = 0,
            padding_bottom = Theme.space.lg,
            block,
        }
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Back button row
-- ─────────────────────────────────────────────────────────────────────────────

function Components.backRow(label, on_tap, width)
    local text = "← " .. (label or "Back")
    return Button:new{
        text           = text,
        text_font_face = "cfont",
        text_font_bold = true,
        text_font_size = Theme.font.size.body,
        bordersize     = 0,
        padding        = Theme.space.md,
        padding_top    = Theme.space.lg,
        padding_bottom = Theme.space.md,
        width          = width or Screen:getWidth(),
        align          = "left",
        callback       = on_tap or function() end,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Home header (v2.0: "友 tomo" + sekki + [shelf] on ONE line)
-- ─────────────────────────────────────────────────────────────────────────────

-- `greeting` is the sekki greeting text (e.g. "春分 · Vernal equinox")
-- `on_sekki_tap` is called when the sekki text is tapped (opens sekki popup)
function Components.homeHeader(on_shelf_tap, width, greeting, on_sekki_tap)
    local w = width or Screen:getWidth()
    local inner_w = w - Theme.space.md * 2

    -- "友 tomo" at title size, bold
    local logo = TextWidget:new{
        text      = Theme.glyph.logo .. " tomo",
        face      = Theme.face(Theme.font.size.title),
        bold      = true,
        max_width = math.floor(inner_w * 0.35),
    }

    -- Sekki greeting -- tappable for popup
    local sekki_widget = Button:new{
        text           = greeting or "",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.whisper,
        bordersize     = 0,
        padding        = 0,
        callback       = on_sekki_tap or function() end,
    }

    -- [shelf] button
    local shelf_btn = Button:new{
        text           = "[shelf]",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.small,
        bordersize     = 0,
        padding        = 0,
        callback       = on_shelf_tap or function() end,
    }

    -- Calculate spacer widths to distribute remaining space
    local logo_w  = logo:getSize().w
    local sekki_w = sekki_widget:getSize().w
    local shelf_w = shelf_btn:getSize().w
    local used = logo_w + sekki_w + shelf_w
    local remaining = math.max(0, inner_w - used)
    local gap1 = math.floor(remaining / 2)
    local gap2 = remaining - gap1

    return FrameContainer:new{
        width      = w,
        bordersize = 0,
        padding    = Theme.space.md,
        padding_top = Theme.space.lg,
        padding_bottom = Theme.space.sm,
        HorizontalGroup:new{
            align = "center",
            logo,
            HorizontalSpan:new{ width = gap1 },
            sekki_widget,
            HorizontalSpan:new{ width = gap2 },
            shelf_btn,
        },
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Presence hint ("Others are here →")
-- ─────────────────────────────────────────────────────────────────────────────

function Components.othersHere(on_tap, width)
    return Button:new{
        text           = "Others are here  →",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.small,
        bordersize     = 0,
        padding        = 0,
        width          = width or Screen:getWidth() - Theme.space.md * 2,
        align          = "left",
        callback       = on_tap or function() end,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Failed messages notice
-- ─────────────────────────────────────────────────────────────────────────────

function Components.failedNotice(on_tap, width)
    return Button:new{
        text           = "Some messages could not be sent.",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.small,
        bordersize     = 0,
        padding        = 0,
        width          = width or Screen:getWidth() - Theme.space.md * 2,
        align          = "left",
        callback       = on_tap or function() end,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Page indicator ("Page 1 of 3")
-- ─────────────────────────────────────────────────────────────────────────────

function Components.pageIndicator(current_page, total_pages, width)
    local text = "Page " .. tostring(current_page) .. " of " .. tostring(total_pages)
    return CenterContainer:new{
        dimen = Geom:new{ w = width or Screen:getWidth(), h = 24 },
        TextWidget:new{
            text    = text,
            face    = Theme.face(Theme.font.size.whisper),
            fgcolor = Theme.blitColor(Theme.color.text_whisper),
        },
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Quick reply pills
-- ─────────────────────────────────────────────────────────────────────────────

-- Returns a horizontal group of 3-4 quick reply pill buttons.
-- `on_select(text)` is called with the pill text when tapped.
function Components.quickReplies(on_select, width)
    local pills = {
        "Started reading!",
        "Great point",
        "Tell me more",
    }

    local group = HorizontalGroup:new{ align = "center" }
    for i, pill_text in ipairs(pills) do
        if i > 1 then
            group[#group + 1] = HorizontalSpan:new{ width = Theme.space.sm }
        end
        group[#group + 1] = Button:new{
            text           = pill_text,
            text_font_face = "cfont",
            text_font_size = Theme.font.size.whisper,
            bordersize     = 1,
            padding        = Theme.space.sm,
            radius         = 0,
            callback       = function()
                if on_select then on_select(pill_text) end
            end,
        }
    end

    return FrameContainer:new{
        width      = width or Screen:getWidth(),
        bordersize = 0,
        padding    = Theme.space.sm,
        padding_left = Theme.space.md,
        group,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Vague member count
-- ─────────────────────────────────────────────────────────────────────────────

function Components.memberDesc(count)
    if not count or count <= 1 then return nil end
    if count == 2 then return "a pair"
    elseif count <= 5  then return "a few readers"
    elseif count <= 12 then return "several readers"
    else                    return "many readers"
    end
end

return Components
