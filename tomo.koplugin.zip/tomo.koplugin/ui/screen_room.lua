-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_room.lua
-- v2.0 -- Room chat with PAGINATED messages (e-reader paradigm).
--
-- Layout:
--   ← Room Name
--   ─────────────────────────────────
--   [message blocks, 4-6 per page]
--   ─────────────────────────────────
--   Page 1 of 3          ↓ new
--   [quick reply pills]
--   [Write something...]
--
-- Tap right side → next page. Tap left side → prev page.
-- Swipe right → back to Home.

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local TextWidget      = require("ui/widget/textwidget")
local InputDialog     = require("ui/widget/inputdialog")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")

local ScreenRoom = InputContainer:extend{
    name      = "tomo_room",
    dimen     = nil,
    tomo      = nil,
    room_id   = nil,
    genre_tag = nil,          -- For lazy room_id resolution when nil
    _room     = nil,
    _messages = {},
    _page     = 1,           -- Current page (1-based)
    _per_page = 5,           -- Messages per page
    _has_new_on_last = false, -- True when new messages arrived while on older page
    _resolve_fn = nil,        -- Scheduled lazy resolve function (cancel on close)
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Init
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._width  = self.dimen.w - Theme.space.md * 2

    -- Find room metadata from tomo state.
    for _, r in ipairs(self.tomo.state.rooms or {}) do
        if r.id == self.room_id then
            self._room = r
            break
        end
    end
    if not self._room then
        self._room = { id = self.room_id, name = "Room", kind = "genre" }
    end

    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
        Tap   = { GestureRange:new{ ges = "tap", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
        self.key_events.NextPage = { { Device.input.group.PgFwd } }
        self.key_events.PrevPage = { { Device.input.group.PgBack } }
    end

    -- Load messages from local cache first (instant first-paint).
    -- Guard: room_id can be nil for fallback genre rooms (no server ID yet).
    self._messages = self.room_id and self.tomo._cache:getMessages(self.room_id, 100) or {}
    -- Reverse: cache returns newest-first; UI shows oldest-first.
    local ordered = {}
    for i = #self._messages, 1, -1 do ordered[#ordered + 1] = self._messages[i] end
    self._messages = ordered

    -- Start on the last page (newest messages).
    self._page = math.max(1, math.ceil(#self._messages / self._per_page))

    -- Username lookup table: user_id → latest known username.
    -- Populated from server responses and current user state.
    -- Used at display time so cached stale usernames are overridden.
    self._user_names = {}
    local me = self.tomo.state.user
    if me and me.id and me.username then
        self._user_names[me.id] = me.username
    end

    self:_build()
end

-- Resolve the display username for a message. Prefers the live lookup
-- table (_user_names) over the cached msg.username. This ensures that
-- after a rename, ALL messages show the current name, not the stale
-- cached name from when the message was first stored in msg_cache.
function ScreenRoom:_resolveUsername(msg)
    if msg.user_id and self._user_names[msg.user_id] then
        return self._user_names[msg.user_id]
    end
    return msg.username or "reader"
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Pagination helpers
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:_totalPages()
    if #self._messages == 0 then return 1 end
    return math.ceil(#self._messages / self._per_page)
end

function ScreenRoom:_pageMessages()
    local total = #self._messages
    if total == 0 then return {} end

    local start_idx = (self._page - 1) * self._per_page + 1
    local end_idx   = math.min(self._page * self._per_page, total)

    local page_msgs = {}
    for i = start_idx, end_idx do
        page_msgs[#page_msgs + 1] = self._messages[i]
    end
    return page_msgs
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Build
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:_build()
    local bg = Theme.pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local w  = self._width
    local dw = self.dimen.w
    local dh = self.dimen.h
    local user_id = self.tomo.state.user and self.tomo.state.user.id

    -- ── Header ──────────────────────────────────────────────────────────────
    local header = Components.backRow(
        self._room.name or "Room",
        function()
            local Recorder = require("core/recorder")
            Recorder.log("TAP", "← Back from room")
            Recorder.log("NAV", "closed room")
            UIManager:close(self)
            UIManager:setDirty(nil, "full")
        end,
        dw
    )

    -- ── Divider ─────────────────────────────────────────────────────────────
    local function makeDivider()
        return FrameContainer:new{
            bordersize    = 0,
            padding_left  = Theme.space.md,
            padding_right = Theme.space.md,
            Components.divider(w, self._device),
        }
    end

    -- ── Messages for current page ───────────────────────────────────────────
    local msg_list = VerticalGroup:new{ align = "left" }
    msg_list[#msg_list + 1] = VerticalSpan:new{ width = Theme.space.md }

    local page_msgs = self:_pageMessages()

    if #self._messages == 0 then
        -- Empty room state -- distinguish between "genuinely empty" and "still loading"
        local empty_text = self.tomo.state.online
            and "Nothing yet. Say something."
            or "Waiting for connection..."
        if not self.room_id then
            empty_text = "This room is not yet connected to the server."
        end
        msg_list[#msg_list + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.xl,
            CenterContainer:new{
                dimen = Geom:new{ w = w, h = 100 },
                TextWidget:new{
                    text    = empty_text,
                    face    = Theme.face(Theme.font.size.body),
                    fgcolor = Theme.blitColor(Theme.color.text_whisper),
                },
            },
        }
    else
        for _, msg in ipairs(page_msgs) do
            msg_list[#msg_list + 1] = FrameContainer:new{
                bordersize   = 0,
                padding_left = Theme.space.md,
                padding_right = Theme.space.md,
                Components.messageBubble{
                    username   = self:_resolveUsername(msg),
                    body       = msg.body,
                    kind       = msg.kind or "text",
                    created_at = msg.created_at,
                    is_own     = msg.user_id == user_id,
                    is_pending = msg.is_pending,
                    width      = w,
                },
            }
        end
    end

    -- ── Page indicator + new message indicator ──────────────────────────────
    local total_pages = self:_totalPages()
    local page_row = Components.pageIndicator(self._page, total_pages, dw)

    -- "↓ new" indicator when new messages arrive on last page but user is on older page
    local new_indicator = nil
    if self._has_new_on_last and self._page < total_pages then
        new_indicator = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Button:new{
                text           = "↓ new",
                text_font_face = "cfont",
                text_font_size = Theme.font.size.small,
                bordersize     = 0,
                padding        = Theme.space.sm,
                callback       = function()
                    self._page = self:_totalPages()
                    self._has_new_on_last = false
                    self:_rebuild()
                end,
            },
        }
    end

    -- ── Quick reply pills ───────────────────────────────────────────────────
    local quick_replies = Components.quickReplies(function(text)
        self:_sendMessage(text)
    end, dw)

    -- ── Input trigger row ───────────────────────────────────────────────────
    local input_btn = Button:new{
        text           = "Write something...",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.body,
        text_font_bold = false,
        bordersize     = 1,
        padding        = Theme.space.md,
        width          = w,
        align          = "left",
        callback       = function()
            local Recorder = require("core/recorder")
            Recorder.log("TAP", "Write something...")
            self:_openInputDialog()
        end,
    }
    local input_row = FrameContainer:new{
        width         = dw,
        bordersize    = 0,
        padding       = Theme.space.sm,
        padding_left  = Theme.space.md,
        padding_right = Theme.space.md,
        input_btn,
    }

    -- ── Assemble ────────────────────────────────────────────────────────────
    local content = VerticalGroup:new{ align = "left" }
    content[#content + 1] = header
    content[#content + 1] = makeDivider()
    content[#content + 1] = msg_list
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.sm }
    content[#content + 1] = makeDivider()
    content[#content + 1] = page_row
    if new_indicator then
        content[#content + 1] = new_indicator
    end
    content[#content + 1] = quick_replies
    content[#content + 1] = input_row

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        content,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Tap handler for page navigation
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:onTap(_, ges)
    local x = ges.pos.x
    local y = ges.pos.y
    local dw = self.dimen.w
    local dh = self.dimen.h

    -- Only handle taps in the message area (upper 2/3 of screen).
    -- Bottom area has buttons that handle their own taps.
    if y > dh * 0.7 then
        return false  -- Let buttons handle it
    end

    -- Tap right half → next page
    if x > dw / 2 then
        self:onNextPage()
        return true
    end

    -- Tap left half → prev page
    self:onPrevPage()
    return true
end

function ScreenRoom:onNextPage()
    if self._page < self:_totalPages() then
        self._page = self._page + 1
        if self._page == self:_totalPages() then
            self._has_new_on_last = false
        end
        self:_rebuild()
    end
end

function ScreenRoom:onPrevPage()
    if self._page > 1 then
        self._page = self._page - 1
        self:_rebuild()
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Input dialog
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:_openInputDialog()
    local dlg
    dlg = InputDialog:new{
        title = "Send a message",
        input = "",
        input_hint = "Write something...",
        buttons = {{
            {
                text = "Cancel",
                id = "close",
                callback = function()
                    UIManager:close(dlg)
                end,
            },
            {
                text = "Send",
                is_enter_default = true,
                callback = function()
                    local text = dlg:getInputText()
                    UIManager:close(dlg)
                    if text and not text:match("^%s*$") then
                        self:_sendMessage(text)
                    end
                end,
            },
        }},
    }
    UIManager:show(dlg)
    dlg:onShowKeyboard()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Message sending
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:_sendMessage(body)
    local Recorder = require("core/recorder")
    local logger   = require("logger")

    if not self.room_id then
        logger.warn("Tomo Room: cannot send, room_id is nil")
        local InfoMessage = require("ui/widget/infomessage")
        UIManager:show(InfoMessage:new{ text = "Cannot send message -- room not connected.", timeout = 2 })
        return
    end

    local user_id  = self.tomo.state.user and self.tomo.state.user.id
    local username = self.tomo.state.user and self.tomo.state.user.username or "reader"
    local device_ts = os.date("!%Y-%m-%dT%H:%M:%SZ")
    local room_id  = self.room_id

    Recorder.log("MESSAGE", "Sending: " .. body:sub(1, 50))

    -- Optimistic UI: add to local display immediately.
    local pending_msg = {
        id         = "pending-" .. tostring(os.time()) .. "-" .. tostring(math.random(1000)),
        room_id    = room_id,
        user_id    = user_id,
        username   = username,
        kind       = "text",
        body       = body,
        created_at = device_ts,
        is_pending = true,
    }
    self._messages[#self._messages + 1] = pending_msg

    -- Persist to cache (pcall: cache failure must not crash optimistic UI).
    pcall(self.tomo._cache.storeMessages, self.tomo._cache, room_id, { pending_msg })

    -- Jump to last page to show the new message.
    self._page = self:_totalPages()
    self:_rebuild()

    -- Enqueue to outbox.
    local outbox_id = self.tomo._cache:enqueue(room_id, "text", body, nil, device_ts)
    Recorder.log("OUTBOX", "enqueue id=" .. tostring(outbox_id))

    -- Defer HTTP calls so UI renders the optimistic message.
    if self.tomo.state.online then
        UIManager:scheduleIn(0.1, function()
            local ok_sched, sched_err = pcall(function()
                if not self or not self.tomo then return end
            -- Auto-join the room.
            if user_id then
                self.tomo._api:joinRoom(room_id, user_id, function(join_err)
                    if join_err then
                        logger.warn("Tomo: joinRoom FAILED: " .. tostring(join_err))
                    end
                end)
            end

            -- Send the message.
            self.tomo._api:sendMessage(room_id, body, device_ts, function(err, created)
                if err then
                    logger.warn("Tomo: sendMessage FAILED: " .. tostring(err))
                    return
                end
                self.tomo._cache:markSent(outbox_id)
                local confirmed = created
                if type(confirmed) == "table" and confirmed[1] then
                    confirmed = confirmed[1]
                end
                confirmed = confirmed or {
                    id         = pending_msg.id,
                    room_id    = room_id,
                    user_id    = user_id,
                    username   = username,
                    kind       = "text",
                    body       = body,
                    created_at = device_ts,
                    is_pending = false,
                }
                if type(confirmed) == "table" then
                    confirmed.is_pending = false
                    if type(confirmed.username) ~= "string" or confirmed.username == "" then
                        confirmed.username = username
                    end
                end
                for i, m in ipairs(self._messages) do
                    if m.id == pending_msg.id then
                        self._messages[i] = confirmed
                        break
                    end
                end
                local cache_ok, cache_err = pcall(
                    self.tomo._cache.storeMessages,
                    self.tomo._cache, room_id, { confirmed }
                )
                if not cache_ok then
                    logger.warn("Tomo: cache storeMessages failed: " .. tostring(cache_err))
                end
                self:_rebuild()
            end)

            self.tomo._sync:flushOutbox()
            end)
            if not ok_sched then
                logger.warn("Tomo: scheduled send callback error: " .. tostring(sched_err))
            end
        end)
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- New message arrival (from sync poll)
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:onNewMessage(msg)
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if msg.user_id == user_id then return end

    -- Update the username lookup table with the fresh server-side name.
    -- This is the LIVE username from the PostgREST users(username) join.
    if msg.user_id and msg.username then
        self._user_names[msg.user_id] = msg.username
    end

    self._messages[#self._messages + 1] = msg

    -- If user is on the last page, stay on it. Otherwise show "↓ new".
    local was_on_last = self._page >= self:_totalPages() - 1
    if was_on_last then
        self._page = self:_totalPages()
    else
        self._has_new_on_last = true
    end

    self:_rebuild()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRoom:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenRoom]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenRoom:onShow()
    UIManager:setDirty(self, "full")

    local user_id = self.tomo.state.user and self.tomo.state.user.id

    if self.room_id then
        -- Room has a server ID -- normal path
        if user_id and self.tomo.state.online then
            self.tomo._api:markRead(self.room_id, user_id, function() end)
            for _, r in ipairs(self.tomo.state.rooms) do
                if r.id == self.room_id then
                    r.has_new = false
                    break
                end
            end
        end
        self.tomo._sync:enterRoom(self.room_id, user_id, 20, function(msg)
            self:onNewMessage(msg)
        end)
    else
        -- LAZY RESOLUTION: room_id is nil (fallback genre room).
        -- Try to fetch real room IDs from Supabase now.
        local logger = require("logger")
        logger.warn("Tomo Room: room_id is nil, attempting lazy resolution for genre_tag="
            .. tostring(self.genre_tag or (self._room and self._room.genre_tag)))
        self:_resolveRoomId(user_id)
    end

    return true
end

-- Try to resolve a nil room_id by fetching rooms from Supabase.
-- Retries after 5 seconds if the first attempt fails. Stops on success or close.
function ScreenRoom:_resolveRoomId(user_id)
    local tag = self.genre_tag or (self._room and self._room.genre_tag)
    if not tag then return end
    if self.room_id then return end  -- already resolved

    local function attemptResolve()
        if self.room_id then return end  -- resolved by another path
        self.tomo._api:getRooms(function(err, rooms)
            if err or not rooms then
                -- Retry in 5 seconds
                local logger = require("logger")
                logger.warn("Tomo Room: lazy resolve failed, retrying in 5s: " .. tostring(err))
                self._resolve_fn = function() self:_resolveRoomId(user_id) end
                UIManager:scheduleIn(5, self._resolve_fn)
                return
            end
            -- Find matching room by genre_tag
            for _, r in ipairs(rooms) do
                if r.genre_tag == tag then
                    local logger = require("logger")
                    logger.warn("Tomo Room: resolved room_id=" .. tostring(r.id) .. " for " .. tag)
                    self.room_id = r.id
                    self._room.id = r.id
                    -- Also update the tomo state so other screens benefit
                    for _, sr in ipairs(self.tomo.state.rooms) do
                        if sr.genre_tag == tag and not sr.id then
                            sr.id = r.id
                        end
                    end
                    -- Now load messages and start polling
                    self._messages = self.tomo._cache:getMessages(self.room_id, 100) or {}
                    local ordered = {}
                    for i = #self._messages, 1, -1 do ordered[#ordered + 1] = self._messages[i] end
                    self._messages = ordered
                    self._page = math.max(1, math.ceil(#self._messages / self._per_page))
                    self:_rebuild()
                    if user_id then
                        self.tomo._api:markRead(self.room_id, user_id, function() end)
                    end
                    self.tomo._sync:enterRoom(self.room_id, user_id, 20, function(msg)
                        self:onNewMessage(msg)
                    end)
                    return
                end
            end
            -- Tag not found in rooms -- retry
            self._resolve_fn = function() self:_resolveRoomId(user_id) end
            UIManager:scheduleIn(5, self._resolve_fn)
        end)
    end

    UIManager:scheduleIn(0.1, attemptResolve)
end

function ScreenRoom:onCloseWidget()
    self.tomo._sync:stopRoom()
    self.tomo.state.active_room = nil
    -- Cancel any pending lazy resolve timer
    if self._resolve_fn then
        UIManager:unschedule(self._resolve_fn)
        self._resolve_fn = nil
    end
end

function ScreenRoom:onSwipe(_, ges)
    local direction = ges.direction
    if direction == "east" then
        -- Swipe right → back to home
        self:onClose()
        return true
    end
end

function ScreenRoom:onClose()
    local Recorder = require("core/recorder")
    Recorder.log("NAV", "closed room")
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    return true
end

function ScreenRoom:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

return ScreenRoom
