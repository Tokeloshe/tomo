-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_rooms.lua
-- Screen 2 -- Room Browser (森 Mori, Forest).
-- Many paths, one wood.
--
-- Layout (MASTERPLAN.md §Screen 2):
--   ← Back
--   Genre rooms
--   ──────────────
--   Fantasy & Sci-Fi
--   Romance
--   … (8 genre rooms, always in fixed order)
--   Book rooms
--   ──────────────
--   Dune · a few readers
--   Piranesi · a pair
--   Pen pal     ✦        ← only on stylus devices
--   ──────────────
--   Find a pen pal →

local InputContainer      = require("ui/widget/container/inputcontainer")
local FrameContainer      = require("ui/widget/container/framecontainer")
local ScrollableContainer = require("ui/widget/container/scrollablecontainer")
local VerticalGroup       = require("ui/widget/verticalgroup")
local TextWidget          = require("ui/widget/textwidget")
local Button              = require("ui/widget/button")
local GestureRange        = require("ui/gesturerange")
local Geom                = require("ui/geometry")
local UIManager           = require("ui/uimanager")
local Device              = require("device")
local Screen              = Device.screen
local Blitbuffer          = require("ffi/blitbuffer")
local VerticalSpan        = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")

-- The eight genre rooms in canonical display order (MASTERPLAN.md §Genre Room Taxonomy).
local GENRE_ROOMS = {
    { name = "Fantasy & Sci-Fi",  slug = "fantasy-scifi" },
    { name = "Romance",           slug = "romance"        },
    { name = "Literary Fiction",  slug = "literary"       },
    { name = "Thriller & Mystery",slug = "thriller"       },
    { name = "Non-Fiction",       slug = "nonfiction"     },
    { name = "Horror",            slug = "horror"         },
    { name = "Historical Fiction",slug = "historical"     },
    { name = "Young Adult",       slug = "ya"             },
}

local ScreenRooms = InputContainer:extend{
    name       = "tomo_rooms",
    dimen      = nil,
    tomo       = nil,
    _book_rooms = {},   -- Fetched from Supabase on show
}

function ScreenRooms:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._width  = self.dimen.w - Theme.space.md * 2

    local logger = require("logger")
    logger.warn("Tomo: ScreenRooms device profile: model="
        .. tostring(self._device.model_code)
        .. " has_stylus=" .. tostring(self._device.has_stylus)
        .. " has_color=" .. tostring(self._device.has_color))

    -- _init() already ran: _ordered_touch_zones, ges_events, key_events are set.
    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Build
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRooms:_build()
    local bg = require("ui/theme").pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local w = self._width

    -- Back button row.
    local back_row = Components.backRow("Back", function()
        UIManager:close(self)
    end, self.dimen.w)

    -- Genre rooms section.
    local genre_section = self:_buildGenreSection(w)

    -- Book rooms section.
    local book_section = self:_buildBookSection(w)

    -- Pen pal section (stylus devices only).
    local penpal_section = nil
    if self._device.has_stylus then
        penpal_section = self:_buildPenpalSection(w)
    end
    -- On non-stylus devices, the section is completely absent -- not greyed out.

    local content = VerticalGroup:new{
        align = "left",
        back_row,
        VerticalSpan:new{ width = Theme.space.md },
        genre_section,
        VerticalSpan:new{ width = Theme.space.md },
        book_section,
    }
    if penpal_section then
        table.insert(content, penpal_section)
    end
    table.insert(content, VerticalSpan:new{ width = Theme.space.xl })

    self[1] = FrameContainer:new{
        width      = self.dimen.w,
        height     = self.dimen.h,
        bordersize = 0,
        padding    = 0,
        background = bg,
        ScrollableContainer:new{
            dimen = self.dimen,
            FrameContainer:new{
                width      = self.dimen.w,
                bordersize = 0,
                padding    = 0,
                content,
            },
        },
    }
end

function ScreenRooms:_buildGenreSection(w)
    local group = VerticalGroup:new{ align = "left" }

    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        Components.sectionHeader("Genre rooms", w),
    }
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        padding_right = Theme.space.md,
        Components.divider(w, self._device),
    }
    group[#group + 1] = VerticalSpan:new{ width = Theme.space.sm }

    -- Check which rooms the user has joined.
    local joined_ids = {}
    for _, r in ipairs(self.tomo.state.rooms) do
        joined_ids[r.id] = true
    end

    for _, gr in ipairs(GENRE_ROOMS) do
        -- Find the matching room ID from state. Match by genre_tag because
        -- room slugs in the DB are prefixed ("genre-fantasy-scifi") while
        -- GENRE_ROOMS slugs are plain ("fantasy-scifi").
        local room_id = nil
        local has_new = false
        for _, r in ipairs(self.tomo.state.rooms) do
            if r.genre_tag == gr.slug then
                room_id = r.id
                has_new = r.has_new or false
                break
            end
        end

        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            Components.roomRow{
                name           = gr.name,
                slug           = gr.slug,
                has_new        = has_new,
                is_joined      = room_id ~= nil,
                width          = w,
                device_profile = self._device,
                on_tap         = function()
                    self:_joinAndOpenRoom(room_id, gr.slug, gr.name)
                end,
            },
        }
    end

    return group
end

function ScreenRooms:_buildBookSection(w)
    local group = VerticalGroup:new{ align = "left" }

    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_top  = Theme.space.md,
        padding_left = Theme.space.md,
        Components.sectionHeader("Book rooms", w),
    }
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        padding_right = Theme.space.md,
        Components.divider(w, self._device),
    }
    group[#group + 1] = VerticalSpan:new{ width = Theme.space.sm }

    if #self._book_rooms == 0 then
        group[#group + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            TextWidget:new{
                text  = "No book rooms yet.",
                face  = Theme.face(Theme.font.size.body),
                width = w,
            },
        }
    else
        for _, room in ipairs(self._book_rooms) do
            local member_desc = Components.memberDesc(room.member_count)
            local display_name = room.name
                .. (member_desc and (" · " .. member_desc) or "")
            group[#group + 1] = FrameContainer:new{
                bordersize = 0,
                padding_left = Theme.space.md,
                Components.roomRow{
                    name           = display_name,
                    slug           = room.slug,
                    width          = w,
                    device_profile = self._device,
                    on_tap         = function()
                        self:_joinAndOpenRoom(room.id, room.slug, room.name)
                    end,
                },
            }
        end
    end

    return group
end

function ScreenRooms:_buildPenpalSection(w)
    local group = VerticalGroup:new{ align = "left" }

    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_top  = Theme.space.md,
        padding_left = Theme.space.md,
        TextWidget:new{
            text  = "Pen pal",
            face  = Theme.face(Theme.font.size.body),
            width = w,
        },
    }
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        padding_right = Theme.space.md,
        Components.divider(w, self._device),
    }
    group[#group + 1] = VerticalSpan:new{ width = Theme.space.sm }
    group[#group + 1] = FrameContainer:new{
        bordersize = 0,
        padding_left = Theme.space.md,
        Button:new{
            text           = "Find a pen pal  →",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 0,
            padding        = 0,
            callback       = function() self:_openPenpal() end,
        },
    }

    return group
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Actions
-- ─────────────────────────────────────────────────────────────────────────────

-- Open a room. Closes the browser first (swap pattern: back from room returns to home).
-- Joins the room silently in the background. Never blocks on an API call.
function ScreenRooms:_joinAndOpenRoom(room_id, slug, name)
    local Recorder = require("core/recorder")

    -- If room_id is nil (fallback rooms), look it up from state by genre_tag.
    if not room_id then
        for _, r in ipairs(self.tomo.state.rooms) do
            if r.genre_tag == slug or r.slug == slug then
                room_id = r.id
                break
            end
        end
    end

    local room_data = {
        id        = room_id,
        name      = name or slug,
        slug      = slug,
        genre_tag = slug,
        kind      = "genre",
    }

    Recorder.log("NAV", "Opening room: " .. tostring(name) .. " id=" .. tostring(room_id))

    -- Open the room screen IMMEDIATELY. Never block on API calls.
    UIManager:close(self)
    local ScreenRoom = require("ui/screen_room")
    UIManager:show(ScreenRoom:new{
        tomo      = self.tomo,
        room_id   = room_id,
        genre_tag = slug,
        _room     = room_data,
    })

    -- Join the room in the background (deferred so UI opens instantly).
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if room_id and user_id and self.tomo.state.online then
        UIManager:scheduleIn(0.1, function()
            local ok, err = pcall(function()
                if not self or not self.tomo then return end
                self.tomo._api:joinRoom(room_id, user_id, function() end)
            end)
            if not ok then
                local logger = require("logger")
                logger.warn("Tomo: scheduled callback error: " .. tostring(err))
            end
        end)
    end
end

function ScreenRooms:_openPenpal()
    -- Swap: close browser first so pressing back from pen pal returns to home.
    UIManager:close(self)
    local ScreenPenpal = require("ui/screen_penpal")
    UIManager:show(ScreenPenpal:new{ tomo = self.tomo })
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Data loading
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch book rooms from Supabase and rebuild.
function ScreenRooms:_fetchBookRooms()
    if not self.tomo.state.online then return end
    self.tomo._api:getRooms(function(err, rooms)
        if err or not rooms then return end
        self._book_rooms = {}
        for _, r in ipairs(rooms) do
            if r.kind == "book" then
                self._book_rooms[#self._book_rooms + 1] = r
            end
        end
        self:_rebuild()
    end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenRooms:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenRooms]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenRooms:onShow()
    self:_fetchBookRooms()
    UIManager:setDirty(self, "full")
    return true
end

function ScreenRooms:onSwipe(_, ges)
    local direction = ges.direction
    if direction == "east" then
        self:onClose()
        return true
    elseif direction == "south" then
        self:onClose()
        return true
    end
end

function ScreenRooms:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    return true
end

function ScreenRooms:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

return ScreenRooms
