-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_onboarding.lua
-- First-launch onboarding wizard. 4 steps: Welcome → Name → Haiku → Done.
-- Uses LuaSettings for persistence. Minimizes keyboard interaction.

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local TextWidget      = require("ui/widget/textwidget")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local Button          = require("ui/widget/button")
local InputDialog     = require("ui/widget/inputdialog")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")

local Theme = require("ui/theme")

local ScreenOnboarding = InputContainer:extend{
    name     = "tomo_onboarding",
    dimen    = nil,
    tomo     = nil,
    settings = nil,  -- LuaSettings reference
    _step    = 1,
    _username = nil,
    _haiku   = nil,
}

-- Generate a random nature name so the user can just tap Next.
local function generateName()
    local first = {
        "pine","moss","fern","cedar","birch","oak","willow","sage",
        "ivy","hazel","rowan","lark","wren","fox","hare","moth","cloud",
        "rain","dawn","dusk","ember","stone","river","brook","cliff","meadow",
    }
    local second = {
        "thistle","hollow","grove","shadow","light","leaf","bloom",
        "thorn","drift","branch","shore","vale","crest","ridge","field",
        "song","whisper","mist","frost","spark",
    }
    math.randomseed(os.time())
    return first[math.random(#first)] .. "-" .. second[math.random(#second)]
end

function ScreenOnboarding:init()
    self.dimen = Screen:getSize()
    self._username = generateName()
    self:_buildStep1()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 1: Welcome
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenOnboarding:_buildStep1()
    local dw = self.dimen.w
    local dh = self.dimen.h

    local content = VerticalGroup:new{ align = "center" }
    content[#content + 1] = VerticalSpan:new{ width = math.floor(dh * 0.25) }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 60 },
        TextWidget:new{
            text = "友",
            face = Theme.face(48),
            bold = true,
        },
    }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 40 },
        TextWidget:new{
            text = "tomo",
            face = Theme.face(Theme.font.size.title),
            fgcolor = Theme.blitColor(Theme.color.text_secondary),
        },
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.xl }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 120 },
        TextBoxWidget:new{
            text = "A reading companion for Kobo.\n\nSomething that walks beside you\nwhile you read, and is there\nwhen you look up from the page.",
            face = Theme.face(Theme.font.size.body),
            width = math.floor(dw * 0.7),
            alignment = "center",
            fgcolor = Theme.blitColor(Theme.color.text_whisper),
        },
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.xl * 2 }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 60 },
        Button:new{
            text = "Begin",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.title,
            bordersize = 1,
            padding = Theme.space.lg,
            callback = function() self:_goToStep2() end,
        },
    }

    self[1] = FrameContainer:new{
        width = dw, height = dh, bordersize = 0, padding = 0,
        background = Blitbuffer.COLOR_WHITE,
        content,
    }
    UIManager:setDirty(self, "full")
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 2: Choose a name
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenOnboarding:_goToStep2()
    -- Close welcome and do full refresh to clear ghosting
    UIManager:close(self)
    UIManager:setDirty(nil, "full")

    local dlg
    dlg = InputDialog:new{
        title = "Choose a name",
        input = self._username,
        input_hint = "A nature word, like pine-whisper",
        buttons = {{
            {
                text = "Next",
                is_enter_default = true,
                callback = function()
                    local val = dlg:getInputText()
                    UIManager:close(dlg)
                    if val and #val >= 3 and #val <= 20 then
                        self._username = val
                        self:_goToStep3()
                    else
                        local InfoMessage = require("ui/widget/infomessage")
                        UIManager:show(InfoMessage:new{
                            text = "Name must be 3-20 characters.",
                            timeout = 2,
                        })
                        self:_goToStep2()
                    end
                end,
            },
        }},
    }
    UIManager:show(dlg)
    dlg:onShowKeyboard()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 3: Haiku (optional)
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenOnboarding:_goToStep3()
    local dlg
    dlg = InputDialog:new{
        title = "Write a haiku (optional)",
        input = "",
        input_hint = "autumn reading light\npages turning one by one\ntea grows slowly cold",
        buttons = {{
            {
                text = "Skip",
                callback = function()
                    UIManager:close(dlg)
                    self:_goToStep4()
                end,
            },
            {
                text = "Next",
                is_enter_default = true,
                callback = function()
                    self._haiku = dlg:getInputText()
                    UIManager:close(dlg)
                    self:_goToStep4()
                end,
            },
        }},
    }
    UIManager:show(dlg)
    dlg:onShowKeyboard()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step 4: Done
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenOnboarding:_goToStep4()
    -- Show step 4 as a new full-screen widget with full refresh
    local dw = self.dimen.w
    local dh = self.dimen.h

    local content = VerticalGroup:new{ align = "center" }
    content[#content + 1] = VerticalSpan:new{ width = math.floor(dh * 0.3) }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 40 },
        TextWidget:new{
            text = "One more thing",
            face = Theme.face(Theme.font.size.title),
            bold = true,
        },
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.lg }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 100 },
        TextBoxWidget:new{
            text = "Tomo sends anonymous crash reports\nto help improve the app. No personal\ndata is included.",
            face = Theme.face(Theme.font.size.body),
            width = math.floor(dw * 0.7),
            alignment = "center",
            fgcolor = Theme.blitColor(Theme.color.text_secondary),
        },
    }
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.xl * 2 }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 60 },
        Button:new{
            text = "OK",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.title,
            bordersize = 1,
            padding = Theme.space.lg,
            callback = function() self:_completeOnboarding() end,
        },
    }

    self[1] = FrameContainer:new{
        width = dw, height = dh, bordersize = 0, padding = 0,
        background = Blitbuffer.COLOR_WHITE,
        content,
    }
    -- Re-show self (was closed before step 2 dialogs)
    UIManager:show(self)
    UIManager:setDirty(self, "full")
end

function ScreenOnboarding:_completeOnboarding()
    -- Save to LuaSettings
    if self.settings then
        self.settings:saveSetting("onboarding_complete", true)
        self.settings:saveSetting("username", self._username)
        if self._haiku and self._haiku ~= "" then
            self.settings:saveSetting("haiku_bio", self._haiku)
        end
        self.settings:flush()
    end

    -- Update tomo state
    if self.tomo and self.tomo.state.user then
        self.tomo.state.user.username = self._username
        if self._haiku and self._haiku ~= "" then
            self.tomo.state.user.haiku_bio = self._haiku
        end
    end

    -- Cache locally
    if self.tomo and self.tomo._cache then
        self.tomo._cache:setState("auth_username", self._username)
        if self._haiku and self._haiku ~= "" then
            self.tomo._cache:setState("auth_haiku_bio", self._haiku)
        end
    end

    -- Push to Supabase (deferred, non-blocking)
    if self.tomo and self.tomo._api and self.tomo.state.user then
        local user_id = self.tomo.state.user.id
        if user_id then
            local updates = { username = self._username }
            if self._haiku and self._haiku ~= "" then
                updates.haiku_bio = self._haiku
            end
            UIManager:scheduleIn(0.1, function()
                local ok, err = pcall(function()
                    if not self or not self.tomo then return end
                    self.tomo._api:updateUser(user_id, updates, function() end)
                end)
                if not ok then
                    local logger = require("logger")
                    logger.warn("Tomo: scheduled callback error: " .. tostring(err))
                end
            end)
        end
    end

    -- Close onboarding and show home
    UIManager:close(self)
    UIManager:setDirty(nil, "full")

    -- The caller (main.lua) will show the home screen after this returns
    if self.on_complete then
        self.on_complete()
    end
end

function ScreenOnboarding:onShow()
    UIManager:setDirty(self, "full")
    return true
end

return ScreenOnboarding
