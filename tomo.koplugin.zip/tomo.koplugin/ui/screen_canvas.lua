-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_canvas.lua
-- v2.1.8 -- Boosted palette, 8ms throttle, deferred colour refresh, lazy room resolve.
--
-- KEY INSIGHT: Screen.bb IS the mmap'd framebuffer (/dev/fb0).
-- UIManager:setDirty BATCHES refreshes on the next event loop tick -- useless
-- for real-time pen feedback because 678 queued refreshes merge into one.
--
-- CORRECT APPROACH:
--   1. During onPan: write BLACK pixels to BOTH _canvas_bb AND Screen.bb,
--      then call Screen:refreshFast() for immediate DU waveform ioctl (~30-50ms).
--   2. On pen lift: repaint the stroke in its intended RGB colour on both buffers,
--      then call Screen:refreshPartial(x,y,w,h,dither=true) for Kaleido GCC16
--      colour waveform (~450ms). Colour is physically impossible during DU/A2.
--   3. paintTo renders UI chrome (top bar, toolbar) and blits _canvas_bb for
--      initial render and toolbar button presses only -- NOT during drawing.

local InputContainer = require("ui/widget/container/inputcontainer")
local FrameContainer = require("ui/widget/container/framecontainer")
local VerticalSpan   = require("ui/widget/verticalspan")
local TextWidget     = require("ui/widget/textwidget")
local GestureRange   = require("ui/gesturerange")
local Geom           = require("ui/geometry")
local UIManager      = require("ui/uimanager")
local Device         = require("device")
local Screen         = Device.screen
local Blitbuffer     = require("ffi/blitbuffer")
local Font           = require("ui/font")
local ConfirmBox     = require("ui/widget/confirmbox")
local InfoMessage    = require("ui/widget/infomessage")
local logger         = require("logger")

local Theme = require("ui/theme")

-- ─────────────────────────────────────────────────────────────────────────────
-- Constants
-- ─────────────────────────────────────────────────────────────────────────────

local PEN_WIDTHS = {
    { name = "XF", width = 1 },
    { name = "F",  width = 2 },
    { name = "M",  width = 4 },
    { name = "T",  width = 7 },
    { name = "XT", width = 11 },
}

local PALETTE = {
    { hex = "#000000", grey = 0x00 },   -- ink: true black, the default
    { hex = "#8B4513", grey = 0x55 },   -- sepia: saddlebrown, clearly brown
    { hex = "#4169E1", grey = 0x6A },   -- blue: royal blue, vivid
    { hex = "#DC143C", grey = 0x40 },   -- rose: crimson, vivid pink-red
    { hex = "#D2691E", grey = 0x6A },   -- brown: chocolate, warm
    { hex = "#228B22", grey = 0x5A },   -- green: forest green, vivid
    { hex = "#9932CC", grey = 0x58 },   -- plum: dark orchid, clearly purple
    { hex = "#FF8C00", grey = 0x80 },   -- amber: dark orange, vivid
    { hex = "#FFD700", grey = 0xC0 },   -- gold: bright yellow
    { hex = "#708090", grey = 0x78 },   -- grey: slate grey, clearly not black
}
local PALETTE_NAMES = { "ink","sepia","blue","rose","brown","green","plum","amber","gold","grey" }

local TOOL_PEN    = "pen"
local TOOL_ERASER = "eraser"

local TOPBAR_H  = 48
local TOOLBAR_H = 80
local REFRESH_INTERVAL = 0.008  -- ~120fps, 8ms between refresh ioctls
local MIN_STROKE_POINTS = 50
local NEW_STROKE_DIST_SQ = 40 * 40

local ScreenCanvas = InputContainer:extend{
    name            = "tomo_canvas",
    dimen           = nil,
    tomo            = nil,
    room_id         = nil,
    partner_name    = nil,
    on_send         = nil,
    is_postcrossing = false,
    _strokes        = {},
    _cur_stroke     = nil,
    _last_point     = nil,
    _pen_idx        = 3,       -- Default Medium
    _color_idx      = 1,
    _tool           = TOOL_PEN,
    _canvas_bb      = nil,
    _draw_y         = nil,
    _draw_h         = nil,
    _toolbar_y      = nil,
    _total_points   = 0,
    _bg_val         = 0xFF,
    _ink_val         = 0x00,
    _dirty           = nil,    -- { x1, y1, x2, y2 } in canvas coords
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Init
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:init()
    self.dimen = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._strokes = {}
    self._total_points = 0
    self._last_point = nil
    self._cur_stroke = nil

    local dw = self.dimen.w
    local dh = self.dimen.h

    -- Layout: topbar | 1px div | canvas | 1px div | toolbar
    self._draw_y   = TOPBAR_H + 1
    self._toolbar_y = dh - TOOLBAR_H
    self._draw_h   = self._toolbar_y - 1 - self._draw_y  -- between dividers

    -- Background value: warm off-white on colour, white on mono
    self._bg_val = self._device.has_color and 0xF1 or 0xFF

    logger.warn(string.format(
        "Tomo Canvas LAYOUT: screen=%dx%d draw_y=%d draw_h=%d toolbar_y=%d toolbar_end=%d",
        dw, dh, self._draw_y, self._draw_h, self._toolbar_y, self._toolbar_y + TOOLBAR_H))

    -- Create canvas buffer matching the screen's pixel format so colour is preserved.
    -- On Kobo Libra Colour with color_rendering=true, Screen.bb is BBRGB32.
    -- On monochrome devices, Screen.bb is BB8. Matching the type avoids greyscale
    -- conversion when blitting canvas → screen during paintTo.
    local screen_bb_type = Screen.bb:getType()
    self._canvas_bb = Blitbuffer.new(dw, self._draw_h, screen_bb_type)
    self._is_rgb = self._canvas_bb:getType() ~= Blitbuffer.TYPE_BB8
    logger.warn(string.format(
        "Tomo Canvas: screen_bb type=%d canvas_bb type=%d is_rgb=%s has_color=%s",
        Screen.bb:getType(), self._canvas_bb:getType(),
        tostring(self._is_rgb), tostring(self._device.has_color)))
    -- _fillBg must run before _updateInkVal so _bg_color is set for eraser fallback
    self:_fillBg()
    self:_updateInkVal()
    self:_drawDotGrid()

    -- Pre-compute drawing colours and device flags
    self._device_has_color = self._is_rgb and self._device.has_color
    if self._is_rgb then
        self._black_color = Blitbuffer.ColorRGB32(0, 0, 0, 0xFF)
    else
        self._black_color = Blitbuffer.COLOR_BLACK
    end

    -- Discover available Screen refresh methods. Do NOT cache Screen itself
    -- (it may be replaced on HW rotation), but log what's available.
    local screen_mt = getmetatable(Screen)
    local screen_idx = screen_mt and screen_mt.__index or Screen
    if type(screen_idx) == "table" then
        for k, v in pairs(screen_idx) do
            if type(v) == "function" and type(k) == "string" and k:match("refresh") then
                logger.warn("Tomo Canvas: Screen has method: " .. k)
            end
        end
    end

    -- Stroke dirty region accumulator for deferred colour refresh on pen lift
    self._stroke_dirty = nil

    -- Throttled refresh state: prevent flooding HWTCON controller with ioctls
    self._last_refresh_time = 0
    self._pending_refresh = nil  -- { x, y, w, h } accumulated since last refreshFast

    -- Refresh counter for diagnostic logging on pen lift
    self._refresh_count = 0

    -- Gesture events on the full screen
    self.ges_events = {
        Pan        = { GestureRange:new{ ges = "pan", range = self.dimen } },
        PanRelease = { GestureRange:new{ ges = "pan_release", range = self.dimen } },
        Tap        = { GestureRange:new{ ges = "tap", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.ConfirmDiscard = { { Device.input.group.Back } }
    end

    -- Minimal widget tree: just a full-screen placeholder for InputContainer
    self[1] = FrameContainer:new{
        width = dw, height = dh, bordersize = 0, padding = 0,
        VerticalSpan:new{ width = dh },
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Colour helpers -- resolve hex or grey to the correct Blitbuffer color type
-- ─────────────────────────────────────────────────────────────────────────────

-- Parse a "#RRGGBB" hex string into r, g, b integers (0-255).
local function parseHex(hex)
    local s = hex:gsub("#", "")
    return tonumber(s:sub(1, 2), 16),
           tonumber(s:sub(3, 4), 16),
           tonumber(s:sub(5, 6), 16)
end

-- Return a Blitbuffer color matching the canvas buffer type.
-- When the canvas is RGB, returns ColorRGB32; otherwise Color8.
function ScreenCanvas:_makeColor(hex, grey_fallback)
    if self._is_rgb and hex then
        local r, g, b = parseHex(hex)
        return Blitbuffer.ColorRGB32(r, g, b, 0xFF)
    end
    return Blitbuffer.Color8(grey_fallback or 0x00)
end

-- Fill the canvas with the background colour.
function ScreenCanvas:_fillBg()
    if self._is_rgb and self._device.has_color then
        local r, g, b = parseHex("#F1EDE5")  -- warm eggshell
        self._bg_color = Blitbuffer.ColorRGB32(r, g, b, 0xFF)
    else
        self._bg_color = Blitbuffer.Color8(self._bg_val)
    end
    self._canvas_bb:paintRect(0, 0, self.dimen.w, self._draw_h, self._bg_color)
end

-- Expand the per-stroke dirty rect accumulator (screen coordinates).
-- Used to compute the bounding box for deferred colour refresh on pen lift.
function ScreenCanvas:_expandStrokeDirty(sx1, sy1, sx2, sy2)
    if not self._stroke_dirty then
        self._stroke_dirty = { x = sx1, y = sy1, w = sx2 - sx1, h = sy2 - sy1 }
    else
        local sd = self._stroke_dirty
        local nx1 = math.min(sd.x, sx1)
        local ny1 = math.min(sd.y, sy1)
        local nx2 = math.max(sd.x + sd.w, sx2)
        local ny2 = math.max(sd.y + sd.h, sy2)
        sd.x = nx1; sd.y = ny1; sd.w = nx2 - nx1; sd.h = ny2 - ny1
    end
end

-- Accumulate a dirty rect for the next throttled refresh (screen coords).
-- This grows between refreshFast calls so each refresh covers all new pixels.
function ScreenCanvas:_expandPendingRefresh(sx1, sy1, sx2, sy2)
    if not self._pending_refresh then
        self._pending_refresh = { x = sx1, y = sy1, w = sx2 - sx1, h = sy2 - sy1 }
    else
        local p = self._pending_refresh
        local nx1 = math.min(p.x, sx1)
        local ny1 = math.min(p.y, sy1)
        local nx2 = math.max(p.x + p.w, sx2)
        local ny2 = math.max(p.y + p.h, sy2)
        p.x = nx1; p.y = ny1; p.w = nx2 - nx1; p.h = ny2 - ny1
    end
end

-- Fire a throttled Screen:refreshFast if enough time has elapsed.
-- Returns true if a refresh was fired, false if accumulated for later.
function ScreenCanvas:_doThrottledRefresh(screen_obj)
    local now = os.clock()
    if (now - self._last_refresh_time) >= REFRESH_INTERVAL then
        if self._pending_refresh then
            local p = self._pending_refresh
            if screen_obj.refreshFast then
                screen_obj:refreshFast(p.x, p.y, p.w, p.h)
            elseif screen_obj.refresh then
                screen_obj:refresh(1, 1, p.x, p.y, p.w, p.h)
            else
                UIManager:setDirty(self, "fast", Geom:new(p))
            end
            self._refresh_count = (self._refresh_count or 0) + 1
            self._pending_refresh = nil
        end
        self._last_refresh_time = now
        return true
    end
    return false
end

-- Draw a line segment on an ARBITRARY Blitbuffer (canvas or Screen.bb).
-- This is separate from _drawSegment which is hardcoded to _canvas_bb.
function ScreenCanvas:_drawLineToBB(bb, x1, y1, x2, y2, width, color)
    local half = math.floor(width / 2)
    if width <= 2 then
        local dx = math.abs(x2 - x1)
        local dy = math.abs(y2 - y1)
        local sx = x1 < x2 and 1 or -1
        local sy = y1 < y2 and 1 or -1
        local err = dx - dy
        while true do
            bb:paintRect(x1 - half, y1 - half, width, width, color)
            if x1 == x2 and y1 == y2 then break end
            local e2 = 2 * err
            if e2 > -dy then err = err - dy; x1 = x1 + sx end
            if e2 < dx  then err = err + dx; y1 = y1 + sy end
        end
    else
        local dx = x2 - x1
        local dy = y2 - y1
        local dist = math.sqrt(dx * dx + dy * dy)
        local steps = math.max(1, math.floor(dist / math.max(1, half)))
        for i = 0, steps do
            local t = steps > 0 and (i / steps) or 0
            local cx = math.floor(x1 + dx * t + 0.5)
            local cy = math.floor(y1 + dy * t + 0.5)
            bb:paintCircle(cx, cy, half, color, half)
        end
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Dot grid: medium grey, clearly visible on both eggshell and white
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_drawDotGrid()
    local spacing = 59
    local dot_color = self:_makeColor("#888888", 0x88)
    local w = self.dimen.w
    local h = self._draw_h
    local bb = self._canvas_bb
    for y = spacing, h - 2, spacing do
        for x = spacing, w - 2, spacing do
            bb:paintRect(x, y, 2, 2, dot_color)
        end
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- paintTo: MANUAL rendering. Toolbar guaranteed visible.
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:paintTo(bb, x, y)
    local dw = self.dimen.w
    local dh = self.dimen.h
    local face_lg = Font:getFace("cfont", 22)
    local face_md = Font:getFace("cfont", 18)
    local face_sm = Font:getFace("cfont", 14)
    local div_color = Blitbuffer.Color8(0xAA)

    -- 1. White background
    bb:paintRect(x, y, dw, dh, Blitbuffer.COLOR_WHITE)

    -- 2. Top bar: "✕" left, "Seal" right
    local discard_tw = TextWidget:new{ text = "✕", face = face_lg }
    discard_tw:paintTo(bb, x + 16, y + math.floor((TOPBAR_H - discard_tw:getSize().h) / 2))
    discard_tw:free()

    local seal_tw = TextWidget:new{ text = "Seal", face = face_md, bold = true }
    local seal_w = seal_tw:getSize().w
    seal_tw:paintTo(bb, x + dw - seal_w - 16, y + math.floor((TOPBAR_H - seal_tw:getSize().h) / 2))
    seal_tw:free()

    -- 3. Divider below top bar
    bb:paintRect(x, y + TOPBAR_H, dw, 1, div_color)

    -- 4. Canvas buffer
    bb:blitFrom(self._canvas_bb, x, y + self._draw_y, 0, 0, dw, self._draw_h)

    -- 5. Divider above toolbar
    bb:paintRect(x, y + self._toolbar_y - 1, dw, 1, div_color)

    -- 6. Toolbar background (explicit white so it's never transparent/grey)
    bb:paintRect(x, y + self._toolbar_y, dw, TOOLBAR_H, Blitbuffer.COLOR_WHITE)

    -- 7. Toolbar labels -- 5 equal zones, text centered in each
    local n_btns = self._device.has_color and 5 or 4
    local bw = math.floor(dw / n_btns)
    local labels = {
        "↩",
        self._tool == TOOL_ERASER and "[ERASER]" or "eraser",
        "[" .. PEN_WIDTHS[self._pen_idx].name .. "]",
    }
    -- For colour devices, use text-only name (swatch painted separately below)
    local color_btn_idx = nil
    if self._device.has_color then
        color_btn_idx = #labels + 1
        labels[#labels + 1] = PALETTE_NAMES[self._color_idx]
    end
    labels[#labels + 1] = "clear"

    for i, label in ipairs(labels) do
        local is_bold = (i == 2 and self._tool == TOOL_ERASER)
        local tw = TextWidget:new{ text = label, face = face_md, bold = is_bold }
        local tw_w = tw:getSize().w
        local tw_h = tw:getSize().h
        local tx = x + (i - 1) * bw + math.floor((bw - tw_w) / 2)
        local ty = y + self._toolbar_y + math.floor((TOOLBAR_H - tw_h) / 2)
        tw:paintTo(bb, tx, ty)
        tw:free()
    end

    -- 8. Paint a real coloured swatch rectangle for the colour button
    -- TextWidget can only render greyscale on e-ink, so we paint the actual
    -- RGB colour directly onto the framebuffer and trigger a dithered refresh.
    if color_btn_idx and self._device_has_color then
        local swatch_size = 20
        local btn_x = x + (color_btn_idx - 1) * bw
        local swatch_x = btn_x + 6
        local swatch_y = y + self._toolbar_y + math.floor((TOOLBAR_H - swatch_size) / 2)
        local p = PALETTE[self._color_idx]
        local sr, sg, sb = parseHex(p.hex)
        local swatch_color = Blitbuffer.ColorRGB32(sr, sg, sb, 0xFF)
        bb:paintRect(swatch_x, swatch_y, swatch_size, swatch_size, swatch_color)
        -- 1px border around swatch for visibility
        bb:paintRect(swatch_x - 1, swatch_y - 1, swatch_size + 2, 1, Blitbuffer.COLOR_BLACK)
        bb:paintRect(swatch_x - 1, swatch_y + swatch_size, swatch_size + 2, 1, Blitbuffer.COLOR_BLACK)
        bb:paintRect(swatch_x - 1, swatch_y, 1, swatch_size, Blitbuffer.COLOR_BLACK)
        bb:paintRect(swatch_x + swatch_size, swatch_y, 1, swatch_size, Blitbuffer.COLOR_BLACK)
        -- Schedule a colour refresh for the swatch area after paintTo completes
        self._swatch_rect = { x = swatch_x, y = swatch_y, w = swatch_size, h = swatch_size }
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Ink colour
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_updateInkVal()
    if self._tool == TOOL_ERASER then
        self._ink_val = self._bg_val or 0xFF
        -- Eraser uses bg colour explicitly constructed (never nil).
        if self._is_rgb and self._device.has_color then
            self._ink_color = Blitbuffer.ColorRGB32(0xF1, 0xED, 0xE5, 0xFF)
        else
            self._ink_color = Blitbuffer.Color8(self._bg_val or 0xFF)
        end
    elseif self._is_rgb and self._device.has_color then
        -- Full RGB colour from palette hex
        local p = PALETTE[self._color_idx]
        local r, g, b = parseHex(p.hex)
        self._ink_color = Blitbuffer.ColorRGB32(r, g, b, 0xFF)
        self._ink_val = p.grey  -- fallback for greyscale paths
        logger.warn(string.format("Tomo Canvas INK: color=%s idx=%d RGB=(%d,%d,%d)",
            PALETTE_NAMES[self._color_idx], self._color_idx, r, g, b))
    else
        self._ink_val = self._device.has_color and PALETTE[self._color_idx].grey or 0x00
        self._ink_color = Blitbuffer.Color8(self._ink_val)
    end
end

function ScreenCanvas:_currentWidth()
    if self._tool == TOOL_ERASER then
        return PEN_WIDTHS[self._pen_idx].width * 2
    end
    return PEN_WIDTHS[self._pen_idx].width
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Fast line drawing using native Blitbuffer methods
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_drawSegment(x1, y1, x2, y2, width, color)
    local bb = self._canvas_bb
    local half = math.floor(width / 2)

    if width <= 2 then
        -- Thin: Bresenham with paintRect per pixel
        local dx = math.abs(x2 - x1)
        local dy = math.abs(y2 - y1)
        local sx = x1 < x2 and 1 or -1
        local sy = y1 < y2 and 1 or -1
        local err = dx - dy
        while true do
            bb:paintRect(x1 - half, y1 - half, width, width, color)
            if x1 == x2 and y1 == y2 then break end
            local e2 = 2 * err
            if e2 > -dy then err = err - dy; x1 = x1 + sx end
            if e2 < dx  then err = err + dx; y1 = y1 + sy end
        end
    else
        -- Thick: paintCircle along path at intervals
        local dx = x2 - x1
        local dy = y2 - y1
        local dist = math.sqrt(dx * dx + dy * dy)
        local steps = math.max(1, math.floor(dist / math.max(1, half)))
        for i = 0, steps do
            local t = steps > 0 and (i / steps) or 0
            local cx = math.floor(x1 + dx * t + 0.5)
            local cy = math.floor(y1 + dy * t + 0.5)
            bb:paintCircle(cx, cy, half, color, half)
        end
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Dirty rect tracking
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_markDirty(cx, cy, radius)
    local r = radius + 2
    if not self._dirty then
        self._dirty = { x1 = cx - r, y1 = cy - r, x2 = cx + r, y2 = cy + r }
    else
        local d = self._dirty
        if cx - r < d.x1 then d.x1 = cx - r end
        if cy - r < d.y1 then d.y1 = cy - r end
        if cx + r > d.x2 then d.x2 = cx + r end
        if cy + r > d.y2 then d.y2 = cy + r end
    end
end

-- _flushDirty is no longer used for drawing -- kept as no-op for safety.
function ScreenCanvas:_flushDirty()
    self._dirty = nil
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Gesture handlers
-- v2.1.6: Direct Screen.bb writes + Screen:refreshFast (bypass UIManager)
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:onPan(_, ges)
    local gx = ges.pos.x
    local gy = ges.pos.y

    -- Only draw in the canvas zone (between top bar and toolbar)
    if gy <= self._draw_y or gy >= self._toolbar_y then return false end

    local cx = gx
    local cy = gy - self._draw_y  -- canvas-local Y coordinate

    -- New stroke detection by distance gap
    if self._cur_stroke and #self._cur_stroke > 0 and self._last_point then
        local ddx = cx - self._last_point.x
        local ddy = cy - self._last_point.y
        if ddx * ddx + ddy * ddy > NEW_STROKE_DIST_SQ then
            self._strokes[#self._strokes + 1] = {
                points = self._cur_stroke, tool = self._cur_stroke_tool,
                width = self._cur_stroke_width, ink = self._cur_stroke_ink,
                color_idx = self._cur_stroke_cidx,
            }
            self._cur_stroke = nil
        end
    end

    if not self._cur_stroke then
        self:_updateInkVal()
        self._cur_stroke = {}
        self._cur_stroke_tool = self._tool
        self._cur_stroke_width = self:_currentWidth()
        self._cur_stroke_ink = self._ink_color
        self._cur_stroke_cidx = self._color_idx
        self._stroke_dirty = nil
        self._pending_refresh = nil
    end

    local point = { x = cx, y = cy }
    self._cur_stroke[#self._cur_stroke + 1] = point
    self._total_points = self._total_points + 1

    local pw = self._cur_stroke_width
    local half = math.max(1, math.floor(pw / 2))

    -- During drawing: use black for pen (DU waveform = mono only on Kaleido 3).
    -- For eraser: use the actual background colour to overwrite existing strokes.
    -- Construct eraser colour explicitly to ensure it is never nil.
    local draw_color
    if self._tool == TOOL_ERASER then
        if self._is_rgb and self._device.has_color then
            draw_color = Blitbuffer.ColorRGB32(0xF1, 0xED, 0xE5, 0xFF)
        else
            draw_color = Blitbuffer.Color8(self._bg_val or 0xFF)
        end
    else
        draw_color = self._black_color
    end

    -- Get Screen.bb fresh each time (never cache -- may be replaced on rotation)
    local screen_bb = require("device").screen.bb
    local screen_obj = require("device").screen

    if #self._cur_stroke >= 2 then
        local prev = self._cur_stroke[#self._cur_stroke - 1]

        -- 1. Draw on _canvas_bb (persistence, undo, PNG export)
        self:_drawLineToBB(self._canvas_bb, prev.x, prev.y, cx, cy, pw, draw_color)

        -- 2. Draw on Screen.bb (immediate framebuffer write)
        local prev_sy = prev.y + self._draw_y
        self:_drawLineToBB(screen_bb, prev.x, prev_sy, gx, gy, pw, draw_color)

        -- 3. Compute dirty rect in screen coordinates for this segment
        local rx1 = math.max(0, math.min(prev.x, gx) - half - 1)
        local ry1 = math.max(0, math.min(prev_sy, gy) - half - 1)
        local rx2 = math.min(self.dimen.w, math.max(prev.x, gx) + half + 1)
        local ry2 = math.min(self.dimen.h, math.max(prev_sy, gy) + half + 1)

        -- 4. Accumulate this segment into the pending refresh rect and stroke dirty
        self:_expandPendingRefresh(rx1, ry1, rx2, ry2)
        self:_expandStrokeDirty(rx1, ry1, rx2, ry2)

        -- 5. THROTTLED refresh: only fire Screen:refreshFast every REFRESH_INTERVAL
        -- This prevents flooding the HWTCON controller with 1000+ ioctls per stroke.
        -- The pending rect grows between refreshes, so each one covers all new ink.
        self:_doThrottledRefresh(screen_obj)
    else
        -- First point of stroke: draw a dot and refresh immediately (no throttle)
        if half > 0 then
            self._canvas_bb:paintCircle(cx, cy, half, draw_color, half)
            screen_bb:paintCircle(gx, gy, half, draw_color, half)
        else
            self._canvas_bb:paintRect(cx, cy, 1, 1, draw_color)
            screen_bb:paintRect(gx, gy, 1, 1, draw_color)
        end
        local rx1 = math.max(0, gx - half - 1)
        local ry1 = math.max(0, gy - half - 1)
        local rw = half * 2 + 2
        local rh = half * 2 + 2
        self:_expandPendingRefresh(rx1, ry1, rx1 + rw, ry1 + rh)
        self:_expandStrokeDirty(rx1, ry1, rx1 + rw, ry1 + rh)
        self._last_refresh_time = 0  -- force immediate refresh for first point
        self:_doThrottledRefresh(screen_obj)
    end

    self._last_point = point
    return true
end

function ScreenCanvas:onPanRelease(_, ges)
    if self._cur_stroke and #self._cur_stroke > 0 then
        -- Save the completed stroke
        self._strokes[#self._strokes + 1] = {
            points = self._cur_stroke, tool = self._cur_stroke_tool,
            width = self._cur_stroke_width, ink = self._cur_stroke_ink,
            color_idx = self._cur_stroke_cidx,
        }

        logger.warn(string.format(
            "Tomo Canvas: stroke done, %d points, %d refreshFast calls (throttled)",
            #self._cur_stroke, self._refresh_count or 0))

        -- Flush any pending throttled refresh before colour repaint
        local screen_obj = require("device").screen
        if self._pending_refresh then
            local p = self._pending_refresh
            if screen_obj.refreshFast then
                screen_obj:refreshFast(p.x, p.y, p.w, p.h)
            end
            self._pending_refresh = nil
        end

        -- DEFERRED COLOUR: repaint the stroke in its intended RGB colour.
        -- During onPan, strokes were drawn in black (DU waveform = mono only).
        -- Now repaint in the actual colour on both buffers.
        local color = self._cur_stroke_ink
        local pw = self._cur_stroke_width
        local pts = self._cur_stroke
        local screen_bb = require("device").screen.bb
        local screen_obj = require("device").screen
        local dy = self._draw_y

        -- Only repaint if not eraser and not black (avoid unnecessary work)
        local is_eraser = self._cur_stroke_tool == TOOL_ERASER
        if not is_eraser then
            for i = 2, #pts do
                local p1, p2 = pts[i-1], pts[i]
                -- Repaint on _canvas_bb in intended colour
                self:_drawLineToBB(self._canvas_bb, p1.x, p1.y, p2.x, p2.y, pw, color)
                -- Repaint on Screen.bb in intended colour
                self:_drawLineToBB(screen_bb, p1.x, p1.y + dy, p2.x, p2.y + dy, pw, color)
            end
            if #pts == 1 then
                local half = math.max(1, math.floor(pw / 2))
                self._canvas_bb:paintCircle(pts[1].x, pts[1].y, half, color, half)
                screen_bb:paintCircle(pts[1].x, pts[1].y + dy, half, color, half)
            end
        end

        -- Trigger colour refresh on the stroke's bounding box.
        -- Scheduled via UIManager so it fires AFTER the event handler returns,
        -- preventing ~450ms GCC16 waveform from blocking new pen input.
        if self._stroke_dirty then
            local sd_x = math.max(0, self._stroke_dirty.x)
            local sd_y = math.max(0, self._stroke_dirty.y)
            local sd_w = math.min(self.dimen.w - sd_x, self._stroke_dirty.w)
            local sd_h = math.min(self.dimen.h - sd_y, self._stroke_dirty.h)
            local has_color = self._device_has_color and not is_eraser
            if sd_w > 0 and sd_h > 0 then
                UIManager:scheduleIn(0.05, function()
                    local so = require("device").screen
                    if has_color then
                        logger.warn(string.format(
                            "Tomo Canvas: COLOUR REFRESH (deferred), dither=true, region=(%d,%d,%d,%d)",
                            sd_x, sd_y, sd_w, sd_h))
                        if so.refreshPartial then
                            so:refreshPartial(sd_x, sd_y, sd_w, sd_h, true)
                        else
                            UIManager:setDirty(self, "ui")
                        end
                    else
                        if so.refreshUI then
                            so:refreshUI(sd_x, sd_y, sd_w, sd_h)
                        else
                            UIManager:setDirty(self, "ui")
                        end
                    end
                end)
            end
        else
            UIManager:setDirty(self, "ui")
        end
    end

    self._cur_stroke = nil
    self._last_point = nil
    self._stroke_dirty = nil
    self._refresh_count = 0
    self._dirty = nil
    return true
end

function ScreenCanvas:onTap(_, ges)
    local gx = ges.pos.x
    local gy = ges.pos.y
    local dw = self.dimen.w

    if gy < TOPBAR_H then
        -- TOP BAR ZONE
        if gx < 100 then
            self:_confirmDiscard()
        elseif gx > dw - 150 then
            self:_confirmSeal()
        end
        return true
    elseif gy >= self._toolbar_y then
        -- TOOLBAR ZONE -- divide into equal button zones
        local n_btns = self._device.has_color and 5 or 4
        local bw = math.floor(dw / n_btns)
        local btn = math.floor(gx / bw) + 1
        if btn == 1 then
            self:_undoLastStroke()
        elseif btn == 2 then
            self._tool = self._tool == TOOL_ERASER and TOOL_PEN or TOOL_ERASER
            self:_updateInkVal()
            UIManager:setDirty(self, "ui")
        elseif btn == 3 then
            self._pen_idx = (self._pen_idx % #PEN_WIDTHS) + 1
            UIManager:setDirty(self, "ui")
        elseif btn == 4 then
            if self._device.has_color then
                self._color_idx = (self._color_idx % #PALETTE) + 1
                self:_updateInkVal()
            else
                self:_confirmClear()
            end
            UIManager:setDirty(self, "ui")
            -- Trigger colour refresh for the swatch after the ui repaint
            if self._device_has_color then
                UIManager:scheduleIn(0.3, function()
                    local ok, err = pcall(function()
                        if not self or not self[1] then return end
                        if self._swatch_rect then
                            local sr = self._swatch_rect
                            local so = require("device").screen
                            if so.refreshPartial then
                                so:refreshPartial(sr.x, sr.y, sr.w, sr.h, true)
                            end
                        end
                    end)
                    if not ok then logger.warn("Tomo: scheduled callback error: " .. tostring(err)) end
                end)
            end
        elseif btn == 5 then
            self:_confirmClear()
        end
        return true
    else
        -- CANVAS ZONE -- draw a dot (write to both buffers + direct refresh)
        local cy = gy - self._draw_y
        if cy >= 0 and cy < self._draw_h then
            self:_updateInkVal()
            local w = self:_currentWidth()
            local half = math.max(1, math.floor(w / 2))
            local ink = self._ink_color
            -- Draw on _canvas_bb
            self._canvas_bb:paintCircle(gx, cy, half, ink, half)
            -- Draw on Screen.bb
            local screen_bb = require("device").screen.bb
            local screen_obj = require("device").screen
            screen_bb:paintCircle(gx, gy, half, ink, half)
            -- Direct refresh for the dot
            local rx = math.max(0, gx - half - 1)
            local ry_s = math.max(0, gy - half - 1)
            local rw = half * 2 + 2
            local rh = half * 2 + 2
            if self._device_has_color then
                -- Single dot: use dithered refresh directly for colour
                if screen_obj.refreshPartial then
                    screen_obj:refreshPartial(rx, ry_s, rw, rh, true)
                else
                    UIManager:setDirty(self, "ui")
                end
            else
                if screen_obj.refreshFast then
                    screen_obj:refreshFast(rx, ry_s, rw, rh)
                else
                    UIManager:setDirty(self, "ui")
                end
            end
            self._strokes[#self._strokes + 1] = {
                points = { { x = gx, y = cy } }, tool = self._tool,
                width = w, ink = ink, color_idx = self._color_idx,
            }
            self._total_points = self._total_points + 1
            self._last_point = nil
        end
        return true
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Undo & Clear
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_undoLastStroke()
    if #self._strokes == 0 then return end
    local removed = table.remove(self._strokes)
    self._total_points = self._total_points - #removed.points
    self:_redrawCanvas()
    UIManager:setDirty(self, "ui")
end

function ScreenCanvas:_confirmClear()
    if #self._strokes == 0 then return end
    UIManager:show(ConfirmBox:new{
        text = "Clear the page?", ok_text = "Clear", cancel_text = "Cancel",
        ok_callback = function()
            self._strokes = {}; self._total_points = 0; self._last_point = nil
            self:_redrawCanvas(); UIManager:setDirty(self, "ui")
        end,
    })
end

function ScreenCanvas:_redrawCanvas()
    self:_fillBg()
    self:_drawDotGrid()
    local bb = self._canvas_bb
    for _, stroke in ipairs(self._strokes) do
        local ink = stroke.ink or Blitbuffer.COLOR_BLACK
        local pts = stroke.points
        local w = stroke.width or 4
        for i = 2, #pts do
            self:_drawSegment(pts[i-1].x, pts[i-1].y, pts[i].x, pts[i].y, w, ink)
        end
        if #pts == 1 then
            local half = math.max(1, math.floor(w / 2))
            bb:paintCircle(pts[1].x, pts[1].y, half, ink, half)
        end
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Discard & Seal
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_confirmDiscard()
    if #self._strokes == 0 then
        UIManager:close(self); UIManager:setDirty(nil, "full"); return
    end
    UIManager:show(ConfirmBox:new{
        text = "Discard this letter?", ok_text = "Discard", cancel_text = "Keep writing",
        ok_callback = function() UIManager:close(self); UIManager:setDirty(nil, "full") end,
    })
end

function ScreenCanvas:onConfirmDiscard()
    self:_confirmDiscard(); return true
end

function ScreenCanvas:_confirmSeal()
    if #self._strokes == 0 then return end
    if self._sealing then return end  -- debounce: block double taps
    if self._total_points < MIN_STROKE_POINTS then
        UIManager:show(ConfirmBox:new{
            text = "A letter this short might not say much. Keep writing?",
            ok_text = "Send anyway", cancel_text = "Keep writing",
            ok_callback = function() self:_showSealConfirm() end,
        }); return
    end
    self:_showSealConfirm()
end

function ScreenCanvas:_showSealConfirm()
    local who = self.is_postcrossing and "a fellow reader" or (self.partner_name or "your pen pal")
    UIManager:show(ConfirmBox:new{
        text = "Seal this letter and send it to " .. who .. "?\n\nOnce sealed, it cannot be unsent.",
        ok_text = "Seal", cancel_text = "Keep writing",
        ok_callback = function() self:_doSeal() end,
    })
end

function ScreenCanvas:_doSeal()
    if self._sealing then return end
    self._sealing = true
    local Recorder = require("core/recorder")
    local ok_ds, DataStorage = pcall(require, "datastorage")
    local data_dir = ok_ds and DataStorage:getDataDir() or "/tmp"
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id then
        UIManager:show(InfoMessage:new{ text = "Not authenticated.", timeout = 3 }); return
    end
    local lt = self.is_postcrossing and "postcrossing" or "penpal"
    Recorder.log("MESSAGE", "Sealing " .. lt .. " ink letter")
    local tmp_png = data_dir .. "/tomo_ink_" .. tostring(os.time()) .. ".png"
    local ok, err = self:_exportToPNG(tmp_png)
    if not ok then
        logger.warn("Tomo Canvas: PNG export failed: " .. tostring(err))
        UIManager:show(InfoMessage:new{ text = "Could not save letter.", timeout = 3 }); return
    end
    self:_compressToTarget(tmp_png, 150)
    local device_ts = os.date("!%Y-%m-%dT%H:%M:%SZ")
    if self.is_postcrossing then self:_doPostcrossingSend(tmp_png, device_ts)
    else self:_doPenpalSend(tmp_png, device_ts) end
end

function ScreenCanvas:_doPenpalSend(png_path, device_ts)
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id then return end
    local room_id = self.room_id
    math.randomseed(os.time())
    local delivers_at = os.date("!%Y-%m-%dT%H:%M:%SZ", os.time() + math.random(6*3600, 18*3600))
    self.tomo._cache:enqueue(room_id, "ink", nil, png_path, device_ts)
    UIManager:close(self); UIManager:setDirty(nil, "full")
    UIManager:show(InfoMessage:new{
        text = "Letter sent. It will arrive in a few hours.",
        timeout = 4,
    })
    if self.on_send then pcall(self.on_send) end
    if self.tomo.state.online then
        UIManager:scheduleIn(0.1, function()
            local ok, err = pcall(function()
                if not self or not self.tomo then return end
                local sp = user_id .. "/" .. tostring(os.time()) .. ".png"
                self.tomo._api:uploadInkImage(png_path, sp, function(ue, key)
                    if ue then logger.warn("Tomo: upload failed: " .. tostring(ue)); return end
                    self.tomo._api:sendInkLetter(room_id, key or sp, device_ts, delivers_at, function(se)
                        if se then logger.warn("Tomo: sendInkLetter failed: " .. tostring(se)) end
                        os.remove(png_path)
                    end)
                end)
            end)
            if not ok then logger.warn("Tomo: scheduled callback error: " .. tostring(err)) end
        end)
    end
end

function ScreenCanvas:_doPostcrossingSend(png_path, device_ts)
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id then return end
    UIManager:close(self); UIManager:setDirty(nil, "full")
    UIManager:show(InfoMessage:new{
        text = "Your letter is on its way to a fellow reader somewhere.",
        timeout = 4,
    })
    if self.on_send then pcall(self.on_send) end
    if self.tomo.state.online then
        UIManager:scheduleIn(0.1, function()
            local ok, err = pcall(function()
                if not self or not self.tomo then return end
                local sp = "postcrossing/" .. user_id .. "/" .. tostring(os.time()) .. ".png"
                self.tomo._api:uploadInkImage(png_path, sp, function(ue, key)
                    if ue then logger.warn("Tomo: pc upload failed: " .. tostring(ue)); return end
                    self.tomo._api:sendPostcrossingLetter(key or sp, function(pe)
                        if not pe then self.tomo._api:claimPostcrossingLetter(function() end) end
                        os.remove(png_path)
                    end)
                end)
            end)
            if not ok then logger.warn("Tomo: scheduled callback error: " .. tostring(err)) end
        end)
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- PNG export
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:_getContentBounds()
    local bb = self._canvas_bb
    local w, h = self.dimen.w, self._draw_h
    local x1, y1, x2, y2 = w, h, 0, 0
    local found = false

    -- On RGB buffers, compare each pixel's RGB channels against the background
    -- colour directly. Using getColor8().a on RGB pixels loses colour information
    -- and can miss coloured ink that happens to have similar luminance to the bg.
    if self._is_rgb and self._bg_color then
        local bg_r = self._bg_color:getColorRGB32().r
        local bg_g = self._bg_color:getColorRGB32().g
        local bg_b = self._bg_color:getColorRGB32().b
        local threshold = 20  -- per-channel distance from bg
        for y = 0, h - 1 do
            for x = 0, w - 1 do
                local px = bb:getPixel(x, y):getColorRGB32()
                local dr = math.abs(px.r - bg_r)
                local dg = math.abs(px.g - bg_g)
                local db = math.abs(px.b - bg_b)
                if dr > threshold or dg > threshold or db > threshold then
                    found = true
                    if x < x1 then x1 = x end; if x > x2 then x2 = x end
                    if y < y1 then y1 = y end; if y > y2 then y2 = y end
                end
            end
        end
    else
        -- Greyscale path: compare grey value against background
        local threshold = self._bg_val - 20
        for y = 0, h - 1 do
            for x = 0, w - 1 do
                if bb:getPixel(x, y):getColor8().a < threshold then
                    found = true
                    if x < x1 then x1 = x end; if x > x2 then x2 = x end
                    if y < y1 then y1 = y end; if y > y2 then y2 = y end
                end
            end
        end
    end

    if not found then return nil end
    return {
        x1 = math.max(0, x1 - 16), y1 = math.max(0, y1 - 16),
        x2 = math.min(w - 1, x2 + 16), y2 = math.min(h - 1, y2 + 16),
    }
end

function ScreenCanvas:_exportToPNG(path)
    local bounds = self:_getContentBounds()
    if not bounds then return false, "empty canvas" end
    local cw, ch = bounds.x2 - bounds.x1, bounds.y2 - bounds.y1
    if cw <= 0 or ch <= 0 then return false, "zero-size" end
    local cropped = Blitbuffer.new(cw, ch, self._canvas_bb:getType())
    cropped:blitFrom(self._canvas_bb, 0, 0, bounds.x1, bounds.y1, cw, ch)
    local ok = pcall(function() cropped:writePNG(path) end)
    if ok then cropped:free(); return true end
    local ok2, Mupdf = pcall(require, "ffi/mupdf")
    if ok2 and Mupdf and Mupdf.pixmapFromBlitbuffer then
        local ok3 = pcall(function()
            Mupdf.writePixmapToPNG(Mupdf.pixmapFromBlitbuffer(cropped), path)
        end)
        cropped:free()
        if ok3 then return true end
    else cropped:free() end
    local pgm = path .. ".pgm"
    local f = io.open(pgm, "wb")
    if not f then return false, "cannot write PGM" end
    f:write(string.format("P5\n%d %d\n255\n", cw, ch))
    for y = bounds.y1, bounds.y2 - 1 do
        for x = bounds.x1, bounds.x2 - 1 do
            f:write(string.char(self._canvas_bb:getPixel(x, y):getColor8().a))
        end
    end
    f:close()
    os.execute(string.format('pnmtopng "%s" > "%s" 2>/dev/null || convert "%s" "%s" 2>/dev/null', pgm, path, pgm, path))
    os.remove(pgm)
    local fc = io.open(path, "r")
    if fc then fc:close(); return true end
    return false, "PNG conversion failed"
end

function ScreenCanvas:_compressToTarget(path, target_kb)
    local ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok then return end
    local size = lfs.attributes(path, "size")
    if not size or size <= target_kb * 1024 then return end
    local tmp = path .. ".q.png"
    os.execute(string.format('pngquant --quality=50-80 --speed 1 --output "%s" "%s" 2>/dev/null', tmp, path))
    local cs = lfs.attributes(tmp, "size")
    if cs and cs < size then os.rename(tmp, path) else os.remove(tmp) end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenCanvas:onShow()
    UIManager:setDirty(self, "full")
    -- After full refresh, trigger a colour refresh for the swatch
    if self._swatch_rect and self._device_has_color then
        UIManager:scheduleIn(0.5, function()
            local ok, err = pcall(function()
                if not self or not self[1] then return end
                local sr = self._swatch_rect
                if sr then
                    local screen_obj = require("device").screen
                    if screen_obj.refreshPartial then
                        screen_obj:refreshPartial(sr.x, sr.y, sr.w, sr.h, true)
                    end
                end
            end)
            if not ok then logger.warn("Tomo: scheduled callback error: " .. tostring(err)) end
        end)
    end
    return true
end

function ScreenCanvas:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenCanvas]: self[1] nil on resume, skipping (no _build)")
    end
    return true
end

function ScreenCanvas:onClose()
    if self._canvas_bb then self._canvas_bb:free(); self._canvas_bb = nil end
    UIManager:close(self); UIManager:setDirty(nil, "full"); return true
end

function ScreenCanvas:onCloseWidget()
    if self._canvas_bb then self._canvas_bb:free(); self._canvas_bb = nil end
end

return ScreenCanvas
