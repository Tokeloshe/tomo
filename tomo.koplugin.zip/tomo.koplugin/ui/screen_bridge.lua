-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_bridge.lua
-- Screen 8 -- Reader Bridge (橋 Hashi, Bridge). A leaf falls past the window.
--
-- An opt-in overlay shown while reading when a message arrives.
-- Default: OFF. Must be enabled in Settings > Notifications > While reading.
--
-- Appearance:
--   [light grey blurred overlay covering reading content]
--   ┌────────────────────────┐
--   │  友 Fantasy & Sci-Fi   │
--   │  Something new    [→]  │
--   └────────────────────────┘
--   [auto-dismisses in 6 seconds, appears at most once per 60 minutes per room]
--
-- MASTERPLAN.md §Screen 8:
--   "The bridge no longer shows the message content or the sender's name."
--   "Simply says: something happened. You decide."
--   For pen pal letters: "✦ A letter has arrived" (no room name, no sender).

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local TextWidget      = require("ui/widget/textwidget")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Screen          = require("device").screen
local Blitbuffer      = require("ffi/blitbuffer")

local Theme = require("ui/theme")

-- Per-room timestamps of the last bridge shown: { [room_id] = os.time() }
-- Module-level so it persists across bridge instantiations within a session.
local _last_shown = {}

local ScreenBridge = InputContainer:extend{
    name      = "tomo_bridge",
    dimen     = nil,
    tomo      = nil,
    room_id   = nil,
    room_name = nil,
    is_penpal = false,       -- True for pen pal letter arrivals
    _dismiss_fn = nil,       -- Scheduled auto-dismiss function reference
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Guard: should a bridge appear right now?
-- ─────────────────────────────────────────────────────────────────────────────

-- Return true if the bridge is allowed to appear for this room right now.
-- Rules:
--   1. Settings: notif_while_reading must be ON (default OFF).
--   2. At most once per 60 minutes per room.
function ScreenBridge.shouldShow(cache, room_id, config)
    -- Check settings preference.
    local ScreenSettings = require("ui/screen_settings")
    local prefs = ScreenSettings.loadPrefs(cache)
    if not prefs.notif_while_reading then return false end

    -- Check cooldown.
    local cooldown_s = (config.bridge_cooldown_min or 60) * 60
    local last = _last_shown[room_id]
    if last and (os.time() - last) < cooldown_s then return false end

    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Init
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenBridge:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()

    -- Register the room/time so the cooldown starts from now.
    _last_shown[self.room_id] = os.time()

    -- _init() already ran: _ordered_touch_zones, ges_events, key_events are set.
    -- Consume all touch events so they do not pass through to the reader.
    self.ges_events = {
        Tap = { GestureRange:new{ ges = "tap", range = self.dimen } },
    }
    self.key_events = {}

    self:_build()

    -- Auto-dismiss after 6 seconds (MASTERPLAN.md §Screen 8).
    local function autoDismiss()
        UIManager:close(self)
    end
    self._dismiss_fn = autoDismiss
    UIManager:scheduleIn(6, autoDismiss)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Build
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenBridge:_build()
    local dw = self.dimen.w
    local dh = self.dimen.h

    -- Full-screen semi-opaque grey background.
    -- Drawn as solid light grey (not semi-transparent alpha) to avoid slow
    -- alpha blending on Kobo CPUs. SKILLS.md §4.5 documents this approach.
    local overlay_bg = Blitbuffer.Color8(0xCC)

    -- Card dimensions.
    local HorizontalSpan = require("ui/widget/horizontalspan")
    local card_w = math.floor(dw * 0.7)
    local inner_w = card_w - Theme.space.md * 2

    -- Card text.
    local line1_text, line2_text
    if self.is_penpal then
        line1_text = "A letter has arrived"
        line2_text = ""
    else
        line1_text = Theme.glyph.logo .. " " .. (self.room_name or "Room")
        line2_text = "Something new"
    end

    -- "→" button to open the room.
    local open_btn = Button:new{
        text           = "→",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.room,
        bordersize     = 0,
        padding        = Theme.space.sm,
        callback       = function()
            self:_openRoom()
        end,
    }

    -- Build "Something new  →" on the same line with a spacer between.
    local line2_widget = TextWidget:new{
        text  = line2_text,
        face  = Theme.face(Theme.font.size.body),
    }
    local btn_w = open_btn:getSize().w
    local line2_w = line2_widget:getSize().w
    local line2_spacer = math.max(Theme.space.sm, inner_w - line2_w - btn_w)

    local card_inner = VerticalGroup:new{
        align = "left",
        FrameContainer:new{
            bordersize = 0,
            padding    = Theme.space.md,
            padding_bottom = 0,
            TextWidget:new{
                text  = line1_text,
                face  = Theme.face(Theme.font.size.room),
                width = inner_w,
            },
        },
        FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_bottom = Theme.space.md,
            HorizontalGroup:new{
                align = "center",
                line2_widget,
                HorizontalSpan:new{ width = line2_spacer },
                open_btn,
            },
        },
    }

    local card = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = dh },
        FrameContainer:new{
            width      = card_w,
            bordersize = 1,
            padding    = 0,
            background = Blitbuffer.COLOR_WHITE,
            card_inner,
        },
    }

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = overlay_bg,
        card,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Actions
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenBridge:_openRoom()
    UIManager:unschedule(self._dismiss_fn)
    UIManager:close(self)

    if self.is_penpal then
        local ScreenPenpal = require("ui/screen_penpal")
        UIManager:show(ScreenPenpal:new{ tomo = self.tomo })
    else
        local ScreenRoom = require("ui/screen_room")
        UIManager:show(ScreenRoom:new{
            tomo    = self.tomo,
            room_id = self.room_id,
        })
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenBridge:onTap(_, ges)
    -- Any tap that is not on the "→" button dismisses the overlay.
    UIManager:unschedule(self._dismiss_fn)
    UIManager:close(self)
    return true
end

function ScreenBridge:onCloseWidget()
    -- Cancel the auto-dismiss in case the widget was closed by another path.
    if self._dismiss_fn then
        UIManager:unschedule(self._dismiss_fn)
    end
end

function ScreenBridge:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenBridge]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenBridge:onShow()
    -- Use flashui for the bridge overlay -- fast refresh with less ghosting.
    UIManager:setDirty(self, "flashui")
    return true
end

return ScreenBridge
