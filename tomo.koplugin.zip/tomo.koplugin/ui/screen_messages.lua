-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_messages.lua
-- Messages inbox -- all received pen pal and postcrossing letters in one place.
-- Paginated like other Tomo screens (tap left/right to navigate pages).

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local TextWidget      = require("ui/widget/textwidget")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")

local ScreenMessages = InputContainer:extend{
    name      = "tomo_messages",
    dimen     = nil,
    tomo      = nil,
    _letters  = {},
    _page     = 1,
    _per_page = 6,
}

function ScreenMessages:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._width  = self.dimen.w - Theme.space.md * 2

    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
        Tap   = { GestureRange:new{ ges = "tap", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

-- Vague relative timestamp
local function relativeTime(iso_ts)
    if not iso_ts then return "" end
    local y, mo, d, h, mi, s = iso_ts:match("(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d):(%d%d)")
    if not y then return "" end
    local diff = os.time() - os.time{
        year = tonumber(y), month = tonumber(mo), day = tonumber(d),
        hour = tonumber(h), min = tonumber(mi), sec = tonumber(s),
    }
    if diff < 300        then return "just now"
    elseif diff < 3600   then return "recently"
    elseif diff < 86400  then return "a while ago"
    elseif diff < 172800 then return "yesterday"
    elseif diff < 604800 then return "a few days ago"
    elseif diff < 2592000 then return "last week"
    else                      return "last month"
    end
end

function ScreenMessages:_build()
    local bg = Theme.pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local w  = self._width
    local dw = self.dimen.w
    local dh = self.dimen.h

    local back_row = Components.backRow("Messages", function()
        UIManager:close(self)
        UIManager:setDirty(nil, "full")
    end, dw)

    local list = VerticalGroup:new{ align = "left" }
    list[#list + 1] = VerticalSpan:new{ width = Theme.space.md }

    local total_pages = math.max(1, math.ceil(#self._letters / self._per_page))

    if #self._letters == 0 then
        list[#list + 1] = FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            padding_top = Theme.space.xl,
            CenterContainer:new{
                dimen = Geom:new{ w = w, h = 100 },
                TextWidget:new{
                    text    = "No letters yet.",
                    face    = Theme.face(Theme.font.size.body),
                    fgcolor = Theme.blitColor(Theme.color.text_whisper),
                },
            },
        }
    else
        local start_idx = (self._page - 1) * self._per_page + 1
        local end_idx   = math.min(self._page * self._per_page, #self._letters)
        for i = start_idx, end_idx do
            local letter = self._letters[i]
            local sender = letter.username or letter.sender_username or "reader"
            local ts = relativeTime(letter.created_at or letter.delivered_at)
            local preview = letter.kind == "ink" and "Ink letter" or (letter.body or ""):sub(1, 40)
            local row_text = sender .. "  ·  " .. ts
            if preview ~= "" then
                row_text = row_text .. "\n" .. preview
            end

            list[#list + 1] = FrameContainer:new{
                bordersize   = 0,
                padding_left = Theme.space.md,
                padding_right = Theme.space.md,
                padding_top  = Theme.space.sm,
                padding_bottom = Theme.space.sm,
                Button:new{
                    text           = row_text,
                    text_font_face = "cfont",
                    text_font_size = Theme.font.size.body,
                    bordersize     = 0,
                    padding        = Theme.space.sm,
                    width          = w,
                    align          = "left",
                    callback       = function() end,
                },
            }
            list[#list + 1] = FrameContainer:new{
                bordersize = 0,
                padding_left = Theme.space.md,
                padding_right = Theme.space.md,
                Components.divider(w, self._device),
            }
        end
    end

    local page_indicator = nil
    if total_pages > 1 then
        page_indicator = Components.pageIndicator(self._page, total_pages, dw)
    end

    local content = VerticalGroup:new{ align = "left" }
    content[#content + 1] = back_row
    content[#content + 1] = FrameContainer:new{
        bordersize = 0, padding_left = Theme.space.md, padding_right = Theme.space.md,
        Components.divider(w, self._device),
    }
    content[#content + 1] = list
    if page_indicator then
        content[#content + 1] = VerticalSpan:new{ width = Theme.space.sm }
        content[#content + 1] = page_indicator
    end

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        content,
    }
end

function ScreenMessages:onTap(_, ges)
    local y = ges.pos.y
    local dh = self.dimen.h
    if y < dh * 0.15 or y > dh * 0.85 then return false end
    local total_pages = math.max(1, math.ceil(#self._letters / self._per_page))
    if total_pages <= 1 then return false end
    if ges.pos.x > self.dimen.w / 2 then
        if self._page < total_pages then self._page = self._page + 1; self:_rebuild() end
    else
        if self._page > 1 then self._page = self._page - 1; self:_rebuild() end
    end
    return true
end

function ScreenMessages:_loadLetters()
    if not self.tomo.state.online or not self.tomo.state.user then return end
    local user_id = self.tomo.state.user.id

    -- Load pen pal letters
    local bond = nil
    self.tomo._api:getPenpalBond(user_id, function(err, b)
        bond = b
        if bond and bond.room_id then
            self.tomo._api:getDeliveredLetters(bond.room_id, 20, function(err2, letters)
                if not err2 and letters then
                    for _, l in ipairs(letters) do
                        l._source = "penpal"
                        self._letters[#self._letters + 1] = l
                    end
                end
                -- Also load postcrossing
                self:_loadPostcrossing()
            end)
        else
            self:_loadPostcrossing()
        end
    end)
end

function ScreenMessages:_loadPostcrossing()
    self.tomo._api:getPostcrossingReceived(function(err, letters)
        if not err and letters then
            for _, l in ipairs(letters) do
                l._source = "postcrossing"
                l.username = l.sender_username
                self._letters[#self._letters + 1] = l
            end
        end
        -- Sort all letters by date, newest first
        table.sort(self._letters, function(a, b)
            return (a.created_at or a.delivered_at or "") > (b.created_at or b.delivered_at or "")
        end)
        self._page = 1
        self:_rebuild()
    end)
end

function ScreenMessages:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenMessages]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenMessages:onShow()
    self:_loadLetters()
    UIManager:setDirty(self, "full")
    return true
end

function ScreenMessages:onSwipe(_, ges)
    if ges.direction == "east" then
        self:onClose()
        return true
    end
end

function ScreenMessages:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    return true
end

function ScreenMessages:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

return ScreenMessages
