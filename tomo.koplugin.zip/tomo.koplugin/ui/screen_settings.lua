-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_settings.lua
-- Screen 7 -- Settings (静 Shizuka, Quiet). Preferences that recede into background.
--
-- Layout (MASTERPLAN.md §Screen 7):
--   ← Back
--   "Tomo™ reads nothing about your reading that you do not choose to share."
--   ──────────────────────
--   Notifications
--   While reading      [off]   ← default off
--   Pen pal letters    [on ]
--   Reading
--   Share current book [on ]
--   Display
--   Font size          [med]
--   Message spacing    [open]
--   Account
--   Export my data →
--   Leave Tomo →

local InputContainer      = require("ui/widget/container/inputcontainer")
local FrameContainer      = require("ui/widget/container/framecontainer")
local ScrollableContainer = require("ui/widget/container/scrollablecontainer")
local VerticalGroup       = require("ui/widget/verticalgroup")
local HorizontalGroup     = require("ui/widget/horizontalgroup")
local TextWidget          = require("ui/widget/textwidget")
local TextBoxWidget       = require("ui/widget/textboxwidget")
local Button              = require("ui/widget/button")
local GestureRange        = require("ui/gesturerange")
local Geom                = require("ui/geometry")
local UIManager           = require("ui/uimanager")
local Device              = require("device")
local Screen              = Device.screen
local Blitbuffer          = require("ffi/blitbuffer")
local VerticalSpan        = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")

local ScreenSettings = InputContainer:extend{
    name  = "tomo_settings",
    dimen = nil,
    tomo  = nil,
    -- Settings state (loaded from cache on init, persisted on change).
    _prefs = nil,
}

-- Default preferences. Loaded from cache; these are the fallbacks.
local DEFAULT_PREFS = {
    notif_while_reading = false,  -- Off by default (MASTERPLAN.md §Screen 7)
    notif_penpal        = true,
    share_current_book  = true,
    font_size           = "med",   -- "small" | "med" | "large"
    message_spacing     = "open",  -- "open" | "close"
}

function ScreenSettings:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._width  = self.dimen.w - Theme.space.md * 2

    -- Load preferences from cache.
    self._prefs = {}
    local cache = self.tomo._cache
    for key, default in pairs(DEFAULT_PREFS) do
        local stored = cache:getState("pref_" .. key)
        if stored ~= nil then
            -- Convert stored string back to boolean/string.
            if stored == "true" then
                self._prefs[key] = true
            elseif stored == "false" then
                self._prefs[key] = false
            else
                self._prefs[key] = stored
            end
        else
            self._prefs[key] = default
        end
    end

    -- _init() already ran: _ordered_touch_zones, ges_events, key_events are set.
    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Build
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenSettings:_build()
    local bg = require("ui/theme").pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local w  = self._width
    local dw = self.dimen.w
    local dh = self.dimen.h
    local p  = self._prefs

    -- ── Back ──────────────────────────────────────────────────────────────────
    local back_row = Components.backRow("Back", function()
        UIManager:close(self)
    end, dw)

    -- ── Privacy statement ─────────────────────────────────────────────────────
    -- This is not boilerplate. It is a structural honesty statement that also
    -- serves as an architectural constraint (MASTERPLAN.md §Screen 7).
    local privacy_text = "Tomo reads nothing you do not choose to share."
    local privacy_widget = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        padding_right = Theme.space.md,
        padding_top  = Theme.space.md,
        TextBoxWidget:new{
            text      = privacy_text,
            face      = Theme.face(Theme.font.size.body),
            width     = w - Theme.space.md,
            alignment = "left",
        },
    }

    -- ── Helpers ───────────────────────────────────────────────────────────────
    local function div()
        return FrameContainer:new{
            bordersize   = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.md,
            Components.divider(w, self._device),
        }
    end

    local function section_head(text)
        return FrameContainer:new{
            bordersize   = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.md,
            Components.sectionHeader(text, w),
        }
    end

    -- A toggle row: "Label   [on] / [off]"
    local HorizontalSpan = require("ui/widget/horizontalspan")
    local function toggle_row(label, pref_key)
        local val  = p[pref_key]
        local text = val and "[on ]" or "[off]"
        return FrameContainer:new{
            bordersize   = 0,
            padding_left = Theme.space.md,
            HorizontalGroup:new{
                align = "center",
                TextWidget:new{
                    text  = label,
                    face  = Theme.face(Theme.font.size.body),
                    width = w - 80,
                },
                HorizontalSpan:new{ width = Theme.space.sm },
                Button:new{
                    text           = text,
                    text_font_face = "cfont",
                    text_font_size = Theme.font.size.body,
                    bordersize     = 0,
                    padding        = 0,
                    callback       = function()
                        p[pref_key] = not p[pref_key]
                        self:_savePref(pref_key, p[pref_key])
                        self:_rebuild()
                    end,
                },
            },
        }
    end

    -- A choice row: cycles through options.
    local function choice_row(label, pref_key, options)
        local val  = p[pref_key]
        return FrameContainer:new{
            bordersize   = 0,
            padding_left = Theme.space.md,
            HorizontalGroup:new{
                align = "center",
                TextWidget:new{
                    text  = label,
                    face  = Theme.face(Theme.font.size.body),
                    width = w - 100,
                },
                HorizontalSpan:new{ width = Theme.space.sm },
                Button:new{
                    text           = "[" .. tostring(val) .. "]",
                    text_font_face = "cfont",
                    text_font_size = Theme.font.size.body,
                    bordersize     = 0,
                    padding        = 0,
                    callback       = function()
                        -- Cycle to next option.
                        for i, opt in ipairs(options) do
                            if opt == val then
                                p[pref_key] = options[(i % #options) + 1]
                                self:_savePref(pref_key, p[pref_key])
                                break
                            end
                        end
                        self:_rebuild()
                    end,
                },
            },
        }
    end

    -- ── Account rows ──────────────────────────────────────────────────────────
    local export_row = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        Button:new{
            text           = "Export my data  →",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 0,
            padding        = 0,
            callback       = function() self:_exportData() end,
        },
    }

    local leave_row = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        Button:new{
            text           = "Leave Tomo  →",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 0,
            padding        = 0,
            callback       = function() self:_leaveTomo() end,
        },
    }

    -- ── Assemble ──────────────────────────────────────────────────────────────
    local content = VerticalGroup:new{
        align = "left",
        back_row,
        privacy_widget,
        div(),
        section_head("Notifications"),
        toggle_row("While reading",    "notif_while_reading"),
        toggle_row("Pen pal letters",  "notif_penpal"),
        div(),
        section_head("Reading"),
        toggle_row("Share current book", "share_current_book"),
        div(),
        section_head("Display"),
        choice_row("Font size",        "font_size",        { "small", "med", "large" }),
        choice_row("Message spacing",  "message_spacing",  { "open", "close" }),
        div(),
        section_head("Account"),
        VerticalSpan:new{ width = Theme.space.xs },
        export_row,
        leave_row,
        div(),
        section_head("About"),
        VerticalSpan:new{ width = Theme.space.xs },
        FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            TextWidget:new{
                text = "Tomo v2.7.0",
                face = Theme.face(Theme.font.size.body),
                max_width = w,
            },
        },
        FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            TextWidget:new{
                text = "\u{53CB} (tomo) means 'friend' in Japanese.",
                face = Theme.face(Theme.font.size.small),
                max_width = w,
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
            },
        },
        VerticalSpan:new{ width = Theme.space.sm },
        FrameContainer:new{
            bordersize = 0,
            padding_left = Theme.space.md,
            TextWidget:new{
                text = "\u{00A9} 2026 James Edward Honiball",
                face = Theme.face(Theme.font.size.small),
                max_width = w,
                fgcolor = Theme.blitColor(Theme.color.text_secondary),
            },
        },
        VerticalSpan:new{ width = Theme.space.xl },
    }

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        ScrollableContainer:new{
            dimen = self.dimen,
            FrameContainer:new{
                width      = dw,
                bordersize = 0,
                padding    = 0,
                content,
            },
        },
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Preferences persistence
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenSettings:_savePref(key, value)
    self.tomo._cache:setState("pref_" .. key, tostring(value))
end

-- Return the current preferences (read by tomo.lua and screen_bridge).
function ScreenSettings.loadPrefs(cache)
    local prefs = {}
    for key, default in pairs(DEFAULT_PREFS) do
        local stored = cache:getState("pref_" .. key)
        if stored == "true" then
            prefs[key] = true
        elseif stored == "false" then
            prefs[key] = false
        elseif stored ~= nil then
            prefs[key] = stored
        else
            prefs[key] = default
        end
    end
    return prefs
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Account actions
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenSettings:_exportData()
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id then return end

    self.tomo._api:exportData(user_id, function(err, data)
        if err then return end
        -- Write JSON to a file in the data directory.
        local ok_ds, DataStorage = pcall(require, "datastorage")
        if not ok_ds then return end
        local path = DataStorage:getDataDir() .. "/tomo_export.json"
        local ok_json, json = pcall(require, "rapidjson")
        if not ok_json then return end
        local f = io.open(path, "w")
        if f then
            f:write(json.encode(data))
            f:close()
        end
        -- Confirm to the user.
        local InfoMessage = require("ui/widget/infomessage")
        UIManager:show(InfoMessage:new{
            text    = "Data exported to tomo_export.json in KOReader settings folder.",
            timeout = 4,
        })
    end)
end

function ScreenSettings:_leaveTomo()
    local ConfirmBox = require("ui/widget/confirmbox")
    UIManager:show(ConfirmBox:new{
        text = "Leave Tomo™?\n\nYour messages, shelf, and pen pal bond will be deleted from the server. This cannot be undone.",
        ok_text      = "Leave",
        cancel_text  = "Stay",
        ok_callback  = function()
            self:_performLeave()
        end,
    })
end

function ScreenSettings:_performLeave()
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id then return end

    self.tomo._api:deleteAccount(user_id, function(err, _)
        -- Clear local cache regardless of server response.
        local Auth = require("core/auth")
        Auth.clearToken(self.tomo._cache)
        self.tomo.state.user = nil
        self.tomo.state.rooms = {}
        -- Close all Tomo screens by closing this one (the stack unwinds).
        UIManager:close(self)
    end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenSettings:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenSettings]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenSettings:onShow()
    UIManager:setDirty(self, "full")
    return true
end

function ScreenSettings:onSwipe(_, ges)
    local direction = ges.direction
    if direction == "east" then
        self:onClose()
        return true
    elseif direction == "south" then
        self:onClose()
        return true
    end
end

function ScreenSettings:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    return true
end

function ScreenSettings:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

return ScreenSettings
