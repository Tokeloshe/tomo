-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_notice.lua
-- One-time version notice shown after an update.
-- Uses custom Tomo widget style (thin border, white bg, not InfoMessage).

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local TextWidget      = require("ui/widget/textwidget")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")

local Theme = require("ui/theme")

local ScreenNotice = InputContainer:extend{
    name = "tomo_notice",
    dimen = nil,
    title = "",
    body = "",
    on_dismiss = nil,
}

function ScreenNotice:init()
    self.dimen = Screen:getSize()
    local dw = self.dimen.w
    local dh = self.dimen.h
    local card_w = math.floor(dw * 0.8)
    local inner_w = card_w - 70

    local content = VerticalGroup:new{ align = "center" }
    content[#content + 1] = VerticalSpan:new{ width = 15 }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = inner_w, h = 30 },
        TextWidget:new{
            text = self.title or "",
            face = Theme.face(Theme.font.size.title),
            bold = true,
        },
    }
    content[#content + 1] = VerticalSpan:new{ width = 20 }
    content[#content + 1] = TextBoxWidget:new{
        text = self.body or "",
        face = Theme.face(Theme.font.size.body),
        width = inner_w,
        alignment = "left",
        fgcolor = Theme.blitColor(Theme.color.text_secondary),
    }
    content[#content + 1] = VerticalSpan:new{ width = 25 }
    content[#content + 1] = CenterContainer:new{
        dimen = Geom:new{ w = inner_w, h = 50 },
        Button:new{
            text = "Continue",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize = 1,
            padding = Theme.space.md,
            callback = function()
                UIManager:close(self)
                UIManager:setDirty(nil, "ui")
                if self.on_dismiss then self.on_dismiss() end
            end,
        },
    }

    local card = FrameContainer:new{
        width = card_w,
        bordersize = 1,
        padding = 35,
        background = Blitbuffer.COLOR_WHITE,
        content,
    }

    self[1] = FrameContainer:new{
        width = dw, height = dh, bordersize = 0, padding = 0,
        background = Blitbuffer.Color8(0xCC),
        CenterContainer:new{
            dimen = Geom:new{ w = dw, h = dh },
            card,
        },
    }

    self.ges_events = {}
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end
end

function ScreenNotice:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "ui")
    if self.on_dismiss then self.on_dismiss() end
    return true
end

function ScreenNotice:onResume()
    if not self[1] then self:init() end
end

function ScreenNotice:onShow()
    UIManager:setDirty(self, "flashui")
    return true
end

return ScreenNotice
