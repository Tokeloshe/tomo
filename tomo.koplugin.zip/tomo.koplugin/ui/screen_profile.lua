-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_profile.lua
-- v2.0 -- Profile as a CENTERED DIALOG OVERLAY, not a full screen.
--
-- Appears as a card centered on screen with semi-opaque background.
-- Tap outside the card to dismiss. Contains:
--   - Username (large, bold)
--   - Haiku bio (or placeholder)
--   - Reading shelf: top 5 books
--   - [edit] opens InputDialog sequence
--   - [settings] opens Settings screen
--   - Close button or tap outside
--
-- Two modes:
--   OWN profile: shows edit + settings
--   OTHER user: read-only, no edit/settings

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local TextWidget      = require("ui/widget/textwidget")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")

local ScreenProfile = InputContainer:extend{
    name          = "tomo_profile",
    dimen         = nil,
    tomo          = nil,
    view_user_id  = nil,    -- Set to view another user's profile (read-only)
    _shelf        = {},
    _shelf_source = nil,
    _view_user    = nil,
    _card_dimen   = nil,    -- Geom of the dialog card (for tap-outside detection)
}

function ScreenProfile:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    -- Dialog card width: 80% of screen
    self._card_w = math.floor(self.dimen.w * 0.8)
    self._inner_w = self._card_w - Theme.space.lg * 2

    self.ges_events = {
        Tap = { GestureRange:new{ ges = "tap", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Build
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenProfile:_build()
    local dw = self.dimen.w
    local dh = self.dimen.h

    local is_readonly = self.view_user_id ~= nil
    local user
    if is_readonly then
        user = self._view_user or {}
    else
        user = self.tomo.state.user or {}
    end

    local w = self._inner_w

    -- ── Card content ────────────────────────────────────────────────────────
    local card_content = VerticalGroup:new{ align = "left" }

    -- Username (large, bold)
    card_content[#card_content + 1] = TextWidget:new{
        text      = user.username or "reader",
        face      = Theme.face(Theme.font.size.title),
        bold      = true,
        max_width = w,
    }
    card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.md }

    -- Haiku bio -- guard against rapidjson.null (userdata) from Supabase responses
    local haiku_text = user.haiku_bio
    if type(haiku_text) ~= "string" or haiku_text == "" then
        haiku_text = ""
    end
    if haiku_text == "" then
        card_content[#card_content + 1] = TextBoxWidget:new{
            text      = "Write a haiku about yourself...",
            face      = Theme.face(Theme.font.size.body),
            width     = w,
            alignment = "left",
            fgcolor   = Theme.blitColor(Theme.color.text_whisper),
        }
    else
        card_content[#card_content + 1] = TextBoxWidget:new{
            text      = haiku_text,
            face      = Theme.face(Theme.font.size.body),
            width     = w,
            alignment = "left",
            fgcolor   = Theme.blitColor(Theme.color.text_secondary),
        }
    end

    -- Divider
    card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.md }
    card_content[#card_content + 1] = Components.divider(w, self._device)

    -- Reading shelf (top 5 books)
    card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.md }
    card_content[#card_content + 1] = Components.sectionHeader("Reading shelf", w)

    if #self._shelf == 0 then
        card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.xs }
        card_content[#card_content + 1] = TextWidget:new{
            text      = "Your shelf is empty.",
            face      = Theme.face(Theme.font.size.body),
            max_width = w,
            fgcolor   = Theme.blitColor(Theme.color.text_whisper),
        }
    else
        for i, book in ipairs(self._shelf) do
            if i > 5 then break end
            card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.xs }
            card_content[#card_content + 1] = TextWidget:new{
                text      = tostring(i) .. "  " .. (book.title or ""),
                face      = Theme.face(Theme.font.size.small),
                max_width = w,
            }
        end
    end

    -- Action buttons (own profile only)
    if not is_readonly then
        card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.lg }
        card_content[#card_content + 1] = Components.divider(w, self._device)
        card_content[#card_content + 1] = VerticalSpan:new{ width = Theme.space.md }

        local edit_btn = Button:new{
            text           = "[edit]",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 0,
            padding        = 0,
            callback       = function() self:_openEditDialog() end,
        }
        local settings_btn = Button:new{
            text           = "[settings]",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 0,
            padding        = 0,
            callback       = function() self:_openSettings() end,
        }
        local edit_w = edit_btn:getSize().w
        local settings_w = settings_btn:getSize().w
        local btn_gap = math.max(Theme.space.md, w - edit_w - settings_w)

        card_content[#card_content + 1] = HorizontalGroup:new{
            align = "center",
            edit_btn,
            HorizontalSpan:new{ width = btn_gap },
            settings_btn,
        }
    end

    -- ── Build the card (scrollable if content overflows 70% of screen) ─────
    local ScrollableContainer = require("ui/widget/container/scrollablecontainer")
    local max_card_h = math.floor(dh * 0.7)
    local card_inner = FrameContainer:new{
        width      = self._card_w,
        bordersize = 0,
        padding    = Theme.space.lg,
        background = Blitbuffer.COLOR_WHITE,
        card_content,
    }
    local inner_h = card_inner:getSize().h
    local card_body
    if inner_h > max_card_h then
        card_body = ScrollableContainer:new{
            dimen = Geom:new{ w = self._card_w, h = max_card_h },
            show_parent = self,
            card_inner,
        }
    else
        card_body = card_inner
    end
    local card = FrameContainer:new{
        width      = self._card_w,
        bordersize = 1,
        padding    = 0,
        background = Blitbuffer.COLOR_WHITE,
        card_body,
    }

    -- ── Semi-opaque background + centered card ──────────────────────────────
    local centered_card = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = dh },
        card,
    }

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = Blitbuffer.Color8(0xCC),  -- Semi-opaque grey overlay
        centered_card,
    }

    -- Store card dimensions for tap-outside detection.
    -- The card is centered, so compute its position.
    local card_h = card:getSize().h
    self._card_dimen = Geom:new{
        x = math.floor((dw - self._card_w) / 2),
        y = math.floor((dh - card_h) / 2),
        w = self._card_w,
        h = card_h,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Tap handler: tap outside card to dismiss
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenProfile:onTap(_, ges)
    if self._card_dimen and ges.pos:notIntersectWith(self._card_dimen) then
        self:onClose()
        return true
    end
    -- Let button children handle taps inside the card
    return false
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Edit dialog (username → haiku, sequential InputDialogs)
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenProfile:_openEditDialog()
    local InputDialog = require("ui/widget/inputdialog")
    local logger = require("logger")
    local Recorder = require("core/recorder")
    local user = self.tomo.state.user or {}
    Recorder.log("TAP", "[edit]")

    local ok, err = pcall(function()
        local dlg
        dlg = InputDialog:new{
            title = "Username",
            input = user.username or "",
            input_hint = "A nature word, like rain-fern",
            buttons = {{
                {
                    text = "Cancel",
                    id = "close",
                    callback = function()
                        UIManager:close(dlg)
                    end,
                },
                {
                    text = "Next",
                    is_enter_default = true,
                    callback = function()
                        local new_username = dlg:getInputText()
                        UIManager:close(dlg)
                        self:_openHaikuDialog(new_username)
                    end,
                },
            }},
        }
        UIManager:show(dlg)
        dlg:onShowKeyboard()
    end)
    if not ok then
        logger.warn("Tomo: edit dialog failed: " .. tostring(err))
    end
end

function ScreenProfile:_openHaikuDialog(new_username)
    local InputDialog = require("ui/widget/inputdialog")
    local user = self.tomo.state.user or {}

    -- Guard against rapidjson.null (userdata) -- InputDialog crashes on non-string input
    local current_haiku = user.haiku_bio
    if type(current_haiku) ~= "string" then current_haiku = "" end

    local dlg
    dlg = InputDialog:new{
        title = "Haiku bio",
        input = current_haiku,
        input_hint = "Three lines, like a haiku...",
        buttons = {{
            {
                text = "Cancel",
                id = "close",
                callback = function()
                    UIManager:close(dlg)
                end,
            },
            {
                text = "Save",
                is_enter_default = true,
                callback = function()
                    local new_haiku = dlg:getInputText()
                    UIManager:close(dlg)

                    local user_id = self.tomo.state.user and self.tomo.state.user.id
                    if not user_id then return end

                    local updates = {}
                    if new_username and new_username ~= "" then
                        updates.username = new_username
                        self.tomo.state.user.username = new_username
                        self.tomo._cache:setState("auth_username", new_username)
                        self.tomo._cache:updateCachedUsername(user_id, new_username)
                        -- Mirror to LuaSettings (survives OTA wipes)
                        pcall(function()
                            local LS = require("luasettings")
                            local DS = require("datastorage")
                            local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                            ts:saveSetting("username", new_username)
                            ts:flush()
                        end)
                    end
                    if new_haiku then
                        updates.haiku_bio = new_haiku
                        self.tomo.state.user.haiku_bio = new_haiku
                        self.tomo._cache:setState("auth_haiku_bio", new_haiku)
                        pcall(function()
                            local LS = require("luasettings")
                            local DS = require("datastorage")
                            local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                            ts:saveSetting("haiku_bio", new_haiku)
                            ts:flush()
                        end)
                    end

                    self:_rebuild()

                    if next(updates) then
                        if self.tomo.state.online then
                            UIManager:scheduleIn(0.1, function()
                                local ok, err_s = pcall(function()
                                    if not self or not self.tomo then return end
                                    self.tomo._api:updateUser(user_id, updates, function(err)
                                        if err then
                                            -- API failed: queue the update for retry on next sync.
                                            -- The cached values are already set, so the UI shows
                                            -- the new name/haiku immediately. The pending flag
                                            -- tells syncOnWake not to overwrite with server data.
                                            local logger = require("logger")
                                            logger.warn("Tomo: profile update failed, queuing for retry: " .. tostring(err))
                                            self.tomo._cache:setState("pending_profile_update", "1")
                                        else
                                            -- Success: clear any pending flag
                                            self.tomo._cache:deleteState("pending_profile_update")
                                        end
                                    end)
                                end)
                                if not ok then
                                    local logger = require("logger")
                                    logger.warn("Tomo: scheduled callback error: " .. tostring(err_s))
                                end
                            end)
                        else
                            -- Offline: queue for retry on next sync
                            self.tomo._cache:setState("pending_profile_update", "1")
                        end
                    end
                end,
            },
        }},
    }
    UIManager:show(dlg)
    dlg:onShowKeyboard()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Settings navigation
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenProfile:_openSettings()
    local Recorder = require("core/recorder")
    Recorder.log("TAP", "[settings]")
    -- Close the profile dialog first, then open settings full-screen
    UIManager:close(self)
    local ScreenSettings = require("ui/screen_settings")
    UIManager:show(ScreenSettings:new{ tomo = self.tomo })
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Shelf loading
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenProfile:_loadShelf()
    local target_id = self.view_user_id
        or (self.tomo.state.user and self.tomo.state.user.id)
    if not target_id then return end

    if self.tomo.state.online then
        self.tomo._api:getShelf(target_id, function(err, shelf)
            if not err and shelf and #shelf > 0 then
                self._shelf = shelf
                self._shelf_source = "server"
            elseif not self.view_user_id then
                -- API failed or returned empty -- fall back to local Kobo library
                self:_populateFromLocal()
            end
            self:_rebuild()
        end)
    else
        if not self.view_user_id then
            self:_populateFromLocal()
        end
        self:_rebuild()
    end
end

function ScreenProfile:_populateFromLocal()
    local ok, Library = pcall(require, "core/library")
    if not ok then return end

    local candidates = Library.getShelfCandidates(5)
    if candidates and #candidates > 0 then
        local shelf = {}
        for _, book in ipairs(candidates) do
            shelf[#shelf + 1] = {
                title  = book.title,
                author = book.author,
            }
        end
        self._shelf = shelf
        self._shelf_source = "local"
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenProfile:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenProfile]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenProfile:onShow()
    if self.view_user_id and self.tomo.state.online then
        self.tomo._api:getUserProfile(self.view_user_id, function(err, profile)
            if not err and profile then
                self._view_user = profile
                self:_rebuild()
            end
        end)
    end

    self:_loadShelf()
    UIManager:setDirty(self, "flashui")
    return true
end

function ScreenProfile:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "ui")
    return true
end

function ScreenProfile:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

return ScreenProfile
