-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_conservatory.lua
-- The Conservatory (温室) -- personal book room discovery.
-- Shows only book rooms matching the user's currently-read books.
-- If nothing is in bloom, a quiet empty state with a seed emoji.

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local TextWidget      = require("ui/widget/textwidget")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")

local Theme      = require("ui/theme")
local Components = require("ui/components")

local ScreenConservatory = InputContainer:extend{
    name        = "tomo_conservatory",
    dimen       = nil,
    tomo        = nil,
    _book_rooms = {},
}

function ScreenConservatory:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._width  = self.dimen.w - Theme.space.md * 2

    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

function ScreenConservatory:_build()
    local bg = Theme.pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE
    local w  = self._width
    local dw = self.dimen.w
    local dh = self.dimen.h

    local back_row = Components.backRow("Conservatory", function()
        UIManager:close(self)
        UIManager:setDirty(nil, "full")
    end, dw)

    local content = VerticalGroup:new{ align = "left" }
    content[#content + 1] = back_row
    content[#content + 1] = FrameContainer:new{
        bordersize = 0, padding_left = Theme.space.md, padding_right = Theme.space.md,
        Components.divider(w, self._device),
    }

    if #self._book_rooms == 0 then
        -- Empty state -- centered poetic message, no emoji
        local msg = self._device.compact
            and "The conservatory is quiet.\n\nKeep reading. The seeds\nare already planted."
            or "The conservatory is quiet.\n\nWhen two or more readers open\nthe same book, a room blooms\nhere naturally. No one creates\nit. It simply appears.\n\nKeep reading. The seeds\nare already planted."
        content[#content + 1] = VerticalSpan:new{ width = math.floor(dh * 0.2) }
        content[#content + 1] = CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 250 },
            TextBoxWidget:new{
                text      = msg,
                face      = Theme.face(Theme.font.size.body),
                width     = math.floor(w * 0.75),
                alignment = "center",
                fgcolor   = Theme.blitColor(Theme.color.text_whisper),
            },
        }
    else
        content[#content + 1] = VerticalSpan:new{ width = Theme.space.md }
        for _, room in ipairs(self._book_rooms) do
            content[#content + 1] = FrameContainer:new{
                bordersize = 0,
                padding_left = Theme.space.md,
                Components.roomRow{
                    name           = room.name or "Book room",
                    slug           = room.slug,
                    has_new        = room.has_new or false,
                    is_joined      = true,
                    width          = w,
                    device_profile = self._device,
                    on_tap         = function()
                        self:_openRoom(room)
                    end,
                },
            }
        end
    end

    self[1] = FrameContainer:new{
        width = dw, height = dh, bordersize = 0, padding = 0,
        background = bg, content,
    }
end

function ScreenConservatory:_openRoom(room)
    UIManager:close(self)
    local ScreenRoom = require("ui/screen_room")
    UIManager:show(ScreenRoom:new{
        tomo      = self.tomo,
        room_id   = room.id,
        genre_tag = room.genre_tag,
        _room     = room,
    })
end

function ScreenConservatory:_loadRooms()
    -- Get the user's current books from tomo state
    local my_hashes = {}
    if self.tomo.state.current_book and self.tomo.state.current_book.book_hash then
        my_hashes["book-" .. self.tomo.state.current_book.book_hash] = true
    end

    -- Filter active book rooms to only those matching user's books
    self._book_rooms = {}
    for _, r in ipairs(self.tomo.state.rooms) do
        if r.kind == "book" and r.slug and my_hashes[r.slug] then
            self._book_rooms[#self._book_rooms + 1] = r
        end
    end

    -- Also include any book room the user is a member of
    for _, r in ipairs(self.tomo.state.rooms) do
        if r.kind == "book" then
            local found = false
            for _, br in ipairs(self._book_rooms) do
                if br.id == r.id then found = true; break end
            end
            if not found then
                self._book_rooms[#self._book_rooms + 1] = r
            end
        end
    end

    self:_rebuild()
end

function ScreenConservatory:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenConservatory]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenConservatory:onShow()
    self:_loadRooms()
    UIManager:setDirty(self, "full")
    return true
end

function ScreenConservatory:onSwipe(_, ges)
    if ges.direction == "east" then
        UIManager:close(self); UIManager:setDirty(nil, "full"); return true
    end
end

function ScreenConservatory:onClose()
    UIManager:close(self); UIManager:setDirty(nil, "full"); return true
end

function ScreenConservatory:_rebuild()
    self:_build(); UIManager:setDirty(self, "ui")
end

return ScreenConservatory
