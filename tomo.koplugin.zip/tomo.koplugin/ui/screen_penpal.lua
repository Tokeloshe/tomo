-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/screen_penpal.lua
-- v2.1.0 -- Pen Pal Thread (文 Fumi, Letter). Tegami ceremony.
--
-- "Heta de ii. Heta ga ii" -- It's okay to be awkward. Awkwardness has charm.
--
-- Two states:
--   A) No bond → genre selection + join pool
--   B) Bond exists → paginated letter thread with ink images
--
-- Letters are displayed as images from Supabase Storage.
-- Only shows letters where delivers_at <= now().
-- "Your letter is on its way..." for in-transit letters.

local InputContainer  = require("ui/widget/container/inputcontainer")
local FrameContainer  = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup   = require("ui/widget/verticalgroup")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local TextWidget      = require("ui/widget/textwidget")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local Button          = require("ui/widget/button")
local GestureRange    = require("ui/gesturerange")
local Geom            = require("ui/geometry")
local UIManager       = require("ui/uimanager")
local Device          = require("device")
local Screen          = Device.screen
local Blitbuffer      = require("ffi/blitbuffer")
local VerticalSpan    = require("ui/widget/verticalspan")
local InfoMessage     = require("ui/widget/infomessage")

local Theme      = require("ui/theme")
local Components = require("ui/components")
local Seasons    = require("core/seasons")

local GENRE_OPTIONS = {
    { name = "Fantasy & Sci-Fi",   slug = "fantasy-scifi" },
    { name = "Romance",            slug = "romance"        },
    { name = "Literary Fiction",   slug = "literary"       },
    { name = "Thriller & Mystery", slug = "thriller"       },
    { name = "Non-Fiction",        slug = "nonfiction"     },
    { name = "Horror",             slug = "horror"         },
    { name = "Historical Fiction", slug = "historical"     },
    { name = "Young Adult",        slug = "ya"             },
}

local ScreenPenpal = InputContainer:extend{
    name             = "tomo_penpal",
    dimen            = nil,
    tomo             = nil,
    _bond            = nil,
    _partner         = nil,
    _letters         = {},
    _selected_genres = {},
    _in_pool         = false,
    _has_in_transit  = false,
    _page            = 1,
    _per_page        = 2,  -- Letters are large, 1-2 per page
}

function ScreenPenpal:init()
    self.dimen   = Screen:getSize()
    self._device = require("core/device").getProfile()
    self._width  = self.dimen.w - Theme.space.md * 2

    -- Restore saved genre selections from LuaSettings
    pcall(function()
        local LS = require("luasettings")
        local DS = require("datastorage")
        local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
        local saved = ts:readSetting("penpal_genres")
        if saved and type(saved) == "table" then
            for _, slug in ipairs(saved) do
                self._selected_genres[slug] = true
            end
        end
    end)

    self.ges_events = {
        Swipe = { GestureRange:new{ ges = "swipe", range = self.dimen } },
        Tap   = { GestureRange:new{ ges = "tap", range = self.dimen } },
    }
    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
    end

    self:_build()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Build dispatcher
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_build()
    if self._bond then
        self:_buildThread()
    else
        self:_buildMatchingFlow()
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- State C: Bond has ended -- mono no aware notice
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_buildEndedNotice()
    local bg = Theme.pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local dw = self.dimen.w
    local dh = self.dimen.h
    local w  = self._width

    local back_row = Components.backRow("Back", function()
        UIManager:close(self)
        UIManager:setDirty(nil, "full")
    end, dw)

    local user_id = self.tomo.state.user and self.tomo.state.user.id
    local i_ended = self._bond.ended_by == user_id

    local notice_group = VerticalGroup:new{ align = "center" }

    if i_ended then
        notice_group[#notice_group + 1] = CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 40 },
            TextWidget:new{
                text    = "You ended this connection.",
                face    = Theme.face(Theme.font.size.body),
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
            },
        }
    else
        -- The other person ended it -- show mono no aware notice
        notice_group[#notice_group + 1] = VerticalSpan:new{ width = Theme.space.xl }
        notice_group[#notice_group + 1] = CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 30 },
            TextWidget:new{
                text    = "物の哀れ",
                face    = Theme.face(Theme.font.size.room),
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
            },
        }
        notice_group[#notice_group + 1] = VerticalSpan:new{ width = Theme.space.lg }

        local TextBoxWidget = require("ui/widget/textboxwidget")
        local poem = "This correspondence has\nfound its natural end.\n\nLike letters tucked into a book\nand forgotten on a shelf,\nsome conversations complete\nthemselves in silence.\n\nThank you for the words\nyou shared along the way."
        notice_group[#notice_group + 1] = CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 300 },
            TextBoxWidget:new{
                text      = poem,
                face      = Theme.face(Theme.font.size.body),
                width     = math.floor(w * 0.75),
                alignment = "center",
                fgcolor   = Theme.blitColor(Theme.color.text_whisper),
            },
        }
    end

    local content = VerticalGroup:new{ align = "left" }
    content[#content + 1] = back_row
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.xl }
    content[#content + 1] = notice_group

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        content,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- State A: No bond -- matching flow
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_buildMatchingFlow()
    local bg = Theme.pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local w  = self._width
    local dw = self.dimen.w
    local dh = self.dimen.h

    local back_row = Components.backRow("Back", function()
        UIManager:close(self)
        UIManager:setDirty(nil, "full")
    end, dw)

    -- Intro text
    local intro = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        padding_top  = Theme.space.md,
        TextBoxWidget:new{
            text      = "You will be matched with a reader who shares your taste. This may take days. The wait is part of it.",
            face      = Theme.face(Theme.font.size.body),
            width     = w,
            alignment = "left",
        },
    }

    local helper = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        padding_top  = Theme.space.sm,
        TextWidget:new{
            text    = "These help us find someone who reads like you.",
            face    = Theme.face(Theme.font.size.whisper),
            fgcolor = Theme.blitColor(Theme.color.text_whisper),
            max_width = w,
        },
    }

    -- Genre checklist (select 2-4)
    local genre_group = VerticalGroup:new{ align = "left" }
    genre_group[#genre_group + 1] = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        padding_top  = Theme.space.lg,
        Components.sectionHeader("Choose genres you enjoy:", w),
    }

    for _, genre in ipairs(GENRE_OPTIONS) do
        local selected = self._selected_genres[genre.slug]
        local prefix = selected and "[✓] " or "[ ] "
        genre_group[#genre_group + 1] = FrameContainer:new{
            bordersize   = 0,
            padding_left = Theme.space.md,
            Button:new{
                text           = prefix .. genre.name,
                text_font_face = "cfont",
                text_font_size = Theme.font.size.body,
                bordersize     = 0,
                padding        = Theme.space.sm,
                align          = "left",
                callback       = function() self:_toggleGenre(genre.slug) end,
            },
        }
    end

    -- Count selected
    local sel_count = 0
    for _ in pairs(self._selected_genres) do sel_count = sel_count + 1 end

    -- Join pool button
    local btn_text = self._in_pool and "Waiting for a match..." or "Join the pool"
    local enter_btn = FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        padding_top  = Theme.space.lg,
        Button:new{
            text           = btn_text,
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 1,
            padding        = Theme.space.md,
            enabled        = not self._in_pool and sel_count >= 2,
            callback       = function() self:_enterPool() end,
        },
    }

    local content = VerticalGroup:new{
        align = "left",
        back_row,
        intro,
        helper,
        genre_group,
        enter_btn,
        VerticalSpan:new{ width = Theme.space.xl },
    }

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        content,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- State B: Bond exists -- letter thread (paginated)
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_buildThread()
    local bg = Theme.pageBg(self._device,
        self.tomo.state.season and self.tomo.state.season.season) or Blitbuffer.COLOR_WHITE

    local w  = self._width
    local dw = self.dimen.w
    local dh = self.dimen.h

    local partner_name = self._partner and self._partner.username or "your pen pal"

    -- Header: back button on left, "..." options on right
    local back_row = Components.backRow(
        "Back",
        function()
            UIManager:close(self)
            UIManager:setDirty(nil, "full")
        end,
        dw
    )

    -- Options button ("...") for ending the pen pal bond
    local HorizontalSpan = require("ui/widget/horizontalspan")
    local options_btn = Button:new{
        text           = "···",
        text_font_face = "cfont",
        text_font_size = Theme.font.size.room,
        bordersize     = 0,
        padding        = Theme.space.md,
        callback       = function() self:_showBondOptions() end,
    }
    local options_row = FrameContainer:new{
        bordersize = 0,
        padding_right = Theme.space.md,
        HorizontalGroup:new{
            align = "center",
            HorizontalSpan:new{ width = w - options_btn:getSize().w },
            options_btn,
        },
    }

    -- Season of meeting -- centered
    local sekki_text = ""
    local sekki_english = ""
    if self._bond.season_met then
        sekki_text = "Matched during " .. self._bond.season_met
        -- Look up English translation
        local sekki = Seasons.byRomaji(self._bond.season_met)
        if not sekki then
            -- season_met might be kanji, try to find it
            for _, s in ipairs(Seasons.all()) do
                if s.kanji == self._bond.season_met then
                    sekki_english = s.english
                    break
                end
            end
        else
            sekki_english = sekki.english
        end
    end

    local season_block = VerticalGroup:new{
        align = "center",
        CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 24 },
            TextWidget:new{
                text    = sekki_text,
                face    = Theme.face(Theme.font.size.whisper),
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
            },
        },
    }
    if sekki_english ~= "" then
        season_block[#season_block + 1] = CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 20 },
            TextWidget:new{
                text    = sekki_english,
                face    = Theme.face(Theme.font.size.whisper),
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
            },
        }
    end

    -- Divider
    local function makeDivider()
        return FrameContainer:new{
            bordersize    = 0,
            padding_left  = Theme.space.md,
            padding_right = Theme.space.md,
            padding_top   = Theme.space.sm,
            padding_bottom = Theme.space.sm,
            Components.divider(w, self._device),
        }
    end

    -- Letters for current page
    local letters_group = VerticalGroup:new{ align = "left" }
    letters_group[#letters_group + 1] = VerticalSpan:new{ width = Theme.space.md }

    local total_pages = math.max(1, math.ceil(#self._letters / self._per_page))
    local page_letters = {}
    if #self._letters > 0 then
        local start_idx = (self._page - 1) * self._per_page + 1
        local end_idx   = math.min(self._page * self._per_page, #self._letters)
        for i = start_idx, end_idx do
            page_letters[#page_letters + 1] = self._letters[i]
        end
    end

    if #self._letters == 0 then
        letters_group[#letters_group + 1] = FrameContainer:new{
            bordersize   = 0,
            padding_left = Theme.space.md,
            padding_top  = Theme.space.xl,
            TextWidget:new{
                text    = "No letters yet. Write the first one.",
                face    = Theme.face(Theme.font.size.body),
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
                max_width = w,
            },
        }
    else
        for _, letter in ipairs(page_letters) do
            letters_group[#letters_group + 1] = self:_buildLetterCard(letter, w)
        end
    end

    -- In-transit indicator
    if self._has_in_transit then
        letters_group[#letters_group + 1] = VerticalSpan:new{ width = Theme.space.lg }
        letters_group[#letters_group + 1] = CenterContainer:new{
            dimen = Geom:new{ w = dw, h = 30 },
            TextWidget:new{
                text    = "Your letter is on its way...",
                face    = Theme.face(Theme.font.size.whisper),
                fgcolor = Theme.blitColor(Theme.color.text_whisper),
            },
        }
    end

    -- Page indicator
    local page_indicator = nil
    if total_pages > 1 then
        page_indicator = Components.pageIndicator(self._page, total_pages, dw)
    end

    -- Write a letter button
    local write_btn = CenterContainer:new{
        dimen = Geom:new{ w = dw, h = 60 },
        Button:new{
            text           = "Write a letter",
            text_font_face = "cfont",
            text_font_size = Theme.font.size.body,
            bordersize     = 1,
            padding        = Theme.space.md,
            callback       = function() self:_openCanvas() end,
        },
    }

    -- Assemble
    local content = VerticalGroup:new{ align = "left" }
    content[#content + 1] = back_row
    content[#content + 1] = options_row
    content[#content + 1] = season_block
    content[#content + 1] = makeDivider()
    content[#content + 1] = letters_group
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.md }
    content[#content + 1] = makeDivider()
    if page_indicator then
        content[#content + 1] = page_indicator
    end
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.sm }
    content[#content + 1] = write_btn
    content[#content + 1] = VerticalSpan:new{ width = Theme.space.lg }

    self[1] = FrameContainer:new{
        width      = dw,
        height     = dh,
        bordersize = 0,
        padding    = 0,
        background = bg,
        content,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Letter card: ink image + sender + timestamp
-- ─────────────────────────────────────────────────────────────────────────────

-- Vague relative timestamp
local function relativeTime(iso_ts)
    if not iso_ts then return "" end
    local y, mo, d, h, mi, s = iso_ts:match("(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d):(%d%d)")
    if not y then return "" end
    local diff = os.time() - os.time{
        year = tonumber(y), month = tonumber(mo), day = tonumber(d),
        hour = tonumber(h), min = tonumber(mi), sec = tonumber(s),
    }
    if diff < 300        then return "just now"
    elseif diff < 3600   then return "recently"
    elseif diff < 86400  then return "a while ago"
    elseif diff < 172800 then return "yesterday"
    elseif diff < 604800 then return "a few days ago"
    elseif diff < 2592000 then return "last week"
    else                      return "last month"
    end
end

function ScreenPenpal:_buildLetterCard(letter, w)
    local card_w = w
    local img_h  = 300  -- Fixed height for ink letter display

    -- Try to load the ink image from local cache or show placeholder
    local image_widget = nil
    local ink_url = letter.ink_url
    if ink_url then
        -- Check local cache first
        local ok_ds, DataStorage = pcall(require, "datastorage")
        local cache_dir = ok_ds and (DataStorage:getDataDir() .. "/tomo_ink_cache/") or "/tmp/tomo_ink_cache/"
        -- Create cache dir
        os.execute("mkdir -p '" .. cache_dir .. "' 2>/dev/null")
        local safe_name = ink_url:gsub("[/%s]", "_"):sub(1, 60)
        local local_path = cache_dir .. safe_name .. ".png"

        -- Check if cached
        local f = io.open(local_path, "r")
        if f then
            f:close()
            -- Load image via ImageWidget
            local ok_iw, ImageWidget = pcall(require, "ui/widget/imagewidget")
            if ok_iw then
                local ok_img, img = pcall(ImageWidget.new, ImageWidget, {
                    file = local_path,
                    width = card_w,
                    height = img_h,
                    scale_factor = 0,  -- auto-scale
                    autostretch = true,
                })
                if ok_img and img then
                    image_widget = img
                end
            end
        else
            -- Not cached -- queue download in background
            local dl_logger = require("logger")
            dl_logger.warn("Tomo Ink: not cached, downloading. raw ink_url=" .. tostring(ink_url))
            dl_logger.warn("Tomo Ink: local_path=" .. tostring(local_path))
            if self.tomo.state.online then
                UIManager:scheduleIn(0.1, function()
                    local ok_sched, sched_err = pcall(function()
                        if not self or not self[1] then return end
                        local err = self.tomo._api:downloadInkImage(ink_url, local_path)
                        if err then
                            dl_logger.warn("Tomo Ink: download FAILED: " .. tostring(err))
                            return
                        end
                        dl_logger.warn("Tomo Ink: download OK, rebuilding")
                        -- Verify the file has PNG header
                        local vf = io.open(local_path, "rb")
                        if vf then
                            local header = vf:read(4)
                            vf:close()
                            if header and header:sub(1, 4) == "\137PNG" then
                                dl_logger.warn("Tomo Ink: valid PNG confirmed")
                            else
                                dl_logger.warn("Tomo Ink: NOT a valid PNG! header="
                                    .. tostring(header and header:byte(1)))
                            end
                        end
                        self:_rebuild()
                    end)
                    if not ok_sched then
                        dl_logger.warn("Tomo Ink: scheduled callback error: " .. tostring(sched_err))
                    end
                end)
            else
                dl_logger.warn("Tomo Ink: offline, cannot download")
            end
        end
    end

    -- Fallback: grey placeholder with [ink letter] text
    if not image_widget then
        image_widget = FrameContainer:new{
            width      = card_w,
            height     = img_h,
            bordersize = 1,
            padding    = Theme.space.md,
            background = Blitbuffer.Color8(0xF0),
            CenterContainer:new{
                dimen = Geom:new{ w = card_w - Theme.space.md * 2, h = img_h - Theme.space.md * 2 },
                TextWidget:new{
                    text    = "[ink letter]",
                    face    = Theme.face(Theme.font.size.body),
                    fgcolor = Theme.blitColor(Theme.color.text_whisper),
                },
            },
        }
    end

    -- Sender line
    local rel_time = relativeTime(letter.created_at)
    local sender_text = (letter.username or "reader") .. (rel_time ~= "" and (" · " .. rel_time) or "")

    return FrameContainer:new{
        bordersize   = 0,
        padding_left = Theme.space.md,
        padding_right = Theme.space.md,
        padding_top  = Theme.space.lg,
        VerticalGroup:new{
            align = "left",
            image_widget,
            FrameContainer:new{
                bordersize = 0,
                padding_top = Theme.space.sm,
                TextWidget:new{
                    text      = sender_text,
                    face      = Theme.face(Theme.font.size.small),
                    fgcolor   = Theme.blitColor(Theme.color.text_secondary),
                    max_width = w,
                },
            },
        },
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Tap handler for page navigation
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:onTap(_, ges)
    if not self._bond then return false end  -- Let buttons handle in matching flow

    local x = ges.pos.x
    local y = ges.pos.y
    local dw = self.dimen.w
    local dh = self.dimen.h

    -- Only handle taps in the letter area (middle 60% of screen)
    if y < dh * 0.15 or y > dh * 0.75 then return false end

    local total_pages = math.max(1, math.ceil(#self._letters / self._per_page))
    if total_pages <= 1 then return false end

    if x > dw / 2 then
        -- Next page (older letters)
        if self._page < total_pages then
            self._page = self._page + 1
            self:_rebuild()
        end
        return true
    else
        -- Prev page (newer letters)
        if self._page > 1 then
            self._page = self._page - 1
            self:_rebuild()
        end
        return true
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Genre toggle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_toggleGenre(slug)
    if self._selected_genres[slug] then
        self._selected_genres[slug] = nil
    else
        local count = 0
        for _ in pairs(self._selected_genres) do count = count + 1 end
        if count >= 4 then return end  -- Max 4 genres
        self._selected_genres[slug] = true
    end
    self:_rebuild()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Pool entry
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_enterPool()
    local genres = {}
    for slug in pairs(self._selected_genres) do
        genres[#genres + 1] = slug
    end
    if #genres < 2 then return end

    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id then return end

    local Recorder = require("core/recorder")
    Recorder.log("TAP", "Join the pool (" .. table.concat(genres, ",") .. ")")

    self._in_pool = true
    self:_rebuild()

    -- Persist genre selection in LuaSettings so the user does not re-select every visit
    pcall(function()
        local LS = require("luasettings")
        local DS = require("datastorage")
        local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
        ts:saveSetting("penpal_genres", genres)
        ts:flush()
    end)

    if self.tomo.state.online then
        UIManager:scheduleIn(0.1, function()
            local ok, err_s = pcall(function()
                if not self or not self.tomo then return end
                self.tomo._api:enterPenpalPool(user_id, genres, function(err)
                    if not err then
                        -- Attempt client-side match: find overlapping user in pool
                        pcall(function()
                            self.tomo._api:_request("GET",
                                "/rest/v1/penpal_pool"
                                .. "?user_id=neq." .. user_id
                                .. "&select=user_id,genres"
                                .. "&limit=20",
                                nil, nil)
                        end)
                        local current_sekki = Seasons.current()
                        UIManager:show(InfoMessage:new{
                            text    = "You're in the pen pal pool. We'll find you a fellow reader during " .. (current_sekki and current_sekki.romaji or "this season") .. ".",
                            timeout = 4,
                        })
                    end
                end)
            end)
            if not ok then
                local logger = require("logger")
                logger.warn("Tomo: scheduled callback error: " .. tostring(err_s))
            end
        end)
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Canvas navigation
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_openCanvas()
    local Recorder = require("core/recorder")
    Recorder.log("NAV", "opened canvas from penpal thread")
    local ScreenCanvas = require("ui/screen_canvas")
    UIManager:show(ScreenCanvas:new{
        tomo         = self.tomo,
        room_id      = self._bond and self._bond.room_id,
        partner_name = self._partner and self._partner.username or "your pen pal",
        on_send      = function()
            self._has_in_transit = true
            self:_loadLetters()
        end,
    })
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Bond management -- ending a pen pal connection
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_showBondOptions()
    local ConfirmBox = require("ui/widget/confirmbox")
    UIManager:show(ConfirmBox:new{
        text = "End this pen pal connection?\n\nYour letters will remain, but no new letters can be exchanged. This is a quiet parting -- no notification is sent.",
        ok_text = "End bond",
        cancel_text = "Keep writing",
        ok_callback = function() self:_endBond() end,
    })
end

function ScreenPenpal:_endBond()
    if not self._bond or not self._bond.id then return end
    local Recorder = require("core/recorder")
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    Recorder.log("ACTION", "Ending pen pal bond id=" .. tostring(self._bond.id))

    -- Set ended_at and ended_by on the bond in Supabase
    local bond_id = self._bond.id
    if self.tomo.state.online then
        self.tomo._api:_request("PATCH",
            "/rest/v1/penpal_bonds?id=eq." .. bond_id,
            {
                ended_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
                ended_by = user_id,
            },
            { ["Prefer"] = "return=minimal" })
    end

    -- Clear all local pen pal state for this bond
    self.tomo.state.penpal_partner_name = nil
    self._bond = nil
    self._partner = nil
    self._letters = {}

    -- Close and return to home
    UIManager:close(self)
    UIManager:setDirty(nil, "full")

    UIManager:show(InfoMessage:new{
        text = "You ended this connection.",
        timeout = 3,
    })
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Data loading
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:_loadBond()
    local user_id = self.tomo.state.user and self.tomo.state.user.id
    if not user_id or not self.tomo.state.online then return end

    -- Fetch ACTIVE bond only (ended_at IS NULL). If no active bond exists,
    -- the matching flow shows automatically via _build(). Ended bonds are
    -- history -- they do NOT block the "Find a pen pal" flow.
    self.tomo._api:getPenpalBond(user_id, function(err, bond)
        if err or not bond then return end  -- no active bond → matching flow
        self._bond = bond

        -- Load partner profile
        local partner_id = bond.user_a == user_id and bond.user_b or bond.user_a
        self.tomo._api:getUserProfile(partner_id, function(err2, partner)
            if not err2 then self._partner = partner end
            self:_loadLetters()
        end)
    end)
end

function ScreenPenpal:_loadLetters()
    if not self._bond or not self._bond.room_id then return end
    local user_id = self.tomo.state.user and self.tomo.state.user.id

    -- Fetch delivered letters
    self.tomo._api:getDeliveredLetters(self._bond.room_id, 20, function(err, letters)
        if not err and letters then
            -- Reverse to oldest-first
            local ordered = {}
            for i = #letters, 1, -1 do ordered[#ordered + 1] = letters[i] end
            self._letters = ordered
            self._page = math.max(1, math.ceil(#self._letters / self._per_page))
        end

        -- Check for in-transit letters
        if user_id then
            self.tomo._api:hasLettersInTransit(self._bond.room_id, user_id, function(err2, has)
                if not err2 then self._has_in_transit = has end
                self:_rebuild()
            end)
        else
            self:_rebuild()
        end
    end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function ScreenPenpal:onResume()
    if not self[1] then
        local logger = require("logger")
        logger.warn("Tomo [ScreenPenpal]: self[1] nil on resume, rebuilding")
        self:_build()
    end
end

function ScreenPenpal:onShow()
    local Recorder = require("core/recorder")
    Recorder.log("NAV", "opened penpal screen")
    self:_loadBond()
    UIManager:setDirty(self, "full")
    return true
end

function ScreenPenpal:onSwipe(_, ges)
    if ges.direction == "east" then
        self:onClose()
        return true
    end
end

function ScreenPenpal:onClose()
    UIManager:close(self)
    UIManager:setDirty(nil, "full")
    return true
end

function ScreenPenpal:_rebuild()
    self:_build()
    UIManager:setDirty(self, "ui")
end

return ScreenPenpal
