-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- ui/theme.lua
-- The complete design system for Tomo™ v2.0.
-- All spacing, typography, and colour constants live here.
-- No magic numbers anywhere else in the codebase.
--
-- v2.0 changes: compact spacing for single-screen home,
-- reduced font sizes for information density on e-ink.

local Theme = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Typography -- cfont only. Bold via TextWidget bold=true.
-- ─────────────────────────────────────────────────────────────────────────────

Theme.font = {
    -- Size constants. Every text element uses one of these -- never a raw number.
    -- v2.0: reduced from v1.x to fit all content on one screen without scrolling.
    size = {
        whisper = 12,  -- Seasonal greeting, pen pal delivery status, timestamps
        small   = 14,  -- Metadata, secondary labels
        body    = 16,  -- Messages, shelf entries, main content
        room    = 18,  -- Room names, section headers
        title   = 22,  -- Screen titles, username display
    },
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Spacing -- compact for v2.0 single-screen home design.
-- Room rows must be 36px total. Screen padding 8px on sides.
-- ─────────────────────────────────────────────────────────────────────────────

Theme.space = {
    xs  =  2,   -- Icon-to-text gap, micro-padding
    sm  =  4,   -- Between tightly coupled elements, section divider margins
    md  =  8,   -- Screen margins, standard padding, room row internal padding
    lg  = 12,   -- Between messages, between sections
    xl  = 20,   -- Top/bottom breathing room, major section gaps
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Colour -- 和色 (Washoku) palette. Hex strings, converted on demand.
-- ─────────────────────────────────────────────────────────────────────────────

Theme.color = {
    -- Surfaces
    bg_page     = "#F5F0E8",   -- 鳥の子色 (torinoko-iro) -- eggshell
    bg_card     = "#EDE8DE",   -- 亜麻色 (ama-iro) -- flax
    bg_header   = "#F5F0E8",   -- Seamless with page

    -- Text
    text_primary   = "#1A1A18", -- 墨色 (sumi-iro) -- ink
    text_secondary = "#6B6560", -- 鼠色 (nezumi-iro) -- mouse grey
    text_whisper   = "#8A847C", -- 灰色 (hai-iro) -- ash

    -- Genre Accents -- subtle left-border on room names
    genre = {
        ["fantasy-scifi"] = "#6B7FA3", -- 縹色 (hanada-iro) -- dayflower blue
        romance           = "#B5747A", -- 蘇芳色 (suou-iro) -- dried safflower
        literary          = "#7A6B52", -- 丁子色 (chouji-iro) -- clove brown
        thriller          = "#4A4A4A", -- 消炭色 (keshizumi-iro) -- spent charcoal
        nonfiction        = "#5B7A5B", -- 若葉色 (wakaba-iro) -- young leaf
        horror            = "#6B4A5B", -- 滅紫 (meshi-murasaki) -- faded purple
        historical        = "#A08050", -- 朽葉色 (kuchiba-iro) -- fallen leaf
        ya                = "#7A8A6B", -- 柳色 (yanagi-iro) -- willow
    },

    -- Seasonal Tints -- barely-perceptible page background shifts (Libra Colour only)
    season_tint = {
        spring = "#F7F2EA",
        summer = "#F5F0E4",
        autumn = "#F3EDE2",
        winter = "#F0EDE8",
    },

    -- Pen Pal
    penpal_seal = "#C8A96E", -- 金色 (kin-iro) -- gold
    penpal_ink  = "#2A2218", -- 漆黒 (shikkoku) -- lacquer black

    -- Indicators
    unread_dot = "#B5747A", -- 蘇芳色 -- dusty rose
    divider    = "#D4CFC4", -- Warm grey, near-invisible
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Border
-- ─────────────────────────────────────────────────────────────────────────────

Theme.border = {
    width = 1,
    radius = 0,
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Glyphs -- text glyphs only
-- ─────────────────────────────────────────────────────────────────────────────

Theme.glyph = {
    logo        = "\xE5\x8F\x8B",  -- 友 (CJK, renders on all e-ink)
    arrow       = " \xE2\x86\x92", -- → right arrow (safe ASCII-range)
    dot         = "\xC2\xB7",      -- · middle dot (safe)
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Runtime colour resolution
-- ─────────────────────────────────────────────────────────────────────────────

local function parseHex(hex)
    local s = hex:gsub("#", "")
    local r = tonumber(s:sub(1, 2), 16)
    local g = tonumber(s:sub(3, 4), 16)
    local b = tonumber(s:sub(5, 6), 16)
    return r, g, b
end

local Blitbuffer = require("ffi/blitbuffer")

function Theme.blitColor(hex)
    local r, g, b = parseHex(hex)
    return Blitbuffer.ColorRGB24(r, g, b)
end

function Theme.pageBg(device_profile, season_name)
    if device_profile and device_profile.has_color then
        local tint_hex = Theme.color.season_tint[season_name]
            or Theme.color.bg_page
        local r, g, b = parseHex(tint_hex)
        return Blitbuffer.ColorRGB24(r, g, b)
    end
    return Blitbuffer.COLOR_WHITE
end

function Theme.genreAccent(slug)
    local hex = Theme.color.genre[slug] or Theme.color.text_secondary
    return Theme.blitColor(hex)
end

local Font = require("ui/font")
function Theme.face(size)
    return Font:getFace("cfont", size)
end

function Theme.faceBold(size)
    return Font:getFace("cfont", size)
end

return Theme
