-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

local _ = require("gettext")
return {
    name        = "tomo",
    fullname    = _("Tomo"),
    description = _("Social reading companion"),
    powers      = { "tomo" },
}
