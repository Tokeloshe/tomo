-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/library.lua
-- Read-only access to KoboReader.sqlite -- the Kobo's own reading database.
-- This module NEVER writes to the device database. Not one byte.
-- The architecture non-negotiable is: Tomo™ is a guest in this database.
--
-- Three public functions:
--   Library.getCurrentBook()          → current/most-recent book or nil
--   Library.getShelfCandidates(limit) → top-N books by reading time
--   Library.watchForChange(callback)  → event-driven change detection
--
-- SQLite access uses lua-ljsqlite3 (KOReader's bundled binding).
-- All queries are SELECT-only. Read-only safety is enforced by never
-- running INSERT/UPDATE/DELETE against this database.

local Library = {}

local KOBO_DB_PATH  = "/mnt/onboard/.kobo/KoboReader.sqlite"
local KOBO_WAL_PATH = "/mnt/onboard/.kobo/KoboReader.sqlite-wal"

-- Module-level flag to avoid redefining inotify FFI symbols.
-- LuaJIT raises an error if ffi.cdef sees the same symbol twice.
local _inotify_defs_loaded = false

-- ─────────────────────────────────────────────────────────────────────────────
-- Internal helpers
-- ─────────────────────────────────────────────────────────────────────────────

-- Open KoboReader.sqlite via ljsqlite3.
-- Returns (conn, nil) on success or (nil, error_string) on failure.
-- Callers are responsible for calling conn:close() when done.
local function openDB()
    local ok, SQ3 = pcall(require, "lua-ljsqlite3/init")
    if not ok then
        return nil, "lua-ljsqlite3 module not available"
    end

    local ok_open, conn = pcall(SQ3.open, KOBO_DB_PATH)
    if not ok_open or not conn then
        return nil, "Cannot open KoboReader.sqlite: " .. tostring(conn)
    end
    return conn, nil
end

-- Normalise an ISBN value from KoboReader.sqlite.
-- Returns nil for empty strings and whitespace-only values -- 
-- the Kobo database stores empty string rather than SQL NULL for missing ISBNs.
local function normaliseISBN(raw)
    if not raw then return nil end
    local trimmed = raw:match("^%s*(.-)%s*$")
    if trimmed == "" then return nil end
    return trimmed
end

-- Compute a stable hash from normalized title+author.
-- Available for EVERY book (unlike ISBN which is missing for sideloaded ePubs).
-- Uses djb2 algorithm -- no external dependency, deterministic, collision-adequate.
local function computeBookHash(title, author)
    local function norm(s)
        if not s then return "" end
        s = s:lower()
        s = s:gsub("^the%s+", ""):gsub("^a%s+", ""):gsub("^an%s+", "")
        s = s:gsub("[^%w%s]", ""):gsub("%s+", " ")
        return s:match("^%s*(.-)%s*$") or ""
    end
    local key = norm(title) .. "|" .. norm(author)
    local hash = 5381
    for i = 1, #key do
        hash = ((hash * 33) + key:byte(i)) % 0xFFFFFFFF
    end
    return string.format("%08x", hash)
end

-- Expose as module function for use by api.lua and tests.
Library.computeBookHash = computeBookHash

-- ─────────────────────────────────────────────────────────────────────────────
-- inotify helpers (LuaJIT FFI)
-- ─────────────────────────────────────────────────────────────────────────────

-- Declare the POSIX symbols needed to drive inotify from LuaJIT.
-- Called at most once per process; the flag prevents double-declaration errors.
-- Returns true if the declarations succeeded, false if inotify is unavailable.
local function loadInotifyDefs(ffi)
    if _inotify_defs_loaded then return true end

    -- Attempt the full declaration. If read/close/fcntl are already defined
    -- by KOReader internals, the entire block fails and we try a minimal set.
    local ok = pcall(ffi.cdef, [[
        int inotify_init(void);
        int inotify_add_watch(int fd, const char *pathname, uint32_t mask);
        int inotify_rm_watch(int fd, int wd);
        int read(int fd, void *buf, size_t count);
        int close(int fd);
        int fcntl(int fd, int cmd, ...);
    ]])

    if not ok then
        -- Some symbols already defined by KOReader. Declare only the
        -- inotify-specific calls; read/close/fcntl are already available.
        ok = pcall(ffi.cdef, [[
            int inotify_init(void);
            int inotify_add_watch(int fd, const char *pathname, uint32_t mask);
            int inotify_rm_watch(int fd, int wd);
        ]])
    end

    if ok then
        _inotify_defs_loaded = true
    end
    return _inotify_defs_loaded
end

-- Attempt to create an inotify watcher for the WAL file.
-- `on_change` is called synchronously each time a write event is detected.
-- Returns a watcher object { poll(), stop() } or nil if inotify is unavailable.
--
-- Design: we set the inotify fd to non-blocking mode so that poll() returns
-- immediately when there are no events. UIManager schedules poll() every 2
-- seconds -- cheap when quiet, reactive within 2s of any database write.
local function tryInotify(on_change)
    local ok, ffi = pcall(require, "ffi")
    if not ok then return nil end

    if not loadInotifyDefs(ffi) then return nil end

    local IN_MODIFY  = 0x00000002
    local O_NONBLOCK = 2048
    local F_GETFL    = 3
    local F_SETFL    = 4
    local C = ffi.C

    local fd = C.inotify_init()
    if fd < 0 then return nil end

    -- Set non-blocking so read() returns immediately with -1 when empty.
    -- This makes poll() safe to call on a UIManager schedule without stalling.
    local flags = C.fcntl(fd, F_GETFL)
    C.fcntl(fd, F_SETFL, ffi.cast("int", bit.bor(flags, O_NONBLOCK)))

    local wd = C.inotify_add_watch(fd, KOBO_WAL_PATH, IN_MODIFY)
    if wd < 0 then
        C.close(fd)
        return nil
    end

    local buf     = ffi.new("char[4096]")
    local stopped = false

    return {
        -- Read any pending inotify events. Calls on_change once if any arrived.
        -- Multiple events in a single read are collapsed into one notification -- 
        -- we only care that *something* changed, not how many times.
        poll = function(self)
            if stopped then return end
            local n = C.read(fd, buf, 4096)
            if n > 0 then
                on_change()
            end
        end,

        stop = function(self)
            if stopped then return end
            stopped = true
            C.inotify_rm_watch(fd, wd)
            C.close(fd)
        end,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Public API
-- ─────────────────────────────────────────────────────────────────────────────

-- Return the book the reader is currently reading (or most recently read).
-- "Currently reading" means ReadStatus IN (1, 2) -- started or finished,
-- with a last-read timestamp, ordered most-recent first.
--
-- Returned table:
--   content_id   (string)  ContentID from KoboReader.sqlite (the epub file path)
--   title        (string)  Book title
--   author       (string)  Author (Attribution column)
--   isbn         (string|nil) ISBN-13 if available, nil for sideloaded books
--   progress_pct (number)  Reading progress 0 -- 100
--
-- Returns nil if no book has been read or if the database is unavailable.
function Library.getCurrentBook()
    local conn, err = openDB()
    if not conn then return nil end

    local result = nil
    local ok, results = pcall(conn.exec, conn, [[
        SELECT ContentID, Title, Attribution, ISBN,
               CAST(___PercentRead AS REAL) * 100 AS progress_pct
        FROM content
        WHERE ContentType = 6
          AND ReadStatus IN (1, 2)
          AND DateLastRead IS NOT NULL
        ORDER BY DateLastRead DESC
        LIMIT 1
    ]])

    if ok and results and results.ContentID then
        local title  = results.Title[1]
        local author = results.Attribution[1]
        result = {
            content_id   = results.ContentID[1],
            title        = title,
            author       = author,
            isbn         = normaliseISBN(results.ISBN[1]),
            progress_pct = tonumber(results.progress_pct[1]) or 0,
            book_hash    = computeBookHash(title, author),
        }
    end

    conn:close()
    return result
end

-- Return up to `limit` books sorted by total reading time, descending.
-- This gives the most-read books, which is the best proxy for "books the
-- reader cares enough about to put on their shelf."
-- Sideloaded books without ISBNs are included -- their isbn field will be nil.
--
-- Each entry in the returned array:
--   content_id   (string)  ContentID
--   title        (string)  Book title
--   author       (string)  Author
--   isbn         (string|nil)
--   progress_pct (number)  0 -- 100
--   time_spent_s (integer) Total seconds of active reading
--
-- Returns an empty table (never nil) if the database is unavailable.
function Library.getShelfCandidates(limit)
    limit = (type(limit) == "number" and limit > 0) and math.floor(limit) or 10

    local conn, err = openDB()
    if not conn then return {} end

    local results_out = {}
    local ok, results = pcall(conn.exec, conn, string.format([[
        SELECT ContentID, Title, Attribution, ISBN,
               CAST(___PercentRead AS REAL) * 100 AS progress_pct,
               TimeSpentReading
        FROM content
        WHERE ContentType = 6
          AND TimeSpentReading > 0
        ORDER BY TimeSpentReading DESC
        LIMIT %d
    ]], limit))

    if ok and results and results.ContentID then
        for i = 1, #results.ContentID do
            results_out[#results_out + 1] = {
                content_id   = results.ContentID[i],
                title        = results.Title[i],
                author       = results.Attribution[i],
                isbn         = normaliseISBN(results.ISBN[i]),
                progress_pct = tonumber(results.progress_pct[i]) or 0,
                time_spent_s = tonumber(results.TimeSpentReading[i]) or 0,
            }
        end
    end

    conn:close()
    return results_out
end

-- Set up event-driven detection of book changes.
-- Watches the KoboReader.sqlite WAL file for writes. When Nickel or KOReader
-- updates the database (page turn, book open, etc.) the WAL changes. Tomo™
-- re-queries the current book and fires `callback(new_book)` only when the
-- book identity (ContentID) has actually changed. The callback is also fired
-- immediately on startup to populate the initial state.
--
-- Strategy:
--   1. Try inotify via LuaJIT FFI -- polls every 2s, reacts within 2s.
--   2. Fall back to lfs mtime polling every 5 minutes if inotify is absent.
--      Documented as a known compromise (battery vs. reactivity trade-off).
--
-- Returns a watcher object. Call watcher:stop() when Tomo™ is unloaded or
-- when watching is no longer needed, to cancel the UIManager schedule.
--
-- `callback` signature: callback(book_or_nil)
--   book_or_nil -- the new current book table, or nil if no book is active
function Library.watchForChange(callback)
    -- UIManager is required here because this function installs a recurring
    -- scheduled task into KOReader's event loop. This is appropriate: the
    -- file-watch lifecycle is tied to the plugin's active session.
    local UIManager = require("ui/uimanager")

    -- The last ContentID we reported to the caller.
    -- Starts as a sentinel that cannot match any real ContentID.
    local last_content_id = false   -- false ≠ nil; distinguishes "not yet checked"

    -- Re-query the database and fire the callback if the book changed.
    -- Fires on startup (initial population) and again whenever the WAL changes.
    local function checkForBookChange()
        local book = Library.getCurrentBook()
        local current_id = book and book.content_id or nil

        if current_id ~= last_content_id then
            last_content_id = current_id
            pcall(callback, book)   -- protect the caller from crashing the loop
        end
    end

    -- Attempt inotify first. on_change = checkForBookChange so each WAL event
    -- triggers an immediate re-query. The 2s poll keeps memory pressure near zero.
    local inotify = tryInotify(checkForBookChange)

    -- The returned handle. _stopped gates both the inotify fd and the schedule.
    local handle = { _stopped = false }

    local poll_fn

    if inotify then
        -- inotify path: call poll() every 2 seconds.
        -- poll() reads the non-blocking fd and fires on_change if events exist.
        poll_fn = function()
            if handle._stopped then return end
            inotify:poll()
            UIManager:scheduleIn(2, poll_fn)
        end
    else
        -- Fallback: compare WAL mtime every 5 minutes.
        -- Less responsive but battery-safe when inotify syscall is missing.
        -- SKILLS.md §3.4 documents this as the accepted fall-back behaviour.
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if not ok_lfs then
            -- lfs also unavailable -- we cannot watch at all on this build.
            -- Return a no-op handle so callers do not need to nil-check.
            handle.stop = function(self) end
            -- Still do the initial check so the caller gets an initial value.
            checkForBookChange()
            return handle
        end

        local last_mtime = 0
        poll_fn = function()
            if handle._stopped then return end
            local attr = lfs.attributes(KOBO_WAL_PATH)
            if attr and attr.modification > last_mtime then
                last_mtime = attr.modification
                checkForBookChange()
            end
            UIManager:scheduleIn(300, poll_fn)
        end
    end

    function handle:stop()
        if self._stopped then return end
        self._stopped = true
        UIManager:unschedule(poll_fn)
        if inotify then
            inotify:stop()
        end
    end

    -- Fire immediately so the caller has a current book value before the first
    -- WAL change. This is the synchronous initial population.
    checkForBookChange()

    -- Start the recurring poll.
    UIManager:scheduleIn(inotify and 2 or 300, poll_fn)

    return handle
end

return Library
