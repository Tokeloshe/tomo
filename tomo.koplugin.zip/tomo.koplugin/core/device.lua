-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/device.lua
-- Device detection with 5-tier capability model.
-- Uses KOReader's Device module as the authoritative source.
--
-- TIER 2: Colour + Stylus (Kobo Libra Colour)
-- TIER 3: Stylus, No Colour (Sage, Elipsa, Elipsa 2E, Kindle Scribe)
-- TIER 4: Colour, No Stylus -- finger draw (Clara Colour, Kindle ColorSoft)
-- TIER 5: Finger Draw, B&W (Clara HD/BW, Libra 2, Forma, PW1-6, Oasis, etc.)
-- TIER 6: Text Only -- IR touch (Touch, Mini, Glo, Aura HD, etc.)

local TomoDevice = {}

local _profile = nil

-- Stylus models: Kobo MPP/MPP2 + Kindle Wacom EMR
local STYLUS_MODELS = {
    Kobo_monza   = true,  -- Libra Colour (MPP 2.0)
    Kobo_condor  = true,  -- Elipsa 2E (MPP 2.0)
    Kobo_europa  = true,  -- Elipsa (MPP)
    Kobo_cadmus  = true,  -- Sage (MPP)
}

-- IR touch models: beam-break detection, NOT suitable for drawing
local IR_MODELS = {
    Kobo_trilogy  = true,  -- Touch
    Kobo_pixie    = true,  -- Mini
    Kobo_kraken   = true,  -- Glo
    Kobo_dragon   = true,  -- Aura HD
    Kobo_dahlia   = true,  -- Aura H2O
    Kobo_pika     = true,  -- Touch 2.0
    Kobo_alyssum  = true,  -- Glo HD
    Kobo_star     = true,  -- Aura Edition 2
}

function TomoDevice.getProfile()
    if _profile then return _profile end

    local logger = require("logger")
    local ok, KODevice = pcall(require, "device")

    if not ok or not KODevice then
        logger.warn("Tomo Device: KOReader Device module not available, using defaults")
        _profile = TomoDevice._buildDefault()
        return _profile
    end

    local model = KODevice.model or "unknown"

    -- Colour detection
    local has_color = false
    if type(KODevice.hasColorScreen) == "function" then
        has_color = KODevice:hasColorScreen()
    elseif KODevice.hasColorScreen == true then
        has_color = true
    end

    -- Stylus detection
    local has_stylus = STYLUS_MODELS[model] or false
    -- Kindle Scribe: KOReader exposes hasWAXCTouchscreen or model contains "Scribe"
    if not has_stylus then
        if type(KODevice.hasWAXCTouchscreen) == "function" then
            has_stylus = KODevice:hasWAXCTouchscreen()
        elseif tostring(model):find("Scribe") then
            has_stylus = true
        end
    end
    if os.getenv("TOMO_FORCE_STYLUS") == "1" then has_stylus = true end

    -- Screen dimensions
    local screen_w, screen_h = 1264, 1680
    if KODevice.screen then
        local sw = KODevice.screen:getWidth()
        local sh = KODevice.screen:getHeight()
        if sw and sw > 0 then screen_w = sw end
        if sh and sh > 0 then screen_h = sh end
    end

    -- Touch type: capacitive vs IR
    local has_touch = true
    if type(KODevice.hasNoTouchscreen) == "function" then
        has_touch = not KODevice:hasNoTouchscreen()
    end
    local has_capacitive = has_touch and not IR_MODELS[model]
    -- Kindle IR models
    if model == "KindleTouch" or model == "KindleBasic" or model == "KindleBasic2" then
        has_capacitive = false
    end
    -- Kindle 4 has no touch at all
    if model == "Kindle4" then has_touch = false; has_capacitive = false end

    -- Platform flags
    local is_kindle = type(KODevice.isKindle) == "function" and KODevice:isKindle() or false
    local is_kobo = type(KODevice.isKobo) == "function" and KODevice:isKobo() or false
    local has_keys = type(KODevice.hasKeys) == "function" and KODevice:hasKeys() or false

    -- Tier assignment
    local tier
    if has_color and has_stylus then        tier = 2
    elseif has_stylus then                  tier = 3
    elseif has_color and has_capacitive then tier = 4
    elseif has_capacitive then              tier = 5
    else                                    tier = 6
    end

    -- Drawing mode
    local can_draw = tier <= 5
    local draw_mode = has_stylus and "stylus" or (can_draw and "finger" or "none")
    local pen_width = has_stylus and 4 or 8

    -- Compact layout flag (tiny screens)
    local compact = (screen_w * screen_h) < (1024 * 758)

    logger.warn(string.format(
        "Tomo Device: model=%s screen=%dx%d tier=%d color=%s stylus=%s cap=%s draw=%s compact=%s",
        model, screen_w, screen_h, tier, tostring(has_color), tostring(has_stylus),
        tostring(has_capacitive), draw_mode, tostring(compact)))

    _profile = {
        model_code         = model,
        name               = model,
        has_color          = has_color,
        has_stylus         = has_stylus,
        has_capacitive     = has_capacitive,
        has_touch          = has_touch,
        has_keys           = has_keys,
        is_kindle          = is_kindle,
        is_kobo            = is_kobo,
        screen_w           = screen_w,
        screen_h           = screen_h,
        tier               = tier,
        can_draw           = can_draw,
        draw_mode          = draw_mode,
        pen_width          = pen_width,
        compact            = compact,
    }
    return _profile
end

function TomoDevice._buildDefault()
    return {
        model_code     = "unknown",
        name           = "Unknown",
        has_color      = false,
        has_stylus     = false,
        has_capacitive = true,
        has_touch      = true,
        has_keys       = false,
        is_kindle      = false,
        is_kobo        = false,
        screen_w       = 1264,
        screen_h       = 1680,
        tier           = 5,
        can_draw       = true,
        draw_mode      = "finger",
        pen_width      = 8,
        compact        = false,
    }
end

function TomoDevice.resetCache()
    _profile = nil
end

return TomoDevice
