-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/api.lua
-- All HTTP communication with Supabase REST API.
-- No HTTP calls exist anywhere else in the codebase -- all network I/O is here.
--
-- Pattern: synchronous calls via KOReader's socket.http + ltn12 + socketutil.
-- This is the pattern used by every working KOReader plugin (exporter, opds, etc.).
-- Callbacks are retained in the public API so callers don't need to change,
-- but they are invoked synchronously (not deferred via UIManager).

local Api = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Internal helpers
-- ─────────────────────────────────────────────────────────────────────────────

local rapidjson = require("rapidjson")

-- Sanitize ISO 8601 timestamps for PostgREST URL query parameters.
-- 1. Strip sub-second precision: .909894 → removed
-- 2. Replace +00:00 with Z to avoid URL-encoding issues (+ becomes space)
-- "2026-03-19T21:35:47.909894+00:00" → "2026-03-19T21:35:47Z"
local function cleanTimestamp(ts)
    if not ts or type(ts) ~= "string" then return ts end
    -- Strip microseconds
    ts = ts:gsub("(%d%d:%d%d:%d%d)%.%d+", "%1")
    -- Replace +00:00 timezone offset with Z (prevents + being URL-decoded to space)
    ts = ts:gsub("%+00:00$", "Z")
    ts = ts:gsub("%+00:00", "Z")
    return ts
end

-- Build the common Supabase REST headers.
local function buildHeaders(jwt, anon_key)
    return {
        ["apikey"]        = anon_key,
        ["Authorization"] = "Bearer " .. (jwt or anon_key),
        ["Content-Type"]  = "application/json",
        ["Accept"]        = "application/json",
    }
end

-- Core HTTP request method. Synchronous, blocks until response arrives.
-- Returns (nil, decoded_table) on success, (err_string, nil) on failure.
-- `extra_headers` is an optional table merged into the default headers.
function Api:_request(method, path, body_table, extra_headers)
    local http       = require("socket.http")
    local ltn12      = require("ltn12")
    local socketutil = require("socketutil")
    local ok_rec, Recorder = pcall(require, "core/recorder")

    local url = self.config.supabase_url .. path
    if ok_rec then Recorder.log("API", method .. " " .. path) end
    local headers = buildHeaders(self.jwt, self.config.supabase_key)
    if extra_headers then
        for k, v in pairs(extra_headers) do headers[k] = v end
    end

    local body_str = nil
    if body_table then
        body_str = rapidjson.encode(body_table)
        headers["Content-Length"] = tostring(#body_str)
    end

    local sink = {}
    local request = {
        url     = url,
        method  = method,
        sink    = ltn12.sink.table(sink),
        headers = headers,
    }
    if body_str then
        request.source = ltn12.source.string(body_str)
    end

    socketutil:set_timeout(socketutil.LARGE_BLOCK_TIMEOUT, socketutil.LARGE_TOTAL_TIMEOUT)
    local _, code = http.request(request)
    socketutil:reset_timeout()

    local logger = require("logger")
    if type(code) ~= "number" then
        local err_msg = tostring(code or "no response")
        logger.warn("Tomo API: request to " .. path .. " failed: " .. err_msg)
        if ok_rec then Recorder.log("API", "FAIL " .. method .. " " .. path .. " => " .. err_msg) end
        return err_msg, nil
    end
    if code < 200 or code >= 300 then
        local err_body = table.concat(sink)
        logger.warn("Tomo API: " .. method .. " " .. path .. " => HTTP " .. tostring(code) .. " " .. (err_body or ""):sub(1, 200))
        if ok_rec then Recorder.log("API", "HTTP " .. code .. " " .. method .. " " .. path .. " " .. (err_body or ""):sub(1, 100)) end
        return "HTTP " .. tostring(code), nil
    end
    if ok_rec then Recorder.log("API", "OK " .. method .. " " .. path .. " => " .. code) end

    local response_body = table.concat(sink)
    if not response_body or response_body == "" then
        return nil, nil
    end

    local ok, decoded = pcall(rapidjson.decode, response_body)
    if not ok then
        return "JSON parse error", nil
    end
    return nil, decoded
end

-- Upload a binary file to Supabase Storage. Returns (nil, storage_key) or (err, nil).
function Api:_upload(storage_path, file_path)
    local http       = require("socket.http")
    local ltn12      = require("ltn12")
    local socketutil = require("socketutil")

    local f = io.open(file_path, "rb")
    if not f then return "Cannot read file", nil end
    local content = f:read("*a")
    f:close()

    local url = self.config.supabase_url .. "/storage/v1/object/ink/" .. storage_path
    local headers = {
        ["apikey"]         = self.config.supabase_key,
        ["Authorization"]  = "Bearer " .. self.jwt,
        ["Content-Type"]   = "image/png",
        ["Content-Length"]  = tostring(#content),
    }

    local sink = {}
    socketutil:set_timeout(socketutil.FILE_BLOCK_TIMEOUT, socketutil.FILE_TOTAL_TIMEOUT)
    local _, code = http.request{
        url     = url,
        method  = "POST",
        sink    = ltn12.sink.table(sink),
        source  = ltn12.source.string(content),
        headers = headers,
    }
    socketutil:reset_timeout()

    if type(code) ~= "number" or code < 200 or code >= 300 then
        return "Upload failed: " .. tostring(code), nil
    end

    local response_body = table.concat(sink)
    local ok, decoded = pcall(rapidjson.decode, response_body)
    if ok and type(decoded) == "table" and decoded.Key then
        return nil, decoded.Key
    end
    return "Upload response missing Key", nil
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Constructor
-- ─────────────────────────────────────────────────────────────────────────────

-- Create a new Api instance.
-- `config` is the tomo.lua config table (supabase_url, supabase_key).
-- `jwt` is the current user's JWT (may be nil if unauthenticated).
function Api.new(config, jwt, user_id)
    local instance = {
        config  = config,
        jwt     = jwt or config.supabase_key,
        user_id = user_id,
    }
    return setmetatable(instance, { __index = Api })
end

-- Update the JWT and user_id after a token refresh or late auth.
function Api:setJWT(jwt, user_id)
    self.jwt = jwt
    if user_id then self.user_id = user_id end
end

-- Check if the API has a real user JWT (not just the anon key).
-- When auth fails, jwt falls back to config.supabase_key (the anon key).
-- Write operations (POST, PATCH, DELETE to user data) require a real JWT.
function Api:isAuthenticated()
    return self.user_id ~= nil and self.jwt ~= self.config.supabase_key
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Rooms
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch all active rooms: genre rooms + active book rooms.
-- callback(err, rooms_array)
function Api:getRooms(callback)
    local err, data = self:_request("GET",
        "/rest/v1/rooms"
        .. "?is_active=eq.true"
        .. "&order=kind.asc,bloomed_at.desc"
        .. "&select=id,kind,name,slug,isbn,genre_tag,bloomed_at,last_spoke_at")
    callback(err, data)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Room membership
-- ─────────────────────────────────────────────────────────────────────────────

-- Silently join a room (upsert into room_members).
-- Joining is weightless -- no confirmation, no notification.
function Api:joinRoom(room_id, user_id, callback)
    if not room_id then if callback then callback("room_id is nil") end; return end
    if not self:isAuthenticated() then if callback then callback("not authenticated") end; return end
    local err, data = self:_request("POST", "/rest/v1/room_members", {
        room_id   = room_id,
        user_id   = user_id,
        joined_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    }, { ["Prefer"] = "resolution=merge-duplicates" })
    if callback then callback(err, data) end
end

-- Update last_read_at for a user in a room (clears the unread dot).
function Api:markRead(room_id, user_id, callback)
    if not room_id then if callback then callback("room_id is nil") end; return end
    local err, data = self:_request("PATCH",
        "/rest/v1/room_members"
        .. "?room_id=eq." .. room_id
        .. "&user_id=eq." .. user_id,
        { last_read_at = os.date("!%Y-%m-%dT%H:%M:%SZ") },
        { ["Prefer"] = "return=minimal" })
    if callback then callback(err, data) end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Messages
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch messages for a room. If `after_ts` is provided, fetches only messages
-- created after that timestamp (incremental fetch).
-- callback(err, messages_array)
function Api:getMessages(room_id, page_size, after_ts, callback)
    if not room_id then callback("room_id is nil", nil); return end
    local url = "/rest/v1/messages"
        .. "?room_id=eq." .. room_id
        .. "&select=id,room_id,user_id,kind,body,ink_url,device_ts,created_at,delivers_at"
        .. ",users(username)"
        .. "&order=created_at.desc"
        .. "&limit=" .. tostring(page_size or 20)
    if after_ts then
        url = url .. "&created_at=gt." .. cleanTimestamp(after_ts)
    end

    local err, data = self:_request("GET", url)
    if err then callback(err, nil); return end

    -- Flatten the joined username from the nested users object.
    if type(data) == "table" then
        for _, msg in ipairs(data) do
            if type(msg.users) == "table" then
                msg.username = msg.users.username
                msg.users = nil
            end
        end
    end
    callback(nil, data)
end

-- Fetch messages older than `before_ts` for pagination (load more).
function Api:getOlderMessages(room_id, page_size, before_ts, callback)
    if not room_id then callback("room_id is nil", nil); return end
    local url = "/rest/v1/messages"
        .. "?room_id=eq." .. room_id
        .. "&created_at=lt." .. cleanTimestamp(before_ts)
        .. "&select=id,room_id,user_id,kind,body,ink_url,device_ts,created_at,delivers_at"
        .. ",users(username)"
        .. "&order=created_at.desc"
        .. "&limit=" .. tostring(page_size or 20)

    local err, data = self:_request("GET", url)
    if err then callback(err, nil); return end

    if type(data) == "table" then
        for _, msg in ipairs(data) do
            if type(msg.users) == "table" then
                msg.username = msg.users.username
                msg.users = nil
            end
        end
    end
    callback(nil, data)
end

-- Send a text message. The user_id is included so Supabase RLS can validate
-- the sender matches auth.uid(). Without it, the INSERT fails with HTTP 403.
-- callback(err, created_message)
function Api:sendMessage(room_id, body, device_ts, callback)
    if not room_id then callback("room_id is nil", nil); return end
    if not self:isAuthenticated() then callback("not authenticated", nil); return end
    local err, data = self:_request("POST", "/rest/v1/messages", {
        room_id   = room_id,
        user_id   = self.user_id,
        body      = body,
        kind      = "text",
        device_ts = device_ts,
    }, { ["Prefer"] = "return=representation" })
    callback(err, data)
end

-- Send a pen pal ink message. `ink_url` is the Supabase Storage path.
-- `delivers_at` is computed server-side (Edge Function or trigger).
function Api:sendInkMessage(room_id, ink_url, device_ts, callback)
    if not room_id then callback("room_id is nil", nil); return end
    if not self:isAuthenticated() then callback("not authenticated", nil); return end
    local err, data = self:_request("POST", "/rest/v1/messages", {
        room_id   = room_id,
        user_id   = self.user_id,
        ink_url   = ink_url,
        kind      = "ink",
        device_ts = device_ts,
    }, { ["Prefer"] = "return=representation" })
    callback(err, data)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Unread state (batch, not per-room Realtime)
-- ─────────────────────────────────────────────────────────────────────────────

-- Check unread state for multiple rooms in a single REST call.
-- Returns a map: { [room_id] = true/false }
-- Used on home screen load -- not Realtime.
-- callback(err, { [room_id] = has_new_bool })
function Api:checkUnread(user_id, room_ids, callback)
    if not room_ids or #room_ids == 0 then
        callback(nil, {})
        return
    end

    -- Fetch room_members for the user to get last_read_at per room.
    local ids_joined = table.concat(room_ids, ",")
    local err1, membership_data = self:_request("GET",
        "/rest/v1/room_members"
        .. "?user_id=eq." .. user_id
        .. "&room_id=in.(" .. ids_joined .. ")"
        .. "&select=room_id,last_read_at")

    if err1 then callback(err1, nil); return end

    local last_read_map = {}
    if type(membership_data) == "table" then
        for _, m in ipairs(membership_data) do
            last_read_map[m.room_id] = m.last_read_at
        end
    end

    -- Batch query: get recent messages per room to compare against last_read_at.
    local err2, msg_data = self:_request("GET",
        "/rest/v1/messages"
        .. "?room_id=in.(" .. ids_joined .. ")"
        .. "&user_id=neq." .. user_id
        .. "&select=room_id,created_at"
        .. "&order=created_at.desc"
        .. "&limit=" .. tostring(math.max(#room_ids * 5, 50)))

    if err2 then callback(err2, nil); return end

    local unread_map = {}
    for _, room_id in ipairs(room_ids) do
        unread_map[room_id] = false
    end
    if type(msg_data) == "table" then
        for _, msg in ipairs(msg_data) do
            local last_read = last_read_map[msg.room_id]
            if not last_read or msg.created_at > last_read then
                unread_map[msg.room_id] = true
            end
        end
    end
    callback(nil, unread_map)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Reading presence
-- ─────────────────────────────────────────────────────────────────────────────

-- Upsert the user's current reading book into reading_presence.
-- This is what triggers book room blooming when 2+ readers share an ISBN.
-- Called whenever library.lua detects a book change.
function Api:updatePresence(user_id, book, callback)
    if not self:isAuthenticated() then if callback then callback("not authenticated") end; return end
    if not book then
        if callback then callback(nil, nil) end
        return
    end
    local book_hash = book.book_hash or ""
    local isbn = book.isbn or ""
    if book_hash == "" and isbn == "" then
        if callback then callback(nil, nil) end
        return
    end
    local pct = math.floor(book.progress_pct or 0)
    pct = math.max(0, math.min(100, pct))
    local err, data = self:_request("POST", "/rest/v1/reading_presence", {
        user_id      = user_id,
        book_hash    = book_hash ~= "" and book_hash or nil,
        isbn         = isbn ~= "" and isbn or nil,
        title        = book.title,
        progress_pct = pct,
        updated_at   = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    }, { ["Prefer"] = "resolution=merge-duplicates" })

    -- Defensive: if 400 with "book_hash" error (column missing pre-migration),
    -- retry without book_hash so the app works before migration is run.
    if err and tostring(err):find("400") and book_hash ~= "" then
        err, data = self:_request("POST", "/rest/v1/reading_presence", {
            user_id      = user_id,
            isbn         = isbn ~= "" and isbn or nil,
            title        = book.title,
            progress_pct = pct,
            updated_at   = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        }, { ["Prefer"] = "resolution=merge-duplicates" })
    end
    if callback then callback(err, data) end
end

-- Trigger book room bloom check via RPC.
-- Silent on 404 (function not created yet -- expected pre-migration).
function Api:bloomRooms(book, callback)
    local body = {}
    if book then
        body.p_user_id = self.user_id
        body.p_book_hash = book.book_hash or ""
        body.p_title = book.title or ""
        body.p_author = book.author or ""
    end
    local err, data = self:_request("POST", "/rest/v1/rpc/bloom_book_rooms", body)
    -- Silence 404: function doesn't exist yet, not an error worth logging
    if err and tostring(err):find("404") then
        if callback then callback(nil, nil) end
        return
    end
    if callback then callback(err, data) end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Users / profile
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch the current user's profile from Supabase.
-- callback(err, user_table)
function Api:getUser(user_id, callback)
    local err, data = self:_request("GET",
        "/rest/v1/users"
        .. "?id=eq." .. user_id
        .. "&select=id,username,haiku_bio,stylus_user,created_at,last_seen"
        .. "&limit=1")

    if err then callback(err, nil); return end
    if type(data) == "table" and data[1] then
        callback(nil, data[1])
    else
        callback("User not found", nil)
    end
end

-- Create the user record after sign-up. Called once, immediately after auth.
function Api:createUser(user_id, username, device_hash, stylus_user, callback)
    -- REVIEW: createUser is not yet wired into the signup flow.
    -- The caller (auth.lua) must pass the real device_hash from Auth.deviceHash().
    local err, data = self:_request("POST", "/rest/v1/users", {
        id           = user_id,
        username     = username,
        device_hash  = device_hash,
        stylus_user  = stylus_user or false,
    }, { ["Prefer"] = "return=representation" })
    callback(err, data)
end

-- Update the user's profile (username, haiku_bio).
function Api:updateUser(user_id, fields, callback)
    local err, data = self:_request("PATCH",
        "/rest/v1/users?id=eq." .. user_id,
        fields,
        { ["Prefer"] = "return=minimal" })
    if callback then callback(err, data) end
end

-- Fetch another user's public profile (read-only -- no contact info exposed).
function Api:getUserProfile(user_id, callback)
    local err, data = self:_request("GET",
        "/rest/v1/users"
        .. "?id=eq." .. user_id
        .. "&select=id,username,haiku_bio,stylus_user"
        .. "&limit=1")

    if err then callback(err, nil); return end
    callback(nil, type(data) == "table" and data[1] or nil)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Reading shelf
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch the user's reading shelf (up to 10 books).
function Api:getShelf(user_id, callback)
    local err, data = self:_request("GET",
        "/rest/v1/reading_shelf"
        .. "?user_id=eq." .. user_id
        .. "&order=position.asc"
        .. "&select=id,isbn,title,author,cover_url,position")
    callback(err, data)
end

-- Replace the entire reading shelf with a new ordered list.
-- `shelf_items` is an array of { isbn, title, author, cover_url, position }.
function Api:saveShelf(user_id, shelf_items, callback)
    -- Delete existing shelf entries first.
    local err1 = self:_request("DELETE",
        "/rest/v1/reading_shelf?user_id=eq." .. user_id)
    if err1 then callback(err1, nil); return end

    if not shelf_items or #shelf_items == 0 then
        callback(nil, {})
        return
    end

    -- Attach user_id to each item and insert.
    for _, item in ipairs(shelf_items) do
        item.user_id = user_id
    end
    local err2, data = self:_request("POST", "/rest/v1/reading_shelf",
        shelf_items,
        { ["Prefer"] = "return=minimal" })
    callback(err2, data)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Ink image upload (Supabase Storage)
-- ─────────────────────────────────────────────────────────────────────────────

-- Upload a PNG file to Supabase Storage.
-- `storage_path` is relative to the bucket root, e.g. "ink/{room_id}/{msg_id}.png".
-- callback(err, public_url_or_nil)
function Api:uploadInkImage(file_path, storage_path, callback)
    local err, key = self:_upload(storage_path, file_path)
    callback(err, key)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Pen pal
-- ─────────────────────────────────────────────────────────────────────────────

-- Enter the pen pal waiting pool with genre preferences.
function Api:enterPenpalPool(user_id, genres, callback)
    local err, data = self:_request("POST", "/rest/v1/penpal_pool", {
        user_id    = user_id,
        genres     = genres,
        entered_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
    }, { ["Prefer"] = "resolution=merge-duplicates" })
    if callback then callback(err, data) end
end

-- Fetch the current user's active pen pal bond (if any).
-- Defensive: if ended_at column doesn't exist yet (pre-007 migration),
-- falls back to querying without the ended_at filter.
function Api:getPenpalBond(user_id, callback)
    local base_filter = "?or=(user_a.eq." .. user_id .. ",user_b.eq." .. user_id .. ")"
    local select_cols = "&select=id,user_a,user_b,room_id,season_met,matched_at,ended_at,ended_by"

    -- Try with ended_at filter first (requires migration 007)
    local err, data = self:_request("GET",
        "/rest/v1/penpal_bonds"
        .. base_filter
        .. "&ended_at=is.null"
        .. select_cols
        .. "&limit=1")

    -- If the query failed because ended_at column doesn't exist, retry without it
    if err then
        local logger = require("logger")
        logger.warn("Tomo API: getPenpalBond with ended_at filter failed (" .. tostring(err)
            .. "), retrying without filter")
        err, data = self:_request("GET",
            "/rest/v1/penpal_bonds"
            .. base_filter
            .. select_cols
            .. "&limit=1")
    end

    if err then callback(err, nil); return end
    callback(nil, type(data) == "table" and data[1] or nil)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Account deletion (Leave Tomo)
-- ─────────────────────────────────────────────────────────────────────────────

-- Delete the user's account and all associated data from Supabase.
-- ON DELETE CASCADE handles messages, room_members, reading_shelf, etc.
-- The caller clears the local cache after this returns success.
function Api:deleteAccount(user_id, callback)
    local err, data = self:_request("DELETE",
        "/rest/v1/users?id=eq." .. user_id)
    callback(err, data)
end

-- Export all user data as a JSON dump. Fetches users, messages, shelf, bonds.
-- callback(err, export_table)
function Api:exportData(user_id, callback)
    local data = {}

    local err1, user = self:_request("GET",
        "/rest/v1/users?id=eq." .. user_id
        .. "&select=id,username,haiku_bio,stylus_user,created_at,last_seen&limit=1")
    data.user = type(user) == "table" and user[1] or nil

    local err2, shelf = self:_request("GET",
        "/rest/v1/reading_shelf?user_id=eq." .. user_id
        .. "&order=position.asc&select=id,isbn,title,author,cover_url,position")
    data.shelf = shelf

    local err3, bond_data = self:_request("GET",
        "/rest/v1/penpal_bonds"
        .. "?or=(user_a.eq." .. user_id .. ",user_b.eq." .. user_id .. ")"
        .. "&select=id,user_a,user_b,room_id,season_met,matched_at&limit=1")
    data.penpal_bond = type(bond_data) == "table" and bond_data[1] or nil

    local err = err1 or err2 or err3
    callback(err, data)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Pen pal ink letter queries
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch delivered pen pal letters (delivers_at <= now()).
-- callback(err, messages_array)
function Api:getDeliveredLetters(room_id, limit, callback)
    if not room_id then callback("room_id is nil", nil); return end
    local url = "/rest/v1/messages"
        .. "?room_id=eq." .. room_id
        .. "&kind=eq.ink"
        .. "&delivers_at=lte.now()"
        .. "&select=id,room_id,user_id,kind,body,ink_url,device_ts,created_at,delivers_at"
        .. ",users(username)"
        .. "&order=created_at.desc"
        .. "&limit=" .. tostring(limit or 20)

    local err, data = self:_request("GET", url)
    if err then callback(err, nil); return end

    if type(data) == "table" then
        for _, msg in ipairs(data) do
            if type(msg.users) == "table" then
                msg.username = msg.users.username
                msg.users = nil
            end
        end
    end
    callback(nil, data)
end

-- Check if user has letters in transit (delivers_at > now()).
-- callback(err, has_in_transit_bool)
function Api:hasLettersInTransit(room_id, user_id, callback)
    if not room_id then callback("room_id is nil", false); return end
    local url = "/rest/v1/messages"
        .. "?room_id=eq." .. room_id
        .. "&user_id=eq." .. user_id
        .. "&kind=eq.ink"
        .. "&delivers_at=gt.now()"
        .. "&select=id"
        .. "&limit=1"

    local err, data = self:_request("GET", url)
    if err then callback(err, false); return end
    local has = type(data) == "table" and #data > 0
    callback(nil, has)
end

-- Send an ink message with delivery delay (6-18 hours).
-- `delivers_at` is an ISO 8601 timestamp in the future.
function Api:sendInkLetter(room_id, ink_url, device_ts, delivers_at, callback)
    if not room_id then callback("room_id is nil", nil); return end
    if not self:isAuthenticated() then callback("not authenticated", nil); return end
    local err, data = self:_request("POST", "/rest/v1/messages", {
        room_id     = room_id,
        user_id     = self.user_id,
        kind        = "ink",
        ink_url     = ink_url,
        device_ts   = device_ts,
        delivers_at = delivers_at,
    }, { ["Prefer"] = "return=representation" })
    callback(err, data)
end

-- Download a file from Supabase Storage to a local path.
-- Returns (nil) on success or (err_string) on failure.
function Api:downloadInkImage(storage_path, local_path)
    local http       = require("socket.http")
    local ltn12      = require("ltn12")
    local socketutil = require("socketutil")
    local logger     = require("logger")

    -- The storage_path from the DB may be a full key like "ink/test/file.png"
    -- or a relative path. The Supabase Storage authenticated download URL is:
    -- /storage/v1/object/authenticated/BUCKET_NAME/PATH
    -- If the path already starts with "ink/", don't double-prefix the bucket name.
    -- Private bucket: MUST use /object/authenticated/BUCKET/PATH
    -- The storage_path from DB may be "ink/test/file.png" (includes bucket name)
    -- or just "test/file.png" (relative to bucket). Handle both.
    local url
    if storage_path:match("^ink/") then
        -- Path includes bucket name already: ink/test/file.png
        -- URL: /storage/v1/object/authenticated/ink/test/file.png
        url = self.config.supabase_url .. "/storage/v1/object/authenticated/" .. storage_path
    else
        -- Relative path: test/file.png
        -- URL: /storage/v1/object/authenticated/ink/test/file.png
        url = self.config.supabase_url .. "/storage/v1/object/authenticated/ink/" .. storage_path
    end
    logger.warn("Tomo: downloadInkImage URL=" .. url)

    local headers = {
        ["apikey"]        = self.config.supabase_key,
        ["Authorization"] = "Bearer " .. self.jwt,
    }

    local f = io.open(local_path, "wb")
    if not f then return "Cannot write to " .. local_path end

    socketutil:set_timeout(socketutil.FILE_BLOCK_TIMEOUT, socketutil.FILE_TOTAL_TIMEOUT)
    local _, code = http.request{
        url     = url,
        method  = "GET",
        sink    = ltn12.sink.file(f),
        headers = headers,
    }
    socketutil:reset_timeout()

    if type(code) ~= "number" or code < 200 or code >= 300 then
        os.remove(local_path)
        logger.warn("Tomo: downloadInkImage FAILED: " .. tostring(code))
        return "Download failed: " .. tostring(code)
    end
    logger.warn("Tomo: downloadInkImage OK: " .. local_path)
    return nil
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Postcrossing
-- ─────────────────────────────────────────────────────────────────────────────

-- Send a postcrossing letter (add to pool).
function Api:sendPostcrossingLetter(ink_url, callback)
    local err, data = self:_request("POST", "/rest/v1/postcrossing_pool", {
        sender_id = self.user_id,
        ink_url   = ink_url,
    }, { ["Prefer"] = "return=representation" })
    callback(err, data)
end

-- Claim a postcrossing letter after sending one (RPC call).
function Api:claimPostcrossingLetter(callback)
    local err, data = self:_request("POST", "/rest/v1/rpc/claim_postcrossing_letter", {
        p_user_id = self.user_id,
    })
    callback(err, data)
end

-- Get user's postcrossing stats: sent count and received count.
-- callback(err, { sent = N, received = N })
function Api:getPostcrossingStats(callback)
    -- Sent count
    local err1, sent_data = self:_request("GET",
        "/rest/v1/postcrossing_pool"
        .. "?sender_id=eq." .. self.user_id
        .. "&select=id")
    local sent = 0
    if not err1 and type(sent_data) == "table" then sent = #sent_data end

    -- Received count (delivered)
    local err2, recv_data = self:_request("GET",
        "/rest/v1/postcrossing_pool"
        .. "?claimed_by=eq." .. self.user_id
        .. "&delivered_at=lte.now()"
        .. "&select=id")
    local received = 0
    if not err2 and type(recv_data) == "table" then received = #recv_data end

    callback(err1 or err2, { sent = sent, received = received })
end

-- Get received postcrossing letters (delivered).
-- callback(err, letters_array)
function Api:getPostcrossingReceived(callback)
    local err, data = self:_request("GET",
        "/rest/v1/postcrossing_pool"
        .. "?claimed_by=eq." .. self.user_id
        .. "&delivered_at=lte.now()"
        .. "&select=id,sender_id,ink_url,created_at,delivered_at"
        .. ",users!postcrossing_pool_sender_id_fkey(username)"
        .. "&order=delivered_at.desc"
        .. "&limit=20")

    if not err and type(data) == "table" then
        for _, item in ipairs(data) do
            if type(item.users) == "table" then
                item.sender_username = item.users.username
                item.users = nil
            end
        end
    end
    callback(err, data)
end

return Api
