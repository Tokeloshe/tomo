-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/seasons.lua
-- Japan's 24-term solar calendar (二十四節気, Nijūshi Sekki).
-- Tomo™ is seasonally conscious. This module provides the current sekki
-- and the four broad season names used for colour tinting.
-- No network required. Computation from the device clock only.

local Seasons = {}

-- The 24 sekki in calendar order.
-- Each entry: { kanji, romaji, english_name, start_month, start_day, season }
-- "season" maps to the four broad seasons used by theme.lua for colour tints.
-- Dates are approximate -- sekki are solar terms and shift by a day each year,
-- but the fixed calendar dates here are accurate within ±1 day, sufficient
-- for a background aesthetic feature.
local SEKKI = {
    {  1, "立春", "Risshun",    "Spring begins",       2,  4, "spring" },
    {  2, "雨水", "Usui",       "Rain water",          2, 19, "spring" },
    {  3, "啓蟄", "Keichitsu",  "Insects awaken",      3,  5, "spring" },
    {  4, "春分", "Shunbun",    "Vernal equinox",      3, 20, "spring" },
    {  5, "清明", "Seimei",     "Pure brightness",     4,  5, "spring" },
    {  6, "穀雨", "Kokuu",      "Grain rain",          4, 20, "spring" },
    {  7, "立夏", "Rikka",      "Summer begins",       5,  5, "summer" },
    {  8, "小満", "Shouman",    "Grain ripens",        5, 21, "summer" },
    {  9, "芒種", "Boushu",     "Seeds are sown",      6,  6, "summer" },
    { 10, "夏至", "Geshi",      "Summer solstice",     6, 21, "summer" },
    { 11, "小暑", "Shousho",    "Small heat",          7,  7, "summer" },
    { 12, "大暑", "Taisho",     "Great heat",          7, 22, "summer" },
    { 13, "立秋", "Risshuu",    "Autumn begins",       8,  7, "autumn" },
    { 14, "処暑", "Shosho",     "Heat recedes",        8, 23, "autumn" },
    { 15, "白露", "Hakuro",     "White dew",           9,  7, "autumn" },
    { 16, "秋分", "Shuubun",    "Autumnal equinox",    9, 23, "autumn" },
    { 17, "寒露", "Kanro",      "Cold dew",           10,  8, "autumn" },
    { 18, "霜降", "Soukou",     "Frost descends",     10, 23, "autumn" },
    { 19, "立冬", "Rittou",     "Winter begins",      11,  7, "winter" },
    { 20, "小雪", "Shousetsu",  "Small snow",         11, 22, "winter" },
    { 21, "大雪", "Taisetsu",   "Great snow",         12,  7, "winter" },
    { 22, "冬至", "Touji",      "Winter solstice",    12, 22, "winter" },
    { 23, "小寒", "Shoukan",    "Small cold",          1,  5, "winter" },
    { 24, "大寒", "Daikan",     "Great cold",          1, 20, "winter" },
}

-- Field indices in SEKKI rows (named constants, not magic numbers).
local F_IDX     = 1
local F_KANJI   = 2
local F_ROMAJI  = 3
local F_ENGLISH = 4
local F_MONTH   = 5
local F_DAY     = 6
local F_SEASON  = 7

-- Convert a sekki row into the table format returned to callers.
local function sekkiToTable(row)
    return {
        index   = row[F_IDX],
        kanji   = row[F_KANJI],
        romaji  = row[F_ROMAJI],
        english = row[F_ENGLISH],
        month   = row[F_MONTH],
        day     = row[F_DAY],
        season  = row[F_SEASON],
    }
end

-- Return the current sekki based on the device clock.
-- The algorithm walks the sekki list and finds the most recent one that has
-- already started. Because sekki #23 (小寒, January 5) and #24 (大寒, January 20)
-- are in January but the year rolls over in Rittou (#19, November 7), the
-- comparison is done by converting each date to a day-of-year and comparing.
--
-- Returns a table:
--   index   (integer) 1-24
--   kanji   (string)  Japanese characters
--   romaji  (string)  Romanisation
--   english (string)  English meaning
--   month   (integer) Calendar month the sekki starts
--   day     (integer) Calendar day the sekki starts
--   season  (string)  "spring" | "summer" | "autumn" | "winter"
function Seasons.current()
    local now  = os.date("*t")
    local m    = now.month
    local d    = now.day

    -- Find the most recently started sekki by scanning all 24 and keeping the
    -- one with the largest (month,day) code that is still <= today.
    -- The SEKKI array is ordered by solar calendar (Feb→Jan) but the month codes
    -- wrap around, so a simple forward scan finding the max works correctly.
    local today_code = m * 100 + d

    local best      = nil
    local best_code = -1

    for i = 1, #SEKKI do
        local row = SEKKI[i]
        local sekki_code = row[F_MONTH] * 100 + row[F_DAY]
        if sekki_code <= today_code and sekki_code > best_code then
            best      = row
            best_code = sekki_code
        end
    end

    if best then
        return sekkiToTable(best)
    end

    -- Wrap-around: today is before every sekki start date in the calendar
    -- (Jan 1 -- 4, before 小寒 on Jan 5). The active sekki is the last one
    -- from the previous year with a month > current month.
    for i = #SEKKI, 1, -1 do
        local row = SEKKI[i]
        if row[F_MONTH] > m then
            return sekkiToTable(row)
        end
    end

    -- Absolute fallback (should never be reached).
    return sekkiToTable(SEKKI[22])  -- 冬至 (Winter solstice, Dec 22)
end

-- Return the display line shown on the home screen, e.g. "白露 · White dew".
-- This is the only place the seasonal greeting is rendered as a combined string.
function Seasons.greeting()
    local s = Seasons.current()
    return s.kanji .. " · " .. s.english
end

-- Return the broad season name ("spring", "summer", "autumn", "winter")
-- for the current date. Used by theme.lua to select the page tint.
function Seasons.broadSeason()
    return Seasons.current().season
end

-- Return the label string used to stamp pen pal bonds when they are formed.
-- Format: "Matched during 白露 / White dew" -- stored in penpal_bonds.season_met.
-- The stored value is the romaji name only (compact, ASCII-safe for the DB).
function Seasons.bondLabel()
    local s = Seasons.current()
    return s.kanji .. " / " .. s.english
end

-- Return a sekki by its romaji name (case-insensitive).
-- Used by tests and by the pen pal bond display which may restore a stored name.
-- Returns nil if the name is not recognised.
function Seasons.byRomaji(name)
    if not name then return nil end
    local lower = name:lower()
    for _, row in ipairs(SEKKI) do
        if row[F_ROMAJI]:lower() == lower then
            return sekkiToTable(row)
        end
    end
    return nil
end

-- Return all 24 sekki as an ordered array of tables.
function Seasons.all()
    local result = {}
    for _, row in ipairs(SEKKI) do
        result[#result + 1] = sekkiToTable(row)
    end
    return result
end

-- Return context for the sekki popup: previous, current, and next sekki.
-- Each is a table with index, kanji, romaji, english, month, day, season.
function Seasons.getContext()
    local current = Seasons.current()
    local idx = current.index
    local all = Seasons.all()
    local prev_idx = idx == 1 and 24 or (idx - 1)
    local next_idx = idx == 24 and 1 or (idx + 1)
    return {
        prev    = all[prev_idx],
        current = current,
        next    = all[next_idx],
    }
end

return Seasons
