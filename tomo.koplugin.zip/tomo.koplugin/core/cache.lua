-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/cache.lua
-- Manages tomo_cache.db -- Tomo™'s only local write database.
-- This is not a replica of the server. It is a staging area:
--   outbox    → messages waiting to be sent (FIFO queue)
--   msg_cache → recent messages per room (LRU, max 100 per room)
--   user_state → JWT, user_id, username, and other session scalars
--
-- KoboReader.sqlite is NEVER touched here. That database is read-only.
-- This module is the sole writer to tomo_cache.db.
--
-- SQLite access uses lua-ljsqlite3 (KOReader's bundled binding).

local Cache = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Schema migrations
-- Each entry is a SQL block to execute when upgrading from version (i-1) to i.
-- Migrations are idempotent: safe to run twice (IF NOT EXISTS guards throughout).
-- The schema_version table tracks which migrations have been applied.
-- ─────────────────────────────────────────────────────────────────────────────

local MIGRATIONS = {}

MIGRATIONS[1] = [[
    CREATE TABLE IF NOT EXISTS schema_version (
        version INTEGER NOT NULL
    );
    INSERT INTO schema_version (version) SELECT 0
        WHERE NOT EXISTS (SELECT 1 FROM schema_version);

    CREATE TABLE IF NOT EXISTS outbox (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        room_id     TEXT NOT NULL,
        kind        TEXT NOT NULL DEFAULT 'text',
        body        TEXT,
        ink_path    TEXT,
        device_ts   TEXT NOT NULL,
        retry_count INTEGER DEFAULT 0,
        status      TEXT NOT NULL DEFAULT 'pending',
        created_at  TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS msg_cache (
        id          TEXT PRIMARY KEY,
        room_id     TEXT NOT NULL,
        user_id     TEXT,
        username    TEXT,
        kind        TEXT NOT NULL DEFAULT 'text',
        body        TEXT,
        ink_url     TEXT,
        created_at  TEXT NOT NULL,
        delivers_at TEXT,
        cached_at   TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_msg_cache_room
        ON msg_cache(room_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS user_state (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
]]

-- Escape a string for safe inclusion in SQL literals.
local function sqlEscape(s)
    if not s then return "NULL" end
    return "'" .. tostring(s):gsub("'", "''") .. "'"
end

-- Sanitize a value for SQLite bind parameters.
-- rapidjson decodes JSON null as rapidjson.null (userdata), which LJSQLite3
-- cannot bind. Convert any non-string/number/nil value to nil (SQL NULL).
local function sqlBind(v)
    local t = type(v)
    if t == "string" or t == "number" or t == "nil" then return v end
    if t == "boolean" then return v and 1 or 0 end
    return nil
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

-- Open tomo_cache.db and run any pending migrations.
-- Returns true on success, false + error string on failure.
-- The caller (tomo.lua) holds the Cache instance for the session lifetime.
function Cache:open()
    local ok_sq3, SQ3 = pcall(require, "lua-ljsqlite3/init")
    if not ok_sq3 then
        return false, "lua-ljsqlite3 not available"
    end

    local ok_ds, DataStorage = pcall(require, "datastorage")
    if not ok_ds then
        return false, "datastorage not available"
    end

    local path = DataStorage:getSettingsDir() .. "/tomo_cache.sqlite3"
    local ok_open, conn = pcall(SQ3.open, path)
    if not ok_open or not conn then
        return false, "Cannot open tomo_cache.db: " .. tostring(conn)
    end

    self.conn = conn

    -- WAL mode gives better concurrent read/write without blocking.
    self.conn:exec("PRAGMA journal_mode=WAL;")
    -- 3-second timeout before returning SQLITE_BUSY.
    self.conn:set_busy_timeout(3000)

    local ok_mig, err = self:migrate()
    if not ok_mig then
        self.conn:close()
        self.conn = nil
        return false, err
    end

    return true
end

function Cache:close()
    if self.conn then
        self.conn:close()
        self.conn = nil
    end
end

-- Apply any migrations with index > current schema_version.
function Cache:migrate()
    -- Determine current schema version. pcall because schema_version
    -- may not exist yet on the very first run.
    local current_version = 0
    local ok, version = pcall(self.conn.rowexec, self.conn,
        "SELECT version FROM schema_version LIMIT 1")
    if ok and version then
        current_version = tonumber(version) or 0
    end

    -- Apply each pending migration in sequence.
    for v = current_version + 1, #MIGRATIONS do
        local ok_exec, err = pcall(self.conn.exec, self.conn, MIGRATIONS[v])
        if not ok_exec then
            return false, string.format("Migration %d failed: %s", v, tostring(err))
        end
        self.conn:exec(string.format(
            "UPDATE schema_version SET version = %d", v
        ))
    end

    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- user_state: key-value store for JWT, user_id, username, etc.
-- ─────────────────────────────────────────────────────────────────────────────

function Cache:setState(key, value)
    if not self.conn then return end
    local stmt = self.conn:prepare(
        "INSERT OR REPLACE INTO user_state (key, value) VALUES (?, ?)"
    )
    stmt:bind(key, tostring(value))
    stmt:step()
    stmt:clearbind():reset()
    stmt:close()
end

function Cache:getState(key)
    if not self.conn then return nil end
    local ok, val = pcall(self.conn.rowexec, self.conn,
        "SELECT value FROM user_state WHERE key = " .. sqlEscape(key) .. " LIMIT 1")
    if ok and val then return val end
    return nil
end

function Cache:deleteState(key)
    if not self.conn then return end
    self.conn:exec(
        "DELETE FROM user_state WHERE key = " .. sqlEscape(key)
    )
end

-- ─────────────────────────────────────────────────────────────────────────────
-- outbox: FIFO queue of unsent messages
-- ─────────────────────────────────────────────────────────────────────────────

-- Add a message to the outbox. Returns the new row id, or nil on error.
-- `kind` is "text" or "ink". `ink_path` is a local filesystem path (for ink
-- messages only); it is uploaded to Supabase Storage on flush.
function Cache:enqueue(room_id, kind, body, ink_path, device_ts)
    if not self.conn then return nil end
    if not room_id or room_id == "" then
        local ok_log, lg = pcall(require, "logger")
        if ok_log then lg.warn("Tomo Cache: enqueue skipped, room_id is nil") end
        return nil
    end
    local stmt = self.conn:prepare([[
        INSERT INTO outbox (room_id, kind, body, ink_path, device_ts)
        VALUES (?, ?, ?, ?, ?)
    ]])
    stmt:bind(room_id, kind or "text", body, ink_path, device_ts)
    stmt:step()
    stmt:clearbind():reset()
    stmt:close()
    return tonumber(self.conn:rowexec("SELECT last_insert_rowid()"))
end

-- Return up to `limit` pending outbox messages in FIFO order.
-- This is a read; it does not dequeue anything.
function Cache:peekOutbox(limit)
    if not self.conn then return {} end
    local results = self.conn:exec(string.format([[
        SELECT id, room_id, kind, body, ink_path, device_ts, retry_count
        FROM outbox
        WHERE status = 'pending'
        ORDER BY id ASC
        LIMIT %d
    ]], limit or 10))
    if not results then return {} end

    local items = {}
    for i = 1, #results.id do
        items[#items + 1] = {
            id          = tonumber(results.id[i]),
            room_id     = results.room_id[i],
            kind        = results.kind[i],
            body        = results.body[i],
            ink_path    = results.ink_path[i],
            device_ts   = results.device_ts[i],
            retry_count = tonumber(results.retry_count[i]) or 0,
        }
    end
    return items
end

-- Remove a successfully sent message from the outbox.
function Cache:markSent(outbox_id)
    if not self.conn then return end
    self.conn:exec(string.format(
        "DELETE FROM outbox WHERE id = %d", outbox_id
    ))
end

-- Increment retry_count for a failed send attempt.
function Cache:markRetry(outbox_id)
    if not self.conn then return end
    self.conn:exec(string.format(
        "UPDATE outbox SET retry_count = retry_count + 1 WHERE id = %d",
        outbox_id
    ))
end

-- Mark a message as permanently failed (shown to user with "try again/let it go").
function Cache:markFailed(outbox_id)
    if not self.conn then return end
    self.conn:exec(string.format(
        "UPDATE outbox SET status = 'failed' WHERE id = %d", outbox_id
    ))
end

-- Mark outbox entries as failed if they are older than max_age_hours.
-- Called on app open to surface stale unsent messages.
function Cache:expireStaleOutbox(max_age_hours)
    if not self.conn then return end
    self.conn:exec(string.format([[
        UPDATE outbox SET status = 'failed'
        WHERE status = 'pending'
          AND created_at < datetime('now', '-%d hours')
    ]], max_age_hours or 24))
end

-- Return all failed outbox entries so the UI can show "some messages couldn't send."
function Cache:getFailedMessages()
    if not self.conn then return {} end
    local results = self.conn:exec([[
        SELECT id, room_id, kind, body, device_ts
        FROM outbox
        WHERE status = 'failed'
        ORDER BY id ASC
    ]])
    if not results then return {} end

    local items = {}
    for i = 1, #results.id do
        items[#items + 1] = {
            id        = tonumber(results.id[i]),
            room_id   = results.room_id[i],
            kind      = results.kind[i],
            body      = results.body[i],
            device_ts = results.device_ts[i],
        }
    end
    return items
end

-- Re-queue a failed message so the next flush attempt picks it up again.
function Cache:retryFailed(outbox_id)
    if not self.conn then return end
    self.conn:exec(string.format([[
        UPDATE outbox SET status = 'pending', retry_count = 0
        WHERE id = %d
    ]], outbox_id))
end

-- Permanently remove a failed message. The user chose "let it go."
function Cache:discardFailed(outbox_id)
    if not self.conn then return end
    self.conn:exec(string.format(
        "DELETE FROM outbox WHERE id = %d", outbox_id
    ))
end

-- ─────────────────────────────────────────────────────────────────────────────
-- msg_cache: LRU cache of received messages per room (max 100 per room)
-- ─────────────────────────────────────────────────────────────────────────────

-- Store a batch of messages from the server. Enforces the 100-per-room LRU
-- cap after insertion by deleting the oldest rows beyond the limit.
-- `messages` is an array of message tables from api.lua.
function Cache:storeMessages(room_id, messages)
    if not self.conn or not messages or #messages == 0 then return end

    local stmt = self.conn:prepare([[
        INSERT OR REPLACE INTO msg_cache
            (id, room_id, user_id, username, kind, body, ink_url, created_at, delivers_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]])

    for _, msg in ipairs(messages) do
        stmt:bind(
            sqlBind(msg.id),
            sqlBind(msg.room_id) or room_id,
            sqlBind(msg.user_id),
            sqlBind(msg.username),
            sqlBind(msg.kind) or "text",
            sqlBind(msg.body),
            sqlBind(msg.ink_url),
            sqlBind(msg.created_at),
            sqlBind(msg.delivers_at)
        )
        stmt:step()
        stmt:clearbind():reset()
    end
    stmt:close()

    -- Enforce LRU cap: keep only the 100 most recent per room.
    local escaped = sqlEscape(room_id)
    self.conn:exec(string.format([[
        DELETE FROM msg_cache
        WHERE room_id = %s
          AND id NOT IN (
            SELECT id FROM msg_cache
            WHERE room_id = %s
            ORDER BY created_at DESC
            LIMIT 100
          )
    ]], escaped, escaped))
end

-- Return cached messages for a room, newest first, up to `limit`.
-- `before_ts` is an optional ISO 8601 timestamp for pagination (load older).
-- Only returns messages where delivers_at IS NULL OR delivers_at <= now(),
-- so delayed pen pal letters are not shown before their delivery time.
function Cache:getMessages(room_id, limit, before_ts)
    if not self.conn then return {} end

    local sql = string.format([[
        SELECT id, room_id, user_id, username, kind, body, ink_url,
               created_at, delivers_at
        FROM msg_cache
        WHERE room_id = %s
          AND (delivers_at IS NULL OR delivers_at <= datetime('now'))
    ]], sqlEscape(room_id))

    if before_ts then
        sql = sql .. " AND created_at < " .. sqlEscape(before_ts)
    end
    sql = sql .. " ORDER BY created_at DESC LIMIT " .. tostring(limit or 20)

    local results = self.conn:exec(sql)
    if not results then return {} end

    local msgs = {}
    for i = 1, #results.id do
        msgs[#msgs + 1] = {
            id          = results.id[i],
            room_id     = results.room_id[i],
            user_id     = results.user_id[i],
            username    = results.username[i],
            kind        = results.kind[i],
            body        = results.body[i],
            ink_url     = results.ink_url[i],
            created_at  = results.created_at[i],
            delivers_at = results.delivers_at[i],
        }
    end
    return msgs
end

-- Return the created_at timestamp of the newest cached message in a room.
-- Used by sync.lua to fetch only messages newer than the cache.
function Cache:newestMessageTime(room_id)
    if not self.conn then return nil end
    local ok, ts = pcall(self.conn.rowexec, self.conn, string.format(
        "SELECT created_at FROM msg_cache WHERE room_id = %s ORDER BY created_at DESC LIMIT 1",
        sqlEscape(room_id)
    ))
    if ok and ts then return ts end
    return nil
end

-- Update the username for all cached messages from a given user_id.
-- Called when the user changes their display name so old messages show the new name.
function Cache:updateCachedUsername(user_id, new_username)
    if not self.conn or not user_id or not new_username then return end
    local ok, err = pcall(self.conn.exec, self.conn, string.format(
        "UPDATE msg_cache SET username = %s WHERE user_id = %s",
        sqlEscape(new_username), sqlEscape(user_id)
    ))
    if not ok then
        local ok_log, lg = pcall(require, "logger")
        if ok_log then lg.warn("Tomo Cache: updateCachedUsername failed: " .. tostring(err)) end
    end
end

-- Remove all cached messages for a room. Called on room leave if the cache
-- grows stale (e.g. after a long offline period on a device with low storage).
function Cache:clearRoomCache(room_id)
    if not self.conn then return end
    self.conn:exec(
        "DELETE FROM msg_cache WHERE room_id = " .. sqlEscape(room_id)
    )
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Factory: return a new Cache instance.
-- Caller must call :open() before using any other method.
-- ─────────────────────────────────────────────────────────────────────────────

function Cache.new()
    return setmetatable({}, { __index = Cache })
end

return Cache
