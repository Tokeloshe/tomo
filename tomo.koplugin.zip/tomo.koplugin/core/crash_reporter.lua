-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/crash_reporter.lua
-- Captures genuine Tomo Lua crashes from KOReader's crash.log.
--
-- BUG FIXES (v2.7.0):
-- 1. Pending files now force-deleted after successful upload (os.rename can fail silently)
-- 2. Content-hash dedup prevents re-uploading identical crashes
-- 3. Max 5 uploads per flush, excess files deleted
-- 4. Crash parser requires real Lua error patterns, not just "tomo" in text
-- 5. savePending() rejects stack traces that do not mention "tomo" (Kindle spam fix)
-- 6. uploadReport() enforces a 24-hour minimum gap between uploads of the
--    same crash_hash to prevent identical-content-upload loops seen on Kindle
-- 7. parseCrashTimestamp() treats pre-2026 dates as spurious (stray system log dates)

local CrashReporter = {}

local logger = require("logger")

-- djb2 hash for deduplication
local function djb2(str)
    if not str or #str == 0 then return "00000000" end
    local hash = 5381
    for i = 1, #str do
        hash = ((hash * 33) + str:byte(i)) % 0xFFFFFFFF
    end
    return string.format("%08x", hash)
end

-- Get or create persistent install data from LuaSettings.
local function getInstallData()
    local ok_ls, LuaSettings = pcall(require, "luasettings")
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if not (ok_ls and ok_ds) then return {} end

    local settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
    local data = {}

    data.install_id = settings:readSetting("install_id")
    if not data.install_id then
        math.randomseed(os.time() + (os.clock() * 1000))
        local t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"
        data.install_id = t:gsub("[xy]", function(c)
            local v = c == "x" and math.random(0, 15) or math.random(8, 11)
            return string.format("%x", v)
        end)
        settings:saveSetting("install_id", data.install_id)
    end

    data.first_installed_at = settings:readSetting("first_installed_at")
    if not data.first_installed_at then
        data.first_installed_at = os.time()
        settings:saveSetting("first_installed_at", data.first_installed_at)
    end
    data.days_since_install = math.floor((os.time() - data.first_installed_at) / 86400)

    data.session_count = (settings:readSetting("session_count") or 0) + 1
    settings:saveSetting("session_count", data.session_count)

    data.total_crashes = settings:readSetting("total_crashes") or 0
    data.previous_crash_hash = settings:readSetting("last_crash_hash")
    data.last_crashlog_hash = settings:readSetting("last_crashlog_hash")

    -- Uploaded crash hashes for dedup (table of hash -> true)
    data.uploaded_hashes = settings:readSetting("uploaded_crash_hashes") or {}

    settings:flush()
    data._settings = settings
    return data
end

-- Read firmware version from device files (not crash.log which may not have it).
local function readFirmwareVersion()
    -- Kobo: second field in version file
    local ok, f = pcall(io.open, "/mnt/onboard/.kobo/version", "r")
    if ok and f then
        local line = f:read("*l"); f:close()
        if line then
            local fw = line:match(",([^,]+),")
            if fw then return fw end
        end
    end
    -- Kindle: /etc/prettyversion.txt or /etc/version.txt
    for _, path in ipairs({"/etc/prettyversion.txt", "/etc/version.txt"}) do
        local kf = io.open(path, "r")
        if kf then
            local v = kf:read("*l"); kf:close()
            if v and #v > 0 then return v end
        end
    end
    return ""
end

-- Read kernel version via uname -r.
local function readKernelVersion()
    local ok, handle = pcall(io.popen, "uname -r 2>/dev/null")
    if ok and handle then
        local v = handle:read("*l"); handle:close()
        if v and #v > 0 then return v end
    end
    return ""
end

-- Parse crash.log timestamp format MM/DD/YY-HH:MM:SS to ISO.
-- If the parsed year is before 2026 (Tomo's earliest plausible crash),
-- the match is treated as spurious (stray date from unrelated system logs)
-- and we fall back to file mtime or the current time.
local function parseCrashTimestamp(content)
    -- Try MM/DD/YY-HH:MM:SS format (KOReader crash.log)
    local m, d, y, h, mi, s = content:match("(%d%d)/(%d%d)/(%d%d)%-(%d%d):(%d%d):(%d%d)")
    if m then
        local year = 2000 + tonumber(y)
        if year >= 2026 then
            return string.format("%04d-%02d-%02dT%02d:%02d:%02dZ",
                year, tonumber(m), tonumber(d), tonumber(h), tonumber(mi), tonumber(s))
        end
        -- else: stale date from unrelated system logs, ignore and fall through.
    end
    -- Try YYYY-MM-DD HH:MM:SS format
    local ts_year, ts_rest = content:match("(%d%d%d%d)(%-%d%d%-%d%d %d%d:%d%d:%d%d)")
    if ts_year and tonumber(ts_year) >= 2026 then
        return ts_year .. ts_rest:gsub(" ", "T") .. "Z"
    end
    -- Fall back to file mtime
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if ok_ds then
        local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
        if ok_lfs then
            local path = DataStorage:getDataDir() .. "/crash.log"
            local attr = lfs.attributes(path)
            if attr and attr.modification then
                return os.date("!%Y-%m-%dT%H:%M:%SZ", attr.modification)
            end
        end
    end
    return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

-- Lua error patterns that indicate a real crash (not system logs or info messages)
local ERROR_PATTERNS = {
    "bad argument #%d",
    "attempt to index a nil value",
    "attempt to call a nil value",
    "attempt to perform arithmetic",
    "attempt to compare",
    "attempt to concatenate",
    "stack traceback:",
    "PANIC:",
    "%.lua:%d+:",          -- file.lua:123: error format
}

-- Check if text contains a real Lua error pattern
local function hasErrorPattern(text)
    for _, pat in ipairs(ERROR_PATTERNS) do
        if text:find(pat) then return true end
    end
    return false
end

-- Parse KOReader's crash.log for genuine Tomo Lua crashes.
-- Returns crash data table or nil.
-- Requirements for a valid crash:
--   1. crash.log content must have changed since last check (dedup by content hash)
--   2. Must contain a real Lua error pattern (not just system logs)
--   3. Must contain "stack traceback:" with tomo.koplugin in the traceback lines
function CrashReporter.checkForCrash()
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if not ok_ds then return nil end

    local crash_path = DataStorage:getDataDir() .. "/crash.log"
    local f = io.open(crash_path, "r")
    if not f then return nil end
    local content = f:read("*a")
    f:close()

    if not content or #content < 10 then return nil end

    -- Skip if we already processed this exact crash.log content
    local content_hash = djb2(content)
    local install_data = getInstallData()
    if install_data.last_crashlog_hash == content_hash then
        return nil
    end

    -- Must contain at least one real error pattern
    if not hasErrorPattern(content) then
        logger.warn("Tomo Crash: crash.log found but no error pattern detected, skipping")
        -- Mark as processed so we don't re-check every launch
        if install_data._settings then
            install_data._settings:saveSetting("last_crashlog_hash", content_hash)
            install_data._settings:flush()
        end
        return nil
    end

    -- Must contain "stack traceback:" to extract a meaningful trace
    local traceback_start = content:find("stack traceback:")
    if not traceback_start then
        logger.warn("Tomo Crash: error found but no stack traceback, skipping")
        if install_data._settings then
            install_data._settings:saveSetting("last_crashlog_hash", content_hash)
            install_data._settings:flush()
        end
        return nil
    end

    -- Extract the error line (line before "stack traceback:")
    local before_traceback = content:sub(math.max(1, traceback_start - 500), traceback_start - 1)
    local error_line = ""
    for line in before_traceback:gmatch("[^\n]+") do
        if line:match(":%d+:") or line:match("luajit:") or line:match("bad argument") then
            error_line = line
        end
    end

    -- Extract the traceback block (up to next blank line or 2000 chars)
    local traceback_block = content:sub(traceback_start, math.min(#content, traceback_start + 2000))
    local block_end = traceback_block:find("\n\n")
    if block_end then traceback_block = traceback_block:sub(1, block_end) end

    -- Must have tomo.koplugin in at least one traceback line
    local is_tomo_crash = false
    for line in traceback_block:gmatch("[^\n]+") do
        if line:find("tomo%.koplugin") or line:find("tomo/") then
            is_tomo_crash = true
            break
        end
    end

    if not is_tomo_crash then
        logger.warn("Tomo Crash: stack trace found but not Tomo-related, skipping")
        if install_data._settings then
            install_data._settings:saveSetting("last_crashlog_hash", content_hash)
            install_data._settings:flush()
        end
        return nil
    end

    -- Build the stack trace string
    local stack = error_line .. "\n" .. traceback_block
    local crash_hash = djb2(stack)

    -- Record that we processed this crash.log
    if install_data._settings then
        install_data._settings:saveSetting("last_crashlog_hash", content_hash)
        install_data._settings:saveSetting("last_crash_hash", crash_hash)
        install_data._settings:saveSetting("total_crashes",
            (install_data.total_crashes or 0) + 1)
        install_data._settings:flush()
    end

    -- Extract metadata: prefer device files over crash.log header
    local koreader_ver = content:match("Version: ([^\n]+)") or ""
    local fw_ver = readFirmwareVersion()
    local kernel_ver = readKernelVersion()
    local crash_time = parseCrashTimestamp(content)

    return {
        stack_trace = stack:sub(1, 3000),
        koreader_version = koreader_ver:sub(1, 50),
        firmware_version = fw_ver:sub(1, 50),
        kernel_version = kernel_ver:sub(1, 50),
        crashed_at = crash_time,
        crash_hash = crash_hash,
        install_data = install_data,
    }
end

-- Build a full crash report with all detail and grouping fields.
function CrashReporter.buildReport(crash_data, device_profile, tomo_version, user_id, tomo_state)
    local Recorder = require("core/recorder")
    local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
    local wifi_connected = ok_nm and NetworkMgr:isConnected() or false
    local install = crash_data.install_data or {}

    local auth_state = "failed"
    if user_id then auth_state = "authenticated"
    elseif tomo_state and tomo_state._api then auth_state = "anon" end

    local outbox_pending = 0
    local rooms_loaded = 0
    if tomo_state then
        if tomo_state._cache then
            local ok_peek, pending = pcall(tomo_state._cache.peekOutbox, tomo_state._cache, 100)
            outbox_pending = ok_peek and pending and #pending or 0
        end
        if tomo_state.state and tomo_state.state.rooms then
            rooms_loaded = #tomo_state.state.rooms
        end
    end

    local current_room_id = tomo_state and tomo_state.state and tomo_state.state.active_room
    local book_title, book_author
    if tomo_state and tomo_state.state and tomo_state.state.current_book then
        book_title = tomo_state.state.current_book.title
        book_author = tomo_state.state.current_book.author
    end

    local device_hash = ""
    local ok_auth, Auth = pcall(require, "core/auth")
    if ok_auth then device_hash = Auth.deviceHash() or "" end

    -- Read current book from KOReader document API (pcall-wrapped)
    if not book_title or book_title == "" then
        pcall(function()
            local ReaderUI = require("apps/reader/readerui")
            local instance = ReaderUI.instance
            if instance and instance.document then
                local props = instance.document:getProps()
                book_title = props.title or ""
                book_author = props.authors or ""
            end
        end)
    end

    -- Firmware and kernel from device (not crash.log)
    local fw = crash_data.firmware_version
    if not fw or fw == "" then fw = readFirmwareVersion() end
    local kv = crash_data.kernel_version
    if not kv or kv == "" then kv = readKernelVersion() end

    -- Session duration
    local session_start = Recorder.getSessionStart()
    local duration = 0
    if session_start then
        local ok_t, t = pcall(function()
            local y,mo,d,h,mi,s = session_start:match("(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)")
            if y then
                return os.time{year=tonumber(y),month=tonumber(mo),day=tonumber(d),
                    hour=tonumber(h),min=tonumber(mi),sec=tonumber(s)}
            end
        end)
        if ok_t and t then duration = os.time() - t end
    end

    return {
        tomo_version = tomo_version or "unknown",
        device_model = device_profile and device_profile.model_code or "unknown",
        device_tier = device_profile and device_profile.tier or 0,
        screen_w = device_profile and device_profile.screen_w or 0,
        screen_h = device_profile and device_profile.screen_h or 0,
        koreader_version = crash_data.koreader_version or "",
        firmware_version = fw or "",
        kernel_version = kv or "",
        user_id = user_id,
        network_state = wifi_connected and "online" or "offline",
        stack_trace = crash_data.stack_trace,
        last_actions = Recorder.getLastActions(20),
        crashed_at = crash_data.crashed_at,
        current_screen = Recorder.getCurrentScreen(),
        current_room_id = current_room_id,
        auth_state = auth_state,
        lua_memory_kb = math.floor(collectgarbage("count") or 0),
        session_count = install.session_count or 0,
        book_title = book_title,
        book_author = book_author,
        outbox_pending = outbox_pending,
        rooms_loaded = rooms_loaded,
        crash_hash = crash_data.crash_hash,
        previous_crash_hash = install.previous_crash_hash,
        wifi_state_at_crash = wifi_connected and "connected" or "disconnected",
        device_hash = device_hash,
        session_id = Recorder.getSessionId(),
        install_id = install.install_id,
        total_crashes = (install.total_crashes or 0) + 1,
        days_since_install = install.days_since_install or 0,
        session_duration_s = duration,
        ota_checked = false,
    }
end

-- Save a crash report as JSON to the pending directory.
-- FINAL GATE: reject any report whose stack_trace does not mention "tomo"
-- (case-insensitive). This prevents Kindle-style spam where unrelated system
-- logs somehow reach this function.
function CrashReporter.savePending(report)
    if not report or type(report) ~= "table" then
        logger.warn("Tomo Crash: savePending rejected nil/non-table report")
        return nil
    end
    local trace = report.stack_trace or ""
    if type(trace) ~= "string" or not trace:lower():find("tomo") then
        logger.warn("Tomo Crash: savePending rejected non-Tomo report (no 'tomo' in stack_trace)")
        return nil
    end

    local Recorder = require("core/recorder")
    local dir = Recorder.getLogDir() .. "/crashes/pending"
    local ts = os.date("%Y-%m-%d_%H-%M-%S")
    local path = dir .. "/" .. ts .. ".json"

    local ok_json, rapidjson = pcall(require, "rapidjson")
    if not ok_json then
        logger.warn("Tomo Crash: cannot save, rapidjson not available")
        return nil
    end

    local f = io.open(path, "w")
    if not f then
        logger.warn("Tomo Crash: cannot write to " .. path)
        return nil
    end
    f:write(rapidjson.encode(report))
    f:close()
    logger.warn("Tomo Crash: saved pending report (hash=" .. tostring(report.crash_hash) .. ")")
    return path
end

-- Upload a single crash report JSON file to Supabase.
-- On success, DELETES the pending file (os.rename to uploaded/ can fail silently).
function CrashReporter.uploadReport(api, json_path)
    local ok_json, rapidjson = pcall(require, "rapidjson")
    if not ok_json then return false end

    local f = io.open(json_path, "r")
    if not f then return false end
    local content = f:read("*a")
    f:close()

    local ok_dec, report = pcall(rapidjson.decode, content)
    if not ok_dec or type(report) ~= "table" then
        -- Corrupt JSON file, delete it
        os.remove(json_path)
        logger.warn("Tomo Crash: deleted corrupt pending file: " .. json_path)
        return false
    end

    -- Dedup: check if this crash_hash was already uploaded, and enforce a
    -- 24-hour minimum gap between uploads of the same hash. This stops the
    -- pathological case seen on Kindle where an identical report is uploaded
    -- repeatedly across sessions.
    local ok_ls, LuaSettings = pcall(require, "luasettings")
    local ok_ds, DataStorage = pcall(require, "datastorage")
    local hash = report.crash_hash or djb2(content)
    local now_ts = os.time()
    if ok_ls and ok_ds then
        local settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
        local uploaded_hashes = settings:readSetting("uploaded_crash_hashes") or {}
        local uploaded_ts = settings:readSetting("uploaded_crash_timestamps") or {}
        if uploaded_hashes[hash] then
            logger.warn("Tomo Crash: duplicate hash " .. hash .. ", deleting without upload")
            os.remove(json_path)
            return true  -- Count as handled
        end
        local last_ts = uploaded_ts[hash]
        if last_ts and (now_ts - last_ts) < 86400 then
            logger.warn("Tomo Crash: hash " .. hash
                .. " uploaded < 24h ago, deleting without upload")
            os.remove(json_path)
            return true
        end
    end

    local err = api:_request("POST", "/rest/v1/crash_reports", report,
        { ["Prefer"] = "return=minimal" })

    if not err then
        logger.warn("Tomo Crash: uploaded successfully, deleting pending file")
        -- Record the hash + timestamp so we never re-upload within 24h.
        if ok_ls and ok_ds then
            local settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
            local uploaded_hashes = settings:readSetting("uploaded_crash_hashes") or {}
            local uploaded_ts = settings:readSetting("uploaded_crash_timestamps") or {}
            uploaded_hashes[hash] = true
            uploaded_ts[hash] = now_ts
            -- Keep hash tables from growing unbounded (max 50 entries each).
            local count = 0
            for _ in pairs(uploaded_hashes) do count = count + 1 end
            if count > 50 then
                uploaded_hashes = {}
                uploaded_ts = {}
                uploaded_hashes[hash] = true
                uploaded_ts[hash] = now_ts
            end
            settings:saveSetting("uploaded_crash_hashes", uploaded_hashes)
            settings:saveSetting("uploaded_crash_timestamps", uploaded_ts)
            settings:flush()
        end
        -- Delete the pending file. Use os.remove, not os.rename (rename can fail silently).
        os.remove(json_path)
        return true
    else
        logger.warn("Tomo Crash: upload failed: " .. tostring(err))
        return false
    end
end

-- Upload pending crash reports. Max 5 per flush, excess deleted.
function CrashReporter.flushPending(api)
    local Recorder = require("core/recorder")
    local dir = Recorder.getLogDir() .. "/crashes/pending"
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs then return end

    -- Collect all pending files
    local files = {}
    for entry in lfs.dir(dir) do
        if entry:match("%.json$") then
            files[#files + 1] = entry
        end
    end

    -- Sort by filename (timestamp-based, newest first)
    table.sort(files, function(a, b) return a > b end)

    local uploaded = 0
    for i, entry in ipairs(files) do
        local path = dir .. "/" .. entry
        if i <= 5 then
            -- Upload the 5 most recent
            if CrashReporter.uploadReport(api, path) then
                uploaded = uploaded + 1
            end
        else
            -- Delete excess files
            os.remove(path)
            logger.warn("Tomo Crash: deleted excess pending file: " .. entry)
        end
    end

    if uploaded > 0 then
        logger.warn("Tomo Crash: flushed " .. uploaded .. " reports")
    end
end

-- Delete uploaded crash reports older than 30 days.
function CrashReporter.cleanupUploaded()
    local Recorder = require("core/recorder")
    local dir = Recorder.getLogDir() .. "/crashes/uploaded"
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs then return end
    local cutoff = os.time() - (30 * 86400)
    for entry in lfs.dir(dir) do
        if entry:match("%.json$") then
            local path = dir .. "/" .. entry
            local attr = lfs.attributes(path)
            if attr and attr.modification < cutoff then
                os.remove(path)
            end
        end
    end
end

-- Main entry point: called from tomo.lua on launch.
function CrashReporter.checkAndReport(api, device_profile, tomo_version, user_id, tomo_state)
    -- Parse crash.log for new Tomo crashes
    local crash_data = CrashReporter.checkForCrash()
    if crash_data then
        local report = CrashReporter.buildReport(
            crash_data, device_profile, tomo_version, user_id, tomo_state)
        CrashReporter.savePending(report)
    end

    -- Upload pending reports (max 5, deduped)
    local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_nm and NetworkMgr:isConnected() then
        CrashReporter.flushPending(api)
    end

    pcall(CrashReporter.cleanupUploaded)
end

return CrashReporter
