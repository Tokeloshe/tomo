-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/updater.lua
-- OTA auto-updater. Checks GitHub for new versions on every launch.
-- Shows a mandatory Update/Exit dialog when a newer version exists.
-- On download failure, re-prompts. After 3 consecutive session failures,
-- offers a "Continue Anyway" escape hatch so users are not trapped.
-- Reports OTA failures to Supabase via the crash reporter infrastructure.

local Updater = {}

local logger = require("logger")

local VERSION_URL = "https://raw.githubusercontent.com/Tokeloshe/tomo/main/version.json"

-- Session-scoped failure counter. Resets each launch (not persisted).
-- After 3 failures in a single session, the mandatory Update/Exit dialog
-- gains a third option: "Continue Anyway" to escape an infinite loop
-- caused by a missing or broken release on the server.
local session_ota_failures = 0

local function isNewer(remote_str, local_str)
    if not remote_str or not local_str then return false end
    local function parse(s)
        local maj, min, pat = s:match("^(%d+)%.(%d+)%.(%d+)")
        return tonumber(maj) or 0, tonumber(min) or 0, tonumber(pat) or 0
    end
    local rmaj, rmin, rpat = parse(remote_str)
    local lmaj, lmin, lpat = parse(local_str)
    if rmaj ~= lmaj then return rmaj > lmaj end
    if rmin ~= lmin then return rmin > lmin end
    return rpat > lpat
end

-- Pick a writable temp path for the downloaded zip.
-- Order:
--   1. KOReader's data directory (writable on every supported device)
--   2. /tmp (writable on most Kobo firmwares, unreliable elsewhere)
--   3. current directory (last resort)
local function getTempPath()
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if ok_ds then
        local ok_dir, dir = pcall(function() return DataStorage:getDataDir() end)
        if ok_dir and dir and dir ~= "" then
            return dir .. "/tomo-update.zip"
        end
    end
    -- Test /tmp with a write probe.
    local probe_path = "/tmp/.tomo_write_test"
    local probe = io.open(probe_path, "w")
    if probe then
        probe:close()
        os.remove(probe_path)
        return "/tmp/tomo-update.zip"
    end
    return "tomo-update.zip"
end

-- Resolve the final URL after following HTTP 301/302/303/307/308 redirects.
-- Probes each response with a discard sink (small response bodies are thrown
-- away) so we never have partial bytes mixed into our download. Returns the
-- terminal URL plus the code observed there, or an error message.
--
-- LuaSocket's built-in auto-redirect REUSES the same sink object across
-- requests, which means a redirect response body gets concatenated with the
-- final 200 body in the same file. That corrupts the zip. We drive redirects
-- manually with `redirect = false` to avoid that behaviour.
local function resolveRedirects(initial_url, block_timeout, total_timeout)
    local http       = require("socket.http")
    local ltn12      = require("ltn12")
    local socketutil = require("socketutil")

    local current_url = initial_url
    local max_redirects = 5
    for _ = 1, max_redirects + 1 do
        local discard = {}
        socketutil:set_timeout(block_timeout or 30, total_timeout or 60)
        local _, code, headers = http.request{
            url     = current_url,
            method  = "GET",
            sink    = ltn12.sink.table(discard),
            headers = { ["User-Agent"] = "Tomo-OTA/1.0" },
            redirect = false,
        }
        socketutil:reset_timeout()

        if type(code) ~= "number" then
            return nil, current_url, tostring(code or "request failed")
        end

        if code == 200 then
            -- The probe already downloaded the full body. Return it so the
            -- caller can use it instead of making a second request.
            return 200, current_url, nil, table.concat(discard)
        end

        if code == 301 or code == 302 or code == 303 or code == 307 or code == 308 then
            local loc = headers and (headers.location or headers.Location)
            if not loc or loc == "" then
                return code, current_url, "redirect with no Location"
            end
            -- Resolve relative URLs against the current scheme+host.
            if not loc:match("^https?://") then
                local scheme_host = current_url:match("^(https?://[^/]+)")
                if scheme_host then
                    if loc:sub(1, 1) == "/" then
                        loc = scheme_host .. loc
                    else
                        loc = scheme_host .. "/" .. loc
                    end
                end
            end
            logger.warn("Tomo OTA: redirect " .. code .. " -> " .. loc:sub(1, 120))
            current_url = loc
        else
            return code, current_url, "HTTP " .. tostring(code)
        end
    end
    return 508, current_url, "too many redirects"
end

function Updater.fetchVersionInfo()
    local code, _final_url, err, body = resolveRedirects(VERSION_URL, 15, 15)
    if code ~= 200 or not body then
        logger.warn("Tomo OTA: version check failed: " .. tostring(err or code))
        return nil
    end

    local ok, data = pcall(require("rapidjson").decode, body)
    if not ok or type(data) ~= "table" then
        logger.warn("Tomo OTA: version.json parse failed")
        return nil
    end

    return data
end

-- Fresh check on every launch. No caching, no flags, no skipping.
function Updater.checkForUpdate(local_version, on_exit)
    local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
    if not (ok_nm and NetworkMgr:isConnected()) then
        logger.warn("Tomo OTA: offline, skipping version check")
        return false
    end

    logger.warn("Tomo OTA: checking version, local=" .. local_version)
    local info = Updater.fetchVersionInfo()
    if not info or not info.version then
        return false
    end

    logger.warn("Tomo OTA: remote=" .. info.version .. " local=" .. local_version)

    if not isNewer(info.version, local_version) then
        logger.warn("Tomo OTA: up to date")
        return false
    end

    logger.warn("Tomo OTA: update available, showing dialog")
    Updater._showUpdateDialog(info, local_version, on_exit)
    return true
end

-- Mandatory dialog: Update or Exit. After 3 consecutive session failures,
-- a third option "Continue Anyway" appears so the user is never trapped
-- in an update loop when the release URL is broken.
function Updater._showUpdateDialog(info, local_version, on_exit)
    local UIManager  = require("ui/uimanager")

    local text = "Tomo v" .. info.version .. " is available.\n\n"
        .. (info.notes or "") .. "\n\n"
        .. "Please update to continue using Tomo."

    if session_ota_failures >= 3 then
        -- Three-button dialog with an escape hatch.
        local ok_bdt, ButtonDialogTitle = pcall(require, "ui/widget/buttondialogtitle")
        if ok_bdt then
            local dialog
            dialog = ButtonDialogTitle:new{
                title = text .. "\n\nThe update has failed several times. "
                    .. "You can continue using this version for now.",
                title_align = "left",
                buttons = {
                    {
                        {
                            text = "Retry Update",
                            callback = function()
                                UIManager:close(dialog)
                                Updater._downloadAndInstall(info, local_version, on_exit)
                            end,
                        },
                    },
                    {
                        {
                            text = "Continue Anyway",
                            callback = function()
                                logger.warn("Tomo OTA: user chose Continue Anyway after "
                                    .. session_ota_failures .. " session failures")
                                UIManager:close(dialog)
                            end,
                        },
                    },
                    {
                        {
                            text = "Exit Tomo",
                            callback = function()
                                UIManager:close(dialog)
                                if on_exit then on_exit() end
                            end,
                        },
                    },
                },
            }
            UIManager:show(dialog)
            return
        end
        -- Fall through to the two-button dialog if ButtonDialogTitle is
        -- unavailable on this KOReader version.
    end

    local ConfirmBox = require("ui/widget/confirmbox")
    UIManager:show(ConfirmBox:new{
        text = text,
        ok_text = "Update",
        cancel_text = "Exit Tomo",
        ok_callback = function()
            Updater._downloadAndInstall(info, local_version, on_exit)
        end,
        cancel_callback = function()
            if on_exit then on_exit() end
        end,
    })
end

-- Report an OTA failure to Supabase via crash reporter infrastructure.
local function reportOtaFailure(failure_type, info, local_version, http_code, err_msg)
    local ok, CrashReporter = pcall(require, "core/crash_reporter")
    if not ok then return end
    local Recorder = require("core/recorder")

    local ok_dev, DevMod = pcall(require, "core/device")
    local profile = ok_dev and DevMod.getProfile() or {}

    local ok_auth, Auth = pcall(require, "core/auth")
    local device_hash = ok_auth and Auth.deviceHash() or nil

    local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
    local wifi = ok_nm and NetworkMgr:isConnected() or false

    local report = {
        tomo_version = local_version or "unknown",
        device_model = profile.model_code or "unknown",
        device_tier = profile.tier or 0,
        screen_w = profile.screen_w or 0,
        screen_h = profile.screen_h or 0,
        stack_trace = "tomo OTA_FAILURE: " .. failure_type
            .. "\nurl=" .. tostring(info and info.url or "nil")
            .. "\nlocal_version=" .. tostring(local_version)
            .. "\nremote_version=" .. tostring(info and info.version or "nil")
            .. "\nhttp_code=" .. tostring(http_code or "nil")
            .. "\nerror=" .. tostring(err_msg or "nil"),
        last_actions = Recorder.getLastActions(20),
        crashed_at = os.date("%Y-%m-%dT%H:%M:%SZ"),
        current_screen = Recorder.getCurrentScreen(),
        device_hash = device_hash,
        session_id = Recorder.getSessionId(),
        install_id = nil,
        wifi_state_at_crash = wifi and "connected" or "disconnected",
        crash_hash = "ota_" .. failure_type,
        network_state = wifi and "online" or "offline",
    }

    -- Fill install_id from LuaSettings
    local ok_ls, LS = pcall(require, "luasettings")
    local ok_ds, DS = pcall(require, "datastorage")
    if ok_ls and ok_ds then
        local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
        report.install_id = ts:readSetting("install_id")
    end

    CrashReporter.savePending(report)
    logger.warn("Tomo OTA: failure report saved (" .. failure_type .. ")")
end

-- Show error, then re-show the mandatory update dialog.
-- Increments the session failure counter so that the third option appears
-- in the dialog after 3 consecutive failures in the same session.
local function showErrorAndReprompt(msg, info, local_version, on_exit)
    session_ota_failures = session_ota_failures + 1
    logger.warn("Tomo OTA: session failures now = " .. session_ota_failures)

    local UIManager  = require("ui/uimanager")
    local InfoMessage = require("ui/widget/infomessage")

    UIManager:show(InfoMessage:new{
        text = msg,
        timeout = 5,
    })

    -- Re-show the mandatory dialog after the error message
    UIManager:scheduleIn(5.5, function()
        local ok_sched, err = pcall(function()
            Updater._showUpdateDialog(info, local_version, on_exit)
        end)
        if not ok_sched then
            logger.warn("Tomo OTA: reprompt error: " .. tostring(err))
        end
    end)
end

-- Verify that the file at path begins with the ZIP magic bytes PK\x03\x04.
-- GitHub 404 responses return HTML pages, not zips; attempting to unzip an
-- HTML page triggers an "extraction_error" that looks like a corrupt build.
-- This check catches the error at the source.
local function isValidZip(path)
    local check = io.open(path, "rb")
    if not check then return false, "cannot open for read" end
    local magic = check:read(4)
    check:close()
    if not magic or #magic < 4 then return false, "too short" end
    if magic:sub(1, 4) ~= "PK\x03\x04" then
        return false, "bad magic: " .. tostring(magic):sub(1, 16)
    end
    return true, nil
end

-- Try to extract a zip to dest_dir using several mechanisms in order:
--   1. `unzip` on PATH
--   2. `busybox unzip`
--   3. Absolute paths /bin/unzip, /usr/bin/unzip
--   4. Pure-Lua fallback using KOReader's bundled libzzip
-- Returns (true, method_name, nil) on success or (false, nil, error_details).
local function extractZip(zip_path, dest_dir)
    os.execute('rm -rf "' .. dest_dir .. '" 2>/dev/null')
    os.execute('mkdir -p "' .. dest_dir .. '" 2>/dev/null')

    local commands = {
        { name = "unzip",            tmpl = 'unzip -o "%s" -d "%s"' },
        { name = "busybox-unzip",    tmpl = 'busybox unzip -o "%s" -d "%s"' },
        { name = "/bin/unzip",       tmpl = '/bin/unzip -o "%s" -d "%s"' },
        { name = "/usr/bin/unzip",   tmpl = '/usr/bin/unzip -o "%s" -d "%s"' },
        { name = "/bin/busybox",     tmpl = '/bin/busybox unzip -o "%s" -d "%s"' },
    }

    local errors = {}
    local marker_path = dest_dir .. "/tomo.koplugin/main.lua"
    for _, c in ipairs(commands) do
        -- Capture stderr so we get a real reason on failure.
        local cmd = string.format(c.tmpl .. ' 2>&1', zip_path, dest_dir)
        local handle = io.popen(cmd)
        local output = ""
        local close_code
        if handle then
            output = handle:read("*a") or ""
            -- In Lua 5.1/LuaJIT, close returns true/false; in 5.3 it returns
            -- (ok, "exit"|"signal", code). Capture what we can.
            local ok_close, _, code = handle:close()
            close_code = ok_close == true and 0 or (code or -1)
        else
            close_code = -1
        end
        -- Verify success by looking for the marker file. Some unzip variants
        -- print warnings on stderr but still succeed; others return nonzero
        -- on benign warnings. The only reliable check is "did main.lua land?".
        local check = io.open(marker_path, "r")
        if check then
            check:close()
            logger.warn("Tomo OTA: extracted via " .. c.name)
            return true, c.name, nil
        end
        errors[#errors + 1] = c.name .. "(exit=" .. tostring(close_code)
            .. "): " .. tostring(output):gsub("[\n\r]", " "):sub(1, 120)
    end

    -- Pure-Lua fallback using libzzip (bundled with KOReader on most builds).
    local ok_ffi, ffi = pcall(require, "ffi")
    if ok_ffi then
        local ok_zzip, result = pcall(function()
            -- Declare just the zzip calls we need. Wrap in its own pcall so
            -- this section never prevents retries on non-FFI devices.
            pcall(ffi.cdef, [[
                typedef struct _ZZIP_DIR  ZZIP_DIR;
                typedef struct _ZZIP_FILE ZZIP_FILE;
                typedef struct zzip_stat {
                    int d_compr;
                    int d_csize;
                    int st_size;
                    char d_name[256];
                } ZZIP_STAT;
                ZZIP_DIR *zzip_opendir(const char *path);
                int zzip_dir_read(ZZIP_DIR *dir, ZZIP_STAT *stat);
                int zzip_dir_close(ZZIP_DIR *dir);
                ZZIP_FILE *zzip_file_open(ZZIP_DIR *dir, const char *name, int o_mode);
                int zzip_file_read(ZZIP_FILE *fp, void *buf, int len);
                int zzip_file_close(ZZIP_FILE *fp);
            ]])
            local zz = ffi.load("zzip")
            local dir = zz.zzip_opendir(zip_path)
            if dir == nil then return "zzip_opendir failed" end
            local stat = ffi.new("ZZIP_STAT")
            local buf = ffi.new("char[65536]")
            while zz.zzip_dir_read(dir, stat) ~= 0 do
                local name = ffi.string(stat.d_name)
                local out_path = dest_dir .. "/" .. name
                if name:sub(-1) == "/" then
                    os.execute('mkdir -p "' .. out_path .. '" 2>/dev/null')
                else
                    local parent = out_path:match("^(.*)/[^/]+$")
                    if parent then
                        os.execute('mkdir -p "' .. parent .. '" 2>/dev/null')
                    end
                    local fp = zz.zzip_file_open(dir, stat.d_name, 0)
                    if fp == nil then
                        zz.zzip_dir_close(dir)
                        return "zzip_file_open failed for " .. name
                    end
                    local of = io.open(out_path, "wb")
                    if not of then
                        zz.zzip_file_close(fp)
                        zz.zzip_dir_close(dir)
                        return "cannot write " .. out_path
                    end
                    while true do
                        local n = zz.zzip_file_read(fp, buf, 65536)
                        if n <= 0 then break end
                        of:write(ffi.string(buf, n))
                    end
                    of:close()
                    zz.zzip_file_close(fp)
                end
            end
            zz.zzip_dir_close(dir)
            return nil
        end)
        if ok_zzip and result == nil then
            local check = io.open(marker_path, "r")
            if check then
                check:close()
                logger.warn("Tomo OTA: extracted via libzzip")
                return true, "libzzip", nil
            end
        else
            errors[#errors + 1] = "libzzip: " .. tostring(result)
        end
    end

    return false, nil, table.concat(errors, " | ")
end

function Updater._downloadAndInstall(info, local_version, on_exit)
    local UIManager  = require("ui/uimanager")
    local InfoMessage = require("ui/widget/infomessage")
    local ltn12      = require("ltn12")

    local dl_msg = InfoMessage:new{
        text = "Downloading update...",
        timeout = 60,
    }
    UIManager:show(dl_msg)

    local tmp_path = getTempPath()
    logger.warn("Tomo OTA: downloading to " .. tmp_path)

    -- Test writability before the HTTP call so we fail fast with a useful
    -- error rather than sinking bytes into a broken file.
    local write_probe = io.open(tmp_path, "wb")
    if not write_probe then
        reportOtaFailure("write_error", info, local_version, nil,
            "cannot open temp file: " .. tmp_path)
        showErrorAndReprompt("Update failed. Cannot write to device.", info, local_version, on_exit)
        return
    end
    write_probe:close()
    os.remove(tmp_path)

    logger.warn("Tomo OTA: downloading from " .. tostring(info.url))

    -- Phase 1: follow redirects with discard sinks so no 302 body bytes leak
    -- into the final file. If the probe itself returned 200, the body has
    -- already been captured and we skip Phase 2.
    local code, final_url, resolve_err, probe_body = resolveRedirects(info.url, 30, 60)

    local body_bytes = probe_body
    if code ~= 200 then
        logger.warn("Tomo OTA: redirect resolve failed: "
            .. tostring(resolve_err or code))
        local fail_type = (code == nil or code == "timeout") and "timeout" or "download_error"
        reportOtaFailure(fail_type, info, local_version, code, resolve_err)
        showErrorAndReprompt("Update failed. Please try again.", info, local_version, on_exit)
        return
    end

    -- Phase 2: if we still need the bytes (shouldn't normally, since the
    -- probe usually already fetched them), do one targeted GET at the
    -- resolved URL with a file sink.
    if not body_bytes or body_bytes == "" then
        local f2 = io.open(tmp_path, "wb")
        if not f2 then
            reportOtaFailure("write_error", info, local_version, nil,
                "phase-2 cannot open " .. tmp_path)
            showErrorAndReprompt("Update failed. Cannot write to device.",
                info, local_version, on_exit)
            return
        end
        local http       = require("socket.http")
        local socketutil = require("socketutil")
        socketutil:set_timeout(30, 60)
        local _, code2 = http.request{
            url     = final_url,
            method  = "GET",
            sink    = ltn12.sink.file(f2),
            headers = { ["User-Agent"] = "Tomo-OTA/1.0" },
            redirect = false,
        }
        socketutil:reset_timeout()
        if type(code2) ~= "number" or code2 ~= 200 then
            os.remove(tmp_path)
            reportOtaFailure("download_error", info, local_version, code2,
                "phase-2 HTTP " .. tostring(code2))
            showErrorAndReprompt("Update failed. Please try again.",
                info, local_version, on_exit)
            return
        end
    else
        -- Write the probe's buffered body to disk.
        local fw = io.open(tmp_path, "wb")
        if not fw then
            reportOtaFailure("write_error", info, local_version, nil,
                "cannot write probe body to " .. tmp_path)
            showErrorAndReprompt("Update failed. Cannot write to device.",
                info, local_version, on_exit)
            return
        end
        fw:write(body_bytes)
        fw:close()
    end

    -- Verify ZIP magic bytes. Catches HTML error pages that were served as
    -- 200 after a redirect chain, and any other non-zip payload.
    local valid, reason = isValidZip(tmp_path)
    if not valid then
        logger.warn("Tomo OTA: downloaded file is not a valid zip ("
            .. tostring(reason) .. ")")
        os.remove(tmp_path)
        reportOtaFailure("download_error", info, local_version, code,
            "not a zip: " .. tostring(reason))
        showErrorAndReprompt("Update failed. Invalid download.",
            info, local_version, on_exit)
        return
    end

    -- Verify file size
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if ok_lfs then
        local attr = lfs.attributes(tmp_path)
        if not attr or (attr.size or 0) < 1000 then
            logger.warn("Tomo OTA: download too small: "
                .. tostring(attr and attr.size))
            os.remove(tmp_path)
            reportOtaFailure("download_error", info, local_version, 200,
                "file too small: " .. tostring(attr and attr.size))
            showErrorAndReprompt("Update failed. Download incomplete.",
                info, local_version, on_exit)
            return
        end
        logger.warn("Tomo OTA: downloaded " .. tostring(attr.size) .. " bytes")
    end

    -- ATOMIC UPDATE: extract to temp dir, verify, swap, rollback on failure.
    -- The live plugin directory is NEVER partially modified.
    logger.warn("Tomo OTA: extracting (atomic)...")
    local ok_ds, DataStorage = pcall(require, "datastorage")
    local plugins_dir = ok_ds and (DataStorage:getDataDir() .. "/plugins") or "."
    local live_dir = plugins_dir .. "/tomo.koplugin"
    local temp_dir = plugins_dir .. "/tomo.koplugin_update_temp"
    local backup_dir = plugins_dir .. "/tomo.koplugin_backup"

    -- Step 1: Extract to temp directory with fallback methods.
    local extracted_ok, method, extract_err = extractZip(tmp_path, temp_dir)
    os.remove(tmp_path)

    if not extracted_ok then
        logger.warn("Tomo OTA: extraction failed: " .. tostring(extract_err))
        os.execute('rm -rf "' .. temp_dir .. '" 2>/dev/null')
        reportOtaFailure("extraction_error", info, local_version, nil,
            "all extractors failed: " .. tostring(extract_err))
        showErrorAndReprompt("Update failed. Extraction error.",
            info, local_version, on_exit)
        return
    end
    logger.warn("Tomo OTA: extraction ok via " .. tostring(method))

    -- The zip contains tomo.koplugin/ as top-level, so files are at temp_dir/tomo.koplugin/
    local new_dir = temp_dir .. "/tomo.koplugin"

    -- Step 2: Verify critical files exist in extracted dir
    local critical_files = {"main.lua", "_meta.lua", "tomo.lua"}
    for _, fname in ipairs(critical_files) do
        local check = io.open(new_dir .. "/" .. fname, "r")
        if not check then
            logger.warn("Tomo OTA: verification failed, " .. fname .. " missing in extracted zip")
            os.execute('rm -rf "' .. temp_dir .. '" 2>/dev/null')
            reportOtaFailure("verification_error", info, local_version, nil, fname .. " missing in zip")
            showErrorAndReprompt("Update failed. Corrupt download.", info, local_version, on_exit)
            return
        end
        check:close()
    end

    -- Step 3: Backup current installation
    os.execute('rm -rf "' .. backup_dir .. '" 2>/dev/null')
    local backup_ok = os.rename(live_dir, backup_dir)

    -- Step 4: Swap in new version
    local swap_ok = os.rename(new_dir, live_dir)
    if not swap_ok then
        logger.warn("Tomo OTA: swap failed, rolling back")
        -- Rollback: restore backup
        if backup_ok then os.rename(backup_dir, live_dir) end
        os.execute('rm -rf "' .. temp_dir .. '" 2>/dev/null')
        reportOtaFailure("extraction_error", info, local_version, nil, "rename to live dir failed")
        showErrorAndReprompt("Update failed. Please try again.", info, local_version, on_exit)
        return
    end

    -- Step 5: Verify the swap
    local final_check = io.open(live_dir .. "/main.lua", "r")
    if not final_check then
        logger.warn("Tomo OTA: post-swap verification failed, rolling back")
        os.execute('rm -rf "' .. live_dir .. '" 2>/dev/null')
        if backup_ok then os.rename(backup_dir, live_dir) end
        os.execute('rm -rf "' .. temp_dir .. '" 2>/dev/null')
        reportOtaFailure("verification_error", info, local_version, nil, "main.lua missing after swap")
        showErrorAndReprompt("Update failed. Please try again.", info, local_version, on_exit)
        return
    end
    final_check:close()

    -- Step 6: Clean up
    os.execute('rm -rf "' .. backup_dir .. '" 2>/dev/null')
    os.execute('rm -rf "' .. temp_dir .. '" 2>/dev/null')

    logger.warn("Tomo OTA: update to v" .. info.version .. " complete (atomic swap)")
    UIManager:show(InfoMessage:new{
        text = "Update complete. Please restart KOReader.",
        timeout = nil,
    })
end

return Updater
