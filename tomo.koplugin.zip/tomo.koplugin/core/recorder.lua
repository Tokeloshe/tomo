-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/recorder.lua
-- Session logger with organized file structure and screen tracking.
-- Logs to logs/sessions/YYYY-MM-DD.log with SESSION START/END markers.
-- Tracks current_screen for crash reports. Generates session_id UUID.

local Recorder = {}

local _file = nil
local _path = nil
local _log_dir = nil
local _session_start = nil
local _current_screen = "home"
local _session_id = nil

local function ensureDir(dir)
    os.execute('mkdir -p "' .. dir .. '" 2>/dev/null')
end

local function getLogDir()
    if _log_dir then return _log_dir end
    -- Store logs OUTSIDE the plugin directory so OTA updates do not wipe them.
    -- Use the KOReader data directory (same level as settings, crash logs, etc.).
    local ok, DataStorage = pcall(require, "datastorage")
    local base = ok and DataStorage:getDataDir() or "."
    _log_dir = base .. "/tomo_logs"
    ensureDir(_log_dir .. "/sessions")
    ensureDir(_log_dir .. "/crashes/pending")
    ensureDir(_log_dir .. "/crashes/uploaded")
    return _log_dir
end

-- Generate a simple random hex UUID for session tracking.
local function generateUUID()
    math.randomseed(os.time() + (os.clock() * 1000))
    local template = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"
    return template:gsub("[xy]", function(c)
        local v = c == "x" and math.random(0, 15) or math.random(8, 11)
        return string.format("%x", v)
    end)
end

function Recorder.start()
    local dir = getLogDir()
    local date = os.date("%Y-%m-%d")
    _path = dir .. "/sessions/" .. date .. ".log"
    _file = io.open(_path, "a")
    _session_start = os.date("%Y-%m-%d %H:%M:%S")
    _session_id = generateUUID()
    _current_screen = "home"
    if _file then
        _file:write("\n=== SESSION START " .. _session_start .. " id=" .. _session_id .. " ===\n")
        _file:flush()
        Recorder.log("LAUNCH", "Session started")
    end
    pcall(Recorder._migrateOldLogs)
    pcall(Recorder._cleanupOldLogs)
end

function Recorder.log(category, message)
    if not _file then return end
    local ts = os.date("%Y-%m-%d %H:%M:%S")
    local line = ts .. " | " .. (category or "?") .. " | " .. tostring(message) .. "\n"
    _file:write(line)
    _file:flush()
    -- Track current screen from NAV events
    if category == "NAV" then
        local msg = tostring(message):lower()
        if msg:find("home") then _current_screen = "home"
        elseif msg:find("room") and not msg:find("closed") then _current_screen = "room"
        elseif msg:find("canvas") then _current_screen = "canvas"
        elseif msg:find("conservatory") then _current_screen = "conservatory"
        elseif msg:find("penpal") then _current_screen = "penpal"
        elseif msg:find("setting") then _current_screen = "settings"
        elseif msg:find("onboard") then _current_screen = "onboarding"
        elseif msg:find("message") or msg:find("inbox") then _current_screen = "messages"
        elseif msg:find("profile") then _current_screen = "profile"
        end
    elseif category == "TAP" then
        local msg = tostring(message):lower()
        if msg:find("sekki") then _current_screen = "sekki" end
    end
end

function Recorder.stop()
    if _file then
        local ts = os.date("%Y-%m-%d %H:%M:%S")
        _file:write("=== SESSION END " .. ts .. " ===\n")
        _file:close()
        _file = nil
    end
end

function Recorder.getSessionPath() return _path end
function Recorder.getLogDir() return getLogDir() end
function Recorder.getCurrentScreen() return _current_screen end
function Recorder.getSessionId() return _session_id end
function Recorder.getSessionStart() return _session_start end

function Recorder.getLastActions(n)
    if not _path then return {} end
    local f = io.open(_path, "r")
    if not f then return {} end
    local lines = {}
    for line in f:lines() do
        if line:match("^%d%d%d%d%-%d%d%-%d%d") and not line:match("^===") then
            lines[#lines + 1] = line
        end
    end
    f:close()
    local result = {}
    local start = math.max(1, #lines - n + 1)
    for i = start, #lines do
        result[#result + 1] = lines[i]
    end
    return result
end

function Recorder._migrateOldLogs()
    local ok, DataStorage = pcall(require, "datastorage")
    if not ok then return end
    local data_dir = DataStorage:getDataDir()
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs then return end
    local count = 0
    for entry in lfs.dir(data_dir) do
        if entry:match("^tomo%-session%-.*%.log$") then
            local src = data_dir .. "/" .. entry
            local dst = getLogDir() .. "/sessions/" .. entry
            os.rename(src, dst)
            count = count + 1
        end
    end
    if count > 0 then
        Recorder.log("MIGRATE", "Moved " .. count .. " old session files to logs/sessions/")
    end
end

function Recorder._cleanupOldLogs()
    local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok_lfs then return end
    local dir = getLogDir() .. "/sessions"
    local cutoff = os.time() - (14 * 86400)
    for entry in lfs.dir(dir) do
        if entry:match("%.log$") then
            local path = dir .. "/" .. entry
            local attr = lfs.attributes(path)
            if attr and attr.modification < cutoff then
                os.remove(path)
            end
        end
    end
end

return Recorder
