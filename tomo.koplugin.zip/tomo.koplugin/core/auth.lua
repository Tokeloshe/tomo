-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/auth.lua
-- Device-fingerprint authentication against Supabase Auth.
-- Tomo™ identifies itself using the Kobo device UUID, salted and hashed.
-- No email, no password, no personal data crosses the wire.
--
-- Flow:
--   1. Compute device_hash = SHA256("tomo-v1:" + device_uuid)
--   2. Attempt Supabase sign-in with device_hash as pseudo-email
--   3. If user does not exist, sign up and create a user record
--   4. Store JWT and user_id in tomo_cache.db via Cache:setState
--   5. On subsequent launches, restore token from cache and verify it is valid

local Auth = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Device fingerprinting
-- ─────────────────────────────────────────────────────────────────────────────

-- Read the device UUID from Kobo's version file.
-- The version string format is:
--   ModelCode,fw1,fw2,fw3,fw4,UUID
-- The UUID is the last comma-separated field.
-- Checks the real device path first, then a relative path for emulator testing.
-- Returns the UUID string, or nil if the file is absent or malformed.
local function readDeviceUUID()
    -- Kobo: UUID is the last field in the version file
    local kobo_paths = {
        "/mnt/onboard/.kobo/version",
        ".kobo/version",
    }
    for _, path in ipairs(kobo_paths) do
        local f = io.open(path, "r")
        if f then
            local line = f:read("*l")
            f:close()
            if line and line ~= "" then
                local uuid = line:match("([%x%-]+)%s*$")
                if uuid then return uuid end
            end
        end
    end

    -- Kindle: serial number from /proc/usid or NKEY
    local kindle_paths = {
        "/proc/usid",
        "/var/local/system/NKEY/nkey.dat",
    }
    for _, path in ipairs(kindle_paths) do
        local f = io.open(path, "r")
        if f then
            local line = f:read("*l")
            f:close()
            if line and line ~= "" then
                local serial = line:match("^%s*(.-)%s*$")
                if serial and #serial >= 8 then return serial end
            end
        end
    end

    -- Kindle: environment variable
    local env_serial = os.getenv("DEVICE_SERIAL")
    if env_serial and #env_serial >= 8 then
        return env_serial
    end

    -- Generic: parse "Serial" from /proc/cpuinfo (works on most Linux ARM devices)
    local cpuinfo = io.open("/proc/cpuinfo", "r")
    if cpuinfo then
        for line in cpuinfo:lines() do
            local serial = line:match("^Serial%s*:%s*(%S+)")
            if serial and #serial >= 8 then
                cpuinfo:close()
                return serial
            end
        end
        cpuinfo:close()
    end

    -- Last resort: generate a persistent random ID via LuaSettings.
    -- Unique per device, survives app restarts, but not a real hardware ID.
    -- Each require is wrapped in its own pcall so one missing module does not
    -- break the fallback chain.
    local ok_ls, LuaSettings = pcall(require, "luasettings")
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if ok_ls and ok_ds then
        local ok_open, settings = pcall(function()
            return LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
        end)
        if ok_open and settings then
            local stored = settings:readSetting("fallback_device_id")
            if stored then return stored end
            -- Generate from device model + random bytes
            local ok_dev, KODevice = pcall(require, "device")
            local model = (ok_dev and KODevice and KODevice.model) or "unknown"
            math.randomseed(os.time() + (os.clock() * 1000))
            local rand = string.format("%08x%08x",
                math.random(0xFFFFFFFF), math.random(0xFFFFFFFF))
            local fallback_id = model .. "-" .. rand
            pcall(function()
                settings:saveSetting("fallback_device_id", fallback_id)
                settings:flush()
            end)
            return fallback_id
        end
    end

    -- ABSOLUTE LAST RESORT: transient in-memory ID. Guarantees we never
    -- return nil so the caller can always proceed with an anonymous session.
    -- This id will change on every launch (not persisted), but the user will
    -- still get a working Tomo experience on device tiers where no settings
    -- storage is available.
    return "transient-" .. tostring(os.time())
        .. "-" .. tostring(math.floor(os.clock() * 1000))
end

-- Compute SHA256("tomo-v1:" + uuid) using KOReader's bundled sha2 FFI.
-- Falls back to shelling out to sha256sum if the FFI module is unavailable.
-- Returns a lowercase hex string (64 characters), or nil on failure.
local function computeDeviceHash(uuid)
    local salted = "tomo-v1:" .. uuid

    -- Primary: use KOReader's bundled SHA2 FFI binding.
    local ok, sha = pcall(require, "ffi/sha2")
    if ok and sha and sha.sha256 then
        return sha.sha256(salted)
    end

    -- Fallback: shell out. Works on any POSIX system with sha256sum.
    -- The input is passed via echo -n to avoid trailing newline contamination.
    local safe_input = salted:gsub('"', '\\"')
    local handle = io.popen(string.format('echo -n "%s" | sha256sum 2>/dev/null', safe_input))
    if not handle then return nil end
    local result = handle:read("*a")
    handle:close()
    local hash = result and result:match("^(%x+)")
    return hash
end

-- Return the device hash for this device.
-- This is the stable, privacy-preserving identifier used as the Supabase
-- pseudo-email. The UUID itself never leaves the device; only the hash does.
-- Guaranteed non-nil: on total failure, returns a transient hash so the caller
-- can always proceed with an anonymous session.
function Auth.deviceHash()
    local ok, result = pcall(function()
        local uuid = readDeviceUUID()
        if uuid then
            local hashed = computeDeviceHash(uuid)
            if hashed then return hashed end
            -- computeDeviceHash failed but we have a uuid; hash the uuid by
            -- running the fallback path again (which rarely fails twice).
            return computeDeviceHash(uuid) or uuid
        end
        return nil
    end)
    if ok and result and type(result) == "string" and #result > 0 then
        return result
    end

    -- Something threw, or both primary and fallback paths returned nil.
    -- readDeviceUUID() is supposed to never return nil, but guard anyway:
    -- try once more with a fresh pcall, then synthesise an emergency id.
    local logger = require("logger")
    logger.warn("Tomo Auth: deviceHash error: " .. tostring(result))

    local ok2, uuid2 = pcall(readDeviceUUID)
    if ok2 and uuid2 and type(uuid2) == "string" and #uuid2 > 0 then
        local ok_h, hashed = pcall(computeDeviceHash, uuid2)
        if ok_h and hashed then return hashed end
        return uuid2
    end

    -- Emergency: synthesise a transient ID so auth.ensureAuthenticated() can
    -- still return something and the rest of the plugin can continue.
    return "emergency-" .. tostring(os.time())
        .. "-" .. tostring(math.floor(os.clock() * 1000))
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Token management (stored in tomo_cache.db via Cache:setState)
-- ─────────────────────────────────────────────────────────────────────────────

-- Store the Supabase JWT and associated user_id in the local cache.
function Auth.saveToken(cache, jwt, user_id)
    cache:setState("auth_jwt", jwt)
    cache:setState("auth_user_id", user_id)
end

-- Retrieve the stored JWT from cache.
-- Returns nil if no token has been saved yet.
function Auth.loadToken(cache)
    return cache:getState("auth_jwt")
end

-- Retrieve the stored user_id from cache.
function Auth.loadUserId(cache)
    return cache:getState("auth_user_id")
end

-- Remove the stored token (used on "Leave Tomo" flow).
function Auth.clearToken(cache)
    cache:deleteState("auth_jwt")
    cache:deleteState("auth_user_id")
    cache:deleteState("auth_username")
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Supabase Auth REST calls
-- Uses socket.http + ltn12 + socketutil, the standard KOReader HTTP pattern.
-- Authentication is synchronous because the UI cannot render without it.
-- ─────────────────────────────────────────────────────────────────────────────

-- Make a synchronous HTTP request to the Supabase Auth API.
-- Returns (status_code, response_body_string) or (nil, error_string).
local function authRequest(url, method, body_table, anon_key)
    local rapidjson  = require("rapidjson")
    local http       = require("socket.http")
    local ltn12      = require("ltn12")
    local socketutil = require("socketutil")

    local headers = {
        ["apikey"]         = anon_key,
        ["Authorization"]  = "Bearer " .. anon_key,
        ["Content-Type"]   = "application/json",
    }

    local body_str = body_table and rapidjson.encode(body_table) or nil
    if body_str then
        headers["Content-Length"] = tostring(#body_str)
    end

    local sink = {}
    local request = {
        url     = url,
        method  = method,
        sink    = ltn12.sink.table(sink),
        headers = headers,
    }
    if body_str then
        request.source = ltn12.source.string(body_str)
    end

    socketutil:set_timeout(socketutil.LARGE_BLOCK_TIMEOUT, socketutil.LARGE_TOTAL_TIMEOUT)
    local _, code = http.request(request)
    socketutil:reset_timeout()

    if type(code) ~= "number" then
        return nil, tostring(code or "HTTP request failed")
    end

    return code, table.concat(sink)
end

-- Attempt to sign in with the device hash.
-- On success, returns (jwt, user_id). On failure, returns (nil, error_string).
local function signIn(supabase_url, anon_key, device_hash)
    local rapidjson = require("rapidjson")
    local logger = require("logger")
    local url = supabase_url .. "/auth/v1/token?grant_type=password"
    local body = {
        email    = device_hash .. "@tomo-reader.local",
        password = device_hash,
    }

    local status, body_str = authRequest(url, "POST", body, anon_key)
    logger.warn("Tomo Auth signIn: status=" .. tostring(status) .. " body=" .. tostring(body_str and body_str:sub(1, 200)))
    if not status then return nil, body_str end

    local ok, data = pcall(rapidjson.decode, body_str)
    if not ok or type(data) ~= "table" then
        return nil, "Auth response parse error"
    end

    if status == 200 and data.access_token then
        return data.access_token, data.user and data.user.id
    end

    return nil, "Sign-in failed: " .. (data.error_description or data.msg or tostring(status))
end

-- Sign up a new device with Supabase Auth.
-- On success, returns (jwt, user_id). On failure, returns (nil, error_string).
local function signUp(supabase_url, anon_key, device_hash)
    local rapidjson = require("rapidjson")
    local logger = require("logger")
    local url = supabase_url .. "/auth/v1/signup"
    local body = {
        email    = device_hash .. "@tomo-reader.local",
        password = device_hash,
    }

    local status, body_str = authRequest(url, "POST", body, anon_key)
    logger.warn("Tomo Auth signUp: status=" .. tostring(status) .. " body=" .. tostring(body_str and body_str:sub(1, 300)))
    if not status then return nil, body_str end

    local ok, data = pcall(rapidjson.decode, body_str)
    if not ok or type(data) ~= "table" then
        return nil, "Sign-up response parse error"
    end

    if (status == 200 or status == 201) and data.access_token then
        return data.access_token, data.user and data.user.id
    end

    return nil, "Sign-up failed: " .. (data.error_description or data.msg or tostring(status))
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Public entry point
-- ─────────────────────────────────────────────────────────────────────────────

-- Ensure the device is authenticated with Supabase.
-- Called once from tomo.lua on plugin init, after Cache:open().
--
-- Strategy:
--   1. Check cache for an existing JWT.
--   2. Try to sign in with the device hash (validates the token is still accepted).
--   3. If sign-in fails (user not found), sign up instead.
--   4. Save the new token to cache.
--
-- `config` is the tomo.lua config table (supabase_url, supabase_key).
-- `cache` is a Cache instance that has been opened.
--
-- Returns (jwt, user_id) on success, (nil, error_string) on failure.
-- The caller should handle the nil case gracefully (offline launch).
function Auth.ensureAuthenticated(config, cache)
    local logger = require("logger")
    local device_hash = Auth.deviceHash()
    if not device_hash or device_hash == "" then
        -- deviceHash() is designed to never return nil, but as a last-ditch
        -- safety net synthesise an emergency hash so the user can still get
        -- an anonymous session instead of being locked out of the app.
        device_hash = "emergency-" .. tostring(os.time())
        logger.warn("Tomo Auth: device_hash was nil, using emergency id")
    end
    logger.warn("Tomo Auth: device_hash="
        .. tostring(device_hash:sub(1, 12)) .. "...")

    -- Try sign-in first. This validates an existing account and refreshes the
    -- JWT without creating a duplicate user.
    local jwt, user_id = signIn(config.supabase_url, config.supabase_key, device_hash)
    if jwt then
        logger.warn("Tomo Auth: sign-in OK, user_id=" .. tostring(user_id))
        Auth.saveToken(cache, jwt, user_id)
        return jwt, user_id
    end
    logger.warn("Tomo Auth: sign-in failed, trying sign-up")

    -- Sign-in failed, most likely a new device. Sign up.
    jwt, user_id = signUp(config.supabase_url, config.supabase_key, device_hash)
    if jwt then
        logger.warn("Tomo Auth: sign-up OK, user_id=" .. tostring(user_id))
        Auth.saveToken(cache, jwt, user_id)
        return jwt, user_id
    end
    logger.warn("Tomo Auth: sign-up also failed, will retry once after 2s")

    -- Retry once: on Kobo the Wi-Fi stack may not be fully ready when
    -- the plugin init fires. A DNS lookup can fail with "host or service
    -- not provided, or not known" even when the network indicator shows
    -- connected. A short sleep gives the DNS resolver time to come up.
    local socket = require("socket")
    socket.sleep(2)

    jwt, user_id = signIn(config.supabase_url, config.supabase_key, device_hash)
    if jwt then
        logger.warn("Tomo Auth: retry sign-in OK, user_id=" .. tostring(user_id))
        Auth.saveToken(cache, jwt, user_id)
        return jwt, user_id
    end

    jwt, user_id = signUp(config.supabase_url, config.supabase_key, device_hash)
    if jwt then
        logger.warn("Tomo Auth: retry sign-up OK, user_id=" .. tostring(user_id))
        Auth.saveToken(cache, jwt, user_id)
        return jwt, user_id
    end
    logger.warn("Tomo Auth: retry also failed, proceeding offline")

    -- Both attempts failed. Return whatever is in the cache.
    local cached_jwt = Auth.loadToken(cache)
    local cached_uid = Auth.loadUserId(cache)
    if cached_jwt and cached_uid then
        return cached_jwt, cached_uid
    end

    return nil, "Authentication failed and no cached token available"
end

return Auth
