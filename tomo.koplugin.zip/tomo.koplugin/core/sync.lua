-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- core/sync.lua
-- Message polling and outbox flushing for the active room.
--
-- Realtime strategy: REST polling every 10 seconds while a room is open.
-- Rationale: KOReader has no native WebSocket client. Polling at 10s intervals
-- is within Supabase free tier API limits (see SKILLS.md §6.3 design decision).
-- WebSocket (via bundled websocat) is deferred to Phase 4.
--
-- One active poll at a time. Entering a new room stops the previous poll and
-- starts a fresh one for the new room. Home screen has no background poll.

local Sync = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Constructor
-- ─────────────────────────────────────────────────────────────────────────────

function Sync.new(api, cache)
    local instance = {
        api          = api,
        cache        = cache,
        _active_room = nil,
        _poll_fn     = nil,
        _polling     = false,
        _flushing    = false,
    }
    return setmetatable(instance, { __index = Sync })
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Room polling
-- ─────────────────────────────────────────────────────────────────────────────

-- Begin polling for new messages in `room_id`.
-- `on_message(msg_table)` is called for each new message received.
-- Cancels any previous poll before starting.
-- The poll runs every 10 seconds until stopRoom() is called.
function Sync:enterRoom(room_id, user_id, page_size, on_message)
    -- Stop any existing poll first.
    self:stopRoom()

    self._active_room = room_id
    self._polling = true
    self._poll_fail_count = 0
    self._poll_interval = 10
    self._poll_stopped = false

    local UIManager = require("ui/uimanager")
    local api       = self.api
    local cache     = self.cache
    local logger    = require("logger")

    local last_seen_ts = cache:newestMessageTime(room_id)

    local poll_fn
    poll_fn = function()
        if not self._polling or self._active_room ~= room_id then return end
        if self._poll_stopped then return end

        -- Quick gate: skip HTTP if we know we're disconnected
        local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
        if ok_nm and not NetworkMgr:isConnected() then
            self._poll_fail_count = (self._poll_fail_count or 0) + 1
            if self._poll_fail_count >= 5 then
                logger.warn("Tomo Sync: 5 failures (offline), stopping poll. Will retry on room reopen.")
                self._poll_stopped = true
                return
            end
            self._poll_interval = math.min((self._poll_interval or 10) * 2, 300)
            logger.warn("Tomo Poll: fail " .. self._poll_fail_count .. "/5, next in " .. self._poll_interval .. "s")
            UIManager:scheduleIn(self._poll_interval, poll_fn)
            return
        end

        api:getMessages(room_id, page_size or 20, last_seen_ts, function(err, msgs)
            if not self._polling or self._active_room ~= room_id then return end

            if err then
                self._poll_fail_count = (self._poll_fail_count or 0) + 1
                if self._poll_fail_count >= 5 then
                    logger.warn("Tomo Sync: 5 failures, stopping poll. Will retry on room reopen.")
                    self._poll_stopped = true
                    return
                end
                self._poll_interval = math.min((self._poll_interval or 10) * 2, 300)
                logger.warn("Tomo Poll: fail " .. self._poll_fail_count .. "/5 (" .. tostring(err) .. "), next in " .. self._poll_interval .. "s")
            elseif type(msgs) == "table" and #msgs > 0 then
                local ordered = {}
                for i = #msgs, 1, -1 do ordered[#ordered + 1] = msgs[i] end
                last_seen_ts = msgs[1].created_at
                pcall(cache.storeMessages, cache, room_id, ordered)
                for _, msg in ipairs(ordered) do
                    pcall(on_message, msg)
                end
                -- Reset backoff on success
                self._poll_fail_count = 0
                self._poll_interval = 10
            else
                -- Empty result (no new messages) is also success
                self._poll_fail_count = 0
                self._poll_interval = 10
            end

            if not self._poll_stopped then
                UIManager:scheduleIn(self._poll_interval, poll_fn)
            end
        end)
    end

    self._poll_fn = poll_fn
    UIManager:scheduleIn(0.1, poll_fn)
end

function Sync:stopRoom()
    self._polling = false
    self._active_room = nil
    self._poll_stopped = false
    self._poll_fail_count = 0
    self._poll_interval = 10
    if self._poll_fn then
        local ok, UIManager = pcall(require, "ui/uimanager")
        if ok then UIManager:unschedule(self._poll_fn) end
        self._poll_fn = nil
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Outbox flushing
-- ─────────────────────────────────────────────────────────────────────────────

-- Drain the outbox FIFO by sending each pending message to Supabase.
-- Called by tomo.lua on onNetworkConnected and periodically during a session.
-- Non-blocking: each send is async; flush continues to the next item on success.
-- After 3 retries, a message is marked failed; after 24h, it expires automatically.
function Sync:flushOutbox()
    if self._flushing then return end  -- Prevent concurrent flushes.
    self._flushing = true

    local api   = self.api
    local cache = self.cache

    local function processNext()
        local items = cache:peekOutbox(1)
        if not items or #items == 0 then
            self._flushing = false
            return
        end

        local item = items[1]

        -- Ink messages need the file uploaded first, then the message created.
        if item.kind == "ink" and item.ink_path then
            local room_id = item.room_id
            local msg_id  = tostring(item.id)
            local storage_path = room_id .. "/" .. msg_id .. ".png"

            api:uploadInkImage(item.ink_path, storage_path, function(upload_err, storage_key)
                if upload_err then
                    if item.retry_count >= 2 then
                        cache:markFailed(item.id)
                    else
                        cache:markRetry(item.id)
                    end
                    self._flushing = false
                    return
                end

                api:sendInkMessage(room_id, storage_key, item.device_ts, function(send_err, _)
                    if send_err then
                        if item.retry_count >= 2 then
                            cache:markFailed(item.id)
                        else
                            cache:markRetry(item.id)
                        end
                    else
                        cache:markSent(item.id)
                        -- Remove the local ink file after successful upload.
                        if item.ink_path then os.remove(item.ink_path) end
                    end
                    processNext()
                end)
            end)
        else
            -- Text message: send directly.
            api:sendMessage(item.room_id, item.body, item.device_ts, function(err, _)
                if err then
                    if item.retry_count >= 2 then
                        cache:markFailed(item.id)
                    else
                        cache:markRetry(item.id)
                    end
                else
                    cache:markSent(item.id)
                end
                processNext()
            end)
        end
    end

    processNext()
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Presence sync
-- ─────────────────────────────────────────────────────────────────────────────

-- Push the current book's presence to Supabase.
-- Called when library.lua detects a book change, and on reconnect.
function Sync:syncPresence(user_id, book)
    if not book then return end
    self.api:updatePresence(user_id, book, function() end)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Unread check (home screen, no Realtime)
-- ─────────────────────────────────────────────────────────────────────────────

-- Fetch unread state for a list of room IDs.
-- callback({ [room_id] = true/false })
function Sync:checkUnread(user_id, room_ids, callback)
    self.api:checkUnread(user_id, room_ids, function(err, unread_map)
        if err then
            callback({})
        else
            callback(unread_map or {})
        end
    end)
end

return Sync
