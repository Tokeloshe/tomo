-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- main.lua
-- KOReader plugin entry point for Tomo™ v2.7.0.
-- Registers the plugin, handles lifecycle, shows splash -- home.

local WidgetContainer = require("ui/widget/container/widgetcontainer")
local UIManager       = require("ui/uimanager")
local _               = require("gettext")

local Tomo = WidgetContainer:extend{
    name        = "tomo",
    is_doc_only = false,
    tomo_version = "2.7.0",
}

-- ─────────────────────────────────────────────────────────────────────────────
-- KOReader plugin lifecycle
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:init()
    self.ui.menu:registerToMainMenu(self)

    -- Crash-loop detection: if Tomo launched >3 times in <30 seconds each,
    -- enter safe mode (skip all network) to break infinite crash-upload cycles.
    self._safe_mode = false
    pcall(function()
        local ok_ls, LuaSettings = pcall(require, "luasettings")
        local ok_ds, DataStorage = pcall(require, "datastorage")
        if ok_ls and ok_ds then
            local settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
            local last_launch = settings:readSetting("last_launch_time") or 0
            local rapid_count = settings:readSetting("rapid_launch_count") or 0
            local now = os.time()
            if (now - last_launch) < 30 then
                rapid_count = rapid_count + 1
            else
                rapid_count = 0
            end
            settings:saveSetting("last_launch_time", now)
            settings:saveSetting("rapid_launch_count", rapid_count)
            settings:flush()

            if rapid_count > 3 then
                self._safe_mode = true
                local lg = require("logger")
                lg.warn("Tomo: crash-loop detected (" .. rapid_count
                    .. " rapid launches), entering safe mode")
            end
        end
    end)

    -- Main init wrapped in pcall so Tomo never crashes KOReader
    local TomoState = require("tomo")
    local ok, err = pcall(TomoState.init, self._safe_mode)
    if ok then
        self._state = TomoState
    else
        self._init_error = tostring(err)
        local lg = require("logger")
        lg.warn("Tomo: FATAL init error: " .. self._init_error)
        pcall(function()
            local ok_ds, DataStorage = pcall(require, "datastorage")
            local dir = ok_ds and DataStorage:getDataDir() or "."
            local f = io.open(dir .. "/tomo_init_error.log", "a")
            if f then
                f:write(os.date() .. " | " .. tostring(err) .. "\n")
                f:close()
            end
        end)
        -- Do NOT re-throw. KOReader continues without Tomo.
        return
    end

    -- Schedule crash-loop counter reset after 5 minutes of stable running
    if self._safe_mode then
        UIManager:scheduleIn(300, function()
            pcall(function()
                local LS = require("luasettings")
                local DS = require("datastorage")
                local s = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                s:saveSetting("rapid_launch_count", 0)
                s:flush()
                local lg = require("logger")
                lg.warn("Tomo: stable for 5 min, reset crash-loop counter")
            end)
        end)
    end

    -- AUTO TEST: open Tomo automatically when TOMO_AUTO_TEST=1 (emulator only)
    if os.getenv("TOMO_AUTO_TEST") == "1" then
        self._auto_test = true
        UIManager:scheduleIn(3, function()
            local ok, err = pcall(function()
                if not self then return end
                local lg = require("logger")
                lg.warn("TAPTEST: Auto-launching Tomo home screen...")
                self:_showHomeScreen()
            end)
            if not ok then
                local lg = require("logger")
                lg.warn("Tomo: scheduled auto-test error: " .. tostring(err))
            end
        end)
    end
end

function Tomo:addToMainMenu(menu_items)
    menu_items.tomo = {
        text         = _("Tomo™"),
        sorting_hint = "tools",
        callback     = function()
            self:_showHomeScreen()
        end,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Network events
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:onNetworkConnected()
    if self._state then
        self._state:onNetworkConnected()
    end
    return true
end

function Tomo:onNetworkDisconnected()
    if self._state then
        self._state:onNetworkDisconnected()
    end
    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Device lifecycle events
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:onResume()
    if self._state then
        self._state:onResume()
    end
    return true
end

function Tomo:onSuspend()
    if self._state then
        self._state:onSuspend()
    end
    return true
end

function Tomo:onCloseWidget()
    if self._state then
        self._state.teardown()
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Entry point
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:_showHomeScreen()
    if self._init_error then
        local InfoMessage = require("ui/widget/infomessage")
        UIManager:show(InfoMessage:new{
            text = "Tomo failed to start:\n" .. self._init_error,
        })
        return
    end
    if not self._state then
        local InfoMessage = require("ui/widget/infomessage")
        UIManager:show(InfoMessage:new{
            text = "Tomo is not initialized.",
        })
        return
    end

    local ok_splash, splash_err = pcall(function()
        self:_showSplash()
    end)
    if not ok_splash then
        self:_openHome()
    end
end

-- Splash screen: centered 友 character, "tomo" below, sekki greeting.
-- Holds for 1.5 seconds, then transitions to the home screen.
function Tomo:_showSplash()
    local Screen            = require("device").screen
    local FrameContainer    = require("ui/widget/container/framecontainer")
    local CenterContainer   = require("ui/widget/container/centercontainer")
    local VerticalGroup     = require("ui/widget/verticalgroup")
    local TextWidget        = require("ui/widget/textwidget")
    local VerticalSpan      = require("ui/widget/verticalspan")
    local Blitbuffer        = require("ffi/blitbuffer")
    local Theme             = require("ui/theme")
    local Seasons           = require("core/seasons")
    local InputContainer    = require("ui/widget/container/inputcontainer")

    local dimen = Screen:getSize()
    local device_profile = require("core/device").getProfile()
    local bg = Theme.pageBg(device_profile,
        self._state.state.season and self._state.state.season.season)
        or Blitbuffer.COLOR_WHITE

    local greeting = Seasons.greeting()

    local splash_content = VerticalGroup:new{
        align = "center",
        TextWidget:new{
            text = "友",
            face = Theme.face(48),
            bold = true,
        },
        VerticalSpan:new{ width = Theme.space.md },
        TextWidget:new{
            text = "tomo",
            face = Theme.face(Theme.font.size.title),
            fgcolor = Theme.blitColor(Theme.color.text_secondary),
        },
        VerticalSpan:new{ width = Theme.space.xl },
        TextWidget:new{
            text    = greeting,
            face    = Theme.face(Theme.font.size.whisper),
            fgcolor = Theme.blitColor(Theme.color.text_whisper),
        },
    }

    -- Use :new (not :extend) so self[1] is set on the INSTANCE, not on a
    -- subclass table. Otherwise KOReader's InputContainer:handleEvent does
    -- ipairs(self) and sees nil because numeric keys on the class are not
    -- visible through the instance metatable.
    local splash = InputContainer:new{
        name  = "tomo_splash",
        dimen = dimen,
    }
    splash[1] = FrameContainer:new{
        width      = dimen.w,
        height     = dimen.h,
        bordersize = 0,
        padding    = 0,
        background = bg,
        CenterContainer:new{
            dimen = dimen,
            splash_content,
        },
    }

    UIManager:show(splash)
    UIManager:setDirty(splash, "full")

    UIManager:scheduleIn(1.5, function()
        local ok, err = pcall(function()
            if splash then
                UIManager:close(splash)
            end
            UIManager:setDirty(nil, "full")
            self:_openHome()
        end)
        if not ok then
            local lg = require("logger")
            lg.warn("Tomo: splash transition error: " .. tostring(err))
        end
    end)
end

function Tomo:_openHome()
    local ok, err = pcall(function()
        -- Check if onboarding is needed
        local ok_ls, LuaSettings = pcall(require, "luasettings")
        local ok_ds, DataStorage = pcall(require, "datastorage")
        if ok_ls and ok_ds then
            local tomo_settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
            if not tomo_settings:isTrue("onboarding_complete") then
                local ScreenOnboarding = require("ui/screen_onboarding")
                UIManager:show(ScreenOnboarding:new{
                    tomo     = self._state,
                    settings = tomo_settings,
                    on_complete = function()
                        -- After onboarding, show the home screen
                        local ScreenHome = require("ui/screen_home")
                        UIManager:show(ScreenHome:new{ tomo = self._state })
                    end,
                })
                return
            end
        end

        -- OTA version check (non-blocking -- shows dialog if update available)
        local ok_upd, Updater = pcall(require, "core/updater")
        if ok_upd then
            pcall(Updater.checkForUpdate, self.tomo_version, function()
                UIManager:close(self)
            end)
        end

        -- First-launch notice for this version (shown once)
        if ok_ls and ok_ds then
            local tomo_settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/tomo.lua")
            if not tomo_settings:isTrue("notice_2_7_0") then
                tomo_settings:saveSetting("notice_2_7_0", true)
                tomo_settings:flush()
                local ScreenNotice = require("ui/screen_notice")
                UIManager:show(ScreenNotice:new{
                    title = "Welcome to Tomo v2.7.0",
                    body = "Bug fixes and improved stability.\n\nFixed update failures on all devices.\nImproved crash reporting accuracy.\nBetter support for Kindle and other\ne-readers.",
                })
            end
        end

        local ScreenHome = require("ui/screen_home")
        local home = ScreenHome:new{ tomo = self._state }
        UIManager:show(home)

        -- AUTO TEST: run tap tests after home screen renders
        if self._auto_test then
            UIManager:scheduleIn(1, function()
                local test_ok, test_err = pcall(function()
                    local TapTest = require("tests/tap_test")
                    TapTest.run(self._state)
                end)
                if not test_ok then
                    local logger = require("logger")
                    logger.warn("TAPTEST: FAILED TO LOAD: " .. tostring(test_err))
                end
            end)
        end
    end)
    if not ok then
        local InfoMessage = require("ui/widget/infomessage")
        UIManager:show(InfoMessage:new{
            text = "Tomo home screen error:\n" .. tostring(err),
        })
    end
end

return Tomo
