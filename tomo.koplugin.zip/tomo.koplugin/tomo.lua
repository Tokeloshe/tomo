-- (c) 2026 James Edward Honiball. All Rights Reserved.
-- Tomo (友) -- Social Reading Companion for Kobo

-- tomo.lua
-- The state orchestrator. All mutable session state lives here.
-- Every other module reads from and writes to this central state table.
-- No other module holds its own mutable session state.
--
-- Responsibilities:
--   - Hold the config (Supabase URL/key, tuning constants)
--   - Hold the session state (user, rooms, current book, season, online flag)
--   - Wire together: Library → presence → API → Cache → UI
--   - Handle network connect/disconnect events
--   - Handle device resume/suspend events
--   - Drive the outbox flush cycle

local Tomo = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Configuration
-- All tunable constants are here. No hardcoded values elsewhere.
-- Supabase credentials are baked in permanently.
-- ─────────────────────────────────────────────────────────────────────────────

Tomo.config = {
    -- Supabase project credentials (baked in permanently).
    supabase_url = "https://flelpiioaeaxwtgfqboa.supabase.co",
    supabase_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZsZWxwaWlvYWVheHd0Z2ZxYm9hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM4NzQ4OTksImV4cCI6MjA4OTQ1MDg5OX0.a_6m4gcYce2aeV7O0NgFTumE4jcGC3qkJDTgUZ-FRU0",

    -- Room blooming threshold: number of readers with the same ISBN needed
    -- for a book room to appear. The Supabase trigger enforces this server-side;
    -- this client-side value is used for UI messaging only.
    book_room_threshold = 2,

    -- Message pagination: number of messages fetched per page.
    message_page_size = 20,

    -- Reader Bridge: minimum minutes between overlay appearances.
    bridge_cooldown_min = 60,

    -- Pen pal delivery delay window (hours).
    penpal_delay_min_h = 6,
    penpal_delay_max_h = 18,

    -- Age (days) after which ink images are removed from Supabase Storage.
    ink_expiry_days = 365,

    -- Outbox: hours before a pending message is marked failed.
    outbox_max_age_h = 24,
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Session state
-- All fields start nil/false/empty. Populated by init().
-- ─────────────────────────────────────────────────────────────────────────────

Tomo.state = {
    user         = nil,    -- Current user record { id, username, haiku_bio, stylus_user }
    rooms        = {},     -- Active rooms the user has joined: array of room tables
    active_room  = nil,    -- Room ID currently open in screen_room, or nil
    current_book = nil,    -- From KoboReader.sqlite: { title, author, isbn, progress_pct }
    season       = nil,    -- Current sekki table from seasons.lua
    online       = false,  -- True when Supabase is reachable
    has_failed_messages = false,  -- True if any outbox entries are in 'failed' state
    penpal_partner_name = nil,   -- Cached pen pal partner username (nil = no match)
    postcrossing_stats  = nil,   -- { sent = N, received = N } or nil
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Module references (populated by init())
-- ─────────────────────────────────────────────────────────────────────────────

Tomo._cache    = nil  -- Cache instance
Tomo._api      = nil  -- Api instance
Tomo._sync     = nil  -- Sync instance
Tomo._lib_watcher = nil  -- Library.watchForChange handle

-- ─────────────────────────────────────────────────────────────────────────────
-- Initialisation
-- ─────────────────────────────────────────────────────────────────────────────

-- Full plugin initialisation. Called from main.lua on plugin load.
-- 1. Open cache DB
-- 2. Authenticate
-- 3. Load user state
-- 4. Start library watcher
-- 5. Check network and sync if online
function Tomo.init(safe_mode)
    Tomo._safe_mode = safe_mode or false

    -- Start session recorder
    local Recorder = require("core/recorder")
    Recorder.start()
    Tomo._recorder = Recorder

    if safe_mode then
        Recorder.log("LAUNCH", "SAFE MODE -- network operations disabled")
    end

    -- Season is always available (no network required).
    Tomo.state.season = require("core/seasons").current()
    Recorder.log("LAUNCH", "Season: " .. (Tomo.state.season and Tomo.state.season.kanji or "?"))

    -- Open the local cache database.
    local Cache = require("core/cache")
    local cache = Cache.new()
    local ok, err = cache:open()
    if not ok then
        -- Cache failure is non-fatal: the plugin degrades to read-only/offline.
        -- Log the error to KOReader's logger rather than crashing.
        local logger = require("logger")
        logger.warn("Tomo: cache open failed: " .. tostring(err))
    end
    Tomo._cache = cache

    -- Expire any stale outbox messages from a previous session.
    cache:expireStaleOutbox(Tomo.config.outbox_max_age_h)

    -- Check if there are failed messages to surface on the home screen.
    local failed = cache:getFailedMessages()
    Tomo.state.has_failed_messages = #failed > 0

    local Auth = require("core/auth")
    local logger = require("logger")
    local jwt, user_id

    if Tomo._safe_mode then
        -- Safe mode: use cached credentials only, no network
        Recorder.log("AUTH", "Safe mode, using cached credentials")
        jwt = Auth.loadToken(cache)
        user_id = Auth.loadUserId(cache)
    else
        Recorder.log("AUTH", "Starting authentication")
        jwt, user_id = Auth.ensureAuthenticated(Tomo.config, cache)
        Recorder.log("AUTH", "Result: jwt=" .. tostring(jwt and "yes" or "no")
            .. " user_id=" .. tostring(user_id and user_id:sub(1,12) or "nil"))
    end

    -- Validate: if auth failed, user_id is an error string, not a UUID.
    -- A valid Supabase UUID is 36 chars with hyphens (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
    if user_id and (not user_id:match("^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$")) then
        logger.warn("Tomo: auth returned invalid user_id (error string), treating as nil: " .. tostring(user_id))
        user_id = nil
    end

    -- Build API and Sync instances.
    local Api  = require("core/api")
    local Sync = require("core/sync")
    local api  = Api.new(Tomo.config, jwt, user_id)

    -- Update last_seen on every session launch (once, pcall-wrapped)
    if user_id and not Tomo._safe_mode then
        pcall(function()
            api:_request("PATCH",
                "/rest/v1/users?id=eq." .. user_id,
                { last_seen = os.date("!%Y-%m-%dT%H:%M:%SZ") },
                { ["Prefer"] = "return=minimal" })
        end)
    end
    local sync = Sync.new(api, cache)
    Tomo._api  = api
    Tomo._sync = sync

    -- Check for and report any crashes from the previous session.
    -- Wrapped in its own pcall so the crash reporter itself cannot crash init.
    if not Tomo._safe_mode then
        local ok_cr, CrashReporter = pcall(require, "core/crash_reporter")
        if ok_cr then
            local ok_report, report_err = pcall(function()
                local device_profile = require("core/device").getProfile()
                CrashReporter.checkAndReport(api, device_profile, "2.7.0", user_id, Tomo)
            end)
            if not ok_report then
                local lg = require("logger")
                lg.warn("Tomo: crash reporter error: " .. tostring(report_err))
            end
        end
    else
        Recorder.log("LAUNCH", "Skipping crash reporter (safe mode)")
    end

    if user_id then
        -- Restore username from cache DB first, then LuaSettings as fallback.
        -- Both are outside the plugin directory and survive OTA updates.
        local cached_username = cache:getState("auth_username")
        if not cached_username then
            -- Cache DB might be empty (first launch or wiped). Check LuaSettings.
            local ok_ls2, LS2 = pcall(require, "luasettings")
            local ok_ds2, DS2 = pcall(require, "datastorage")
            if ok_ls2 and ok_ds2 then
                local ts = LS2:open(DS2:getSettingsDir() .. "/tomo.lua")
                cached_username = ts:readSetting("username")
            end
        end

        if not cached_username then
            -- Truly first launch: generate a nature-word username.
            local nature_words = {
                "brook", "cedar", "cloud", "coral", "crane", "creek", "dawn",
                "dew", "dusk", "elm", "ember", "fawn", "fern", "finch", "flame",
                "flint", "fog", "frost", "gale", "grove", "hawk", "hazel",
                "heron", "holly", "ivy", "jade", "lake", "lark", "leaf",
                "lily", "linden", "maple", "marsh", "meadow", "mist", "moon",
                "moss", "oak", "orchid", "otter", "pearl", "pine", "plum",
                "pond", "rain", "reed", "ridge", "river", "robin", "sage",
                "shore", "sky", "snow", "sparrow", "stone", "storm", "stream",
                "thistle", "thorn", "vale", "wren", "willow", "wind",
            }
            math.randomseed(os.time())
            local a = nature_words[math.random(#nature_words)]
            local b = nature_words[math.random(#nature_words)]
            local username = a .. "-" .. b

            local device_hash = Auth.deviceHash()
            local Device = require("core/device")
            local profile = Device.getProfile()
            local stylus = profile and profile.has_stylus or false

            api:createUser(user_id, username, device_hash, stylus, function(err, _data)
                if not err then
                    cache:setState("auth_username", username)
                    -- Mirror to LuaSettings
                    pcall(function()
                        local LS = require("luasettings")
                        local DS = require("datastorage")
                        local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                        ts:saveSetting("username", username)
                        ts:flush()
                    end)
                end
            end)

            Tomo.state.user = {
                id          = user_id,
                username    = username,
                stylus_user = stylus,
            }
        else
            -- Returning user: restore from cache.
            local cached_haiku = cache:getState("auth_haiku_bio")
            if not cached_haiku then
                pcall(function()
                    local LS = require("luasettings")
                    local DS = require("datastorage")
                    local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                    cached_haiku = ts:readSetting("haiku_bio")
                end)
            end
            Tomo.state.user = {
                id          = user_id,
                username    = cached_username,
                haiku_bio   = cached_haiku,
                stylus_user = false,
            }
        end
    end

    -- Start the library watcher. Fires immediately with the current book,
    -- then fires again whenever KoboReader.sqlite changes.
    -- Also try KOReader's ReaderUI API as fallback (works on Kindle).
    local Library = require("core/library")
    Tomo._lib_watcher = Library.watchForChange(function(book)
        -- If library scanner returned nil (e.g. Kindle has no KoboReader.sqlite),
        -- try reading from KOReader's document API instead.
        if not book then
            pcall(function()
                local ReaderUI = require("apps/reader/readerui")
                local instance = ReaderUI.instance
                if instance and instance.document then
                    local props = instance.document:getProps()
                    if props and props.title and props.title ~= "" then
                        book = {
                            title = props.title,
                            author = props.authors or "",
                            isbn = props.isbn or props.identifier or "",
                            progress_pct = 0,
                            book_hash = Library.computeBookHash(props.title, props.authors or ""),
                        }
                    end
                end
            end)
        end
        Tomo.state.current_book = book
        if Tomo.state.online and user_id then
            sync:syncPresence(user_id, book)
        end
    end)

    -- Check network and kick off initial sync (skip in safe mode).
    if not Tomo._safe_mode then
        local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
        if ok_nm then
            if NetworkMgr:isConnected() then
                Tomo.state.online = true
                Tomo:syncOnWake(user_id)
            end
        end
    else
        Recorder.log("LAUNCH", "Skipping network sync (safe mode)")
    end

end

-- ─────────────────────────────────────────────────────────────────────────────
-- Network event handlers
-- Registered automatically because Tomo is a WidgetContainer in the widget tree.
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:onNetworkConnected()
    self.state.online = true
    local user_id = self.state.user and self.state.user.id

    -- If we don't have a user yet (auth failed at launch due to no network),
    -- try authenticating now that network is available.
    if not user_id and self._cache then
        local Auth = require("core/auth")
        local logger = require("logger")
        local jwt, uid = Auth.ensureAuthenticated(self.config, self._cache)
        -- Validate UUID
        if uid and uid:match("^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$") then
            logger.warn("Tomo: late auth succeeded, user_id=" .. uid)
            self._api:setJWT(jwt, uid)
            user_id = uid
            self.state.user = {
                id       = uid,
                username = self._cache:getState("auth_username") or "reader",
                stylus_user = false,
            }
        end
    end

    if user_id then
        self:syncOnWake(user_id)
    end
    return true
end

function Tomo:onNetworkDisconnected()
    self.state.online = false
    -- Stop the active room poll (will resume on reconnect).
    if self._sync then
        self._sync:stopRoom()
    end
    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Device lifecycle handlers
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo:onResume()
    -- Device woke from sleep. Update season (date may have changed).
    self.state.season = require("core/seasons").current()

    local ok_nm, NetworkMgr = pcall(require, "ui/network/manager")
    if ok_nm and NetworkMgr:isConnected() then
        self.state.online = true
        local user_id = self.state.user and self.state.user.id
        if user_id then
            self:syncOnWake(user_id)
        end
    end
    return true
end

function Tomo:onSuspend()
    -- Device is about to sleep. Stop polling to conserve battery.
    if self._sync then
        self._sync:stopRoom()
    end
    -- Update last_seen before sleep
    local uid = self.state.user and self.state.user.id
    if uid and self._api then
        pcall(self._api._request, self._api, "PATCH",
            "/rest/v1/users?id=eq." .. uid,
            { last_seen = os.date("!%Y-%m-%dT%H:%M:%SZ") },
            { ["Prefer"] = "return=minimal" })
    end
    return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Sync helpers
-- ─────────────────────────────────────────────────────────────────────────────

-- Called on first connect and on every resume-with-network.
-- Flushes outbox, refreshes user profile, and loads rooms.
function Tomo:syncOnWake(user_id)
    if not user_id then return end
    -- Debounce: skip if synced within the last 10 seconds.
    local now = os.time()
    if self._last_sync_time and (now - self._last_sync_time) < 10 then return end
    self._last_sync_time = now

    -- Flush any queued outbox messages.
    self._sync:flushOutbox()

    -- Check if there's a pending profile update that failed in a previous session.
    -- If so, push the cached values TO the server before fetching FROM the server.
    -- This prevents the server's old data from overwriting the user's unsaved edit.
    local pending = self._cache:getState("pending_profile_update")
    if pending == "1" then
        local cached_name = self._cache:getState("auth_username")
        local cached_haiku = self._cache:getState("auth_haiku_bio")
        local updates = {}
        if cached_name then updates.username = cached_name end
        if cached_haiku then updates.haiku_bio = cached_haiku end
        if next(updates) then
            local logger = require("logger")
            logger.warn("Tomo: retrying pending profile update: " .. (cached_name or ""))
            self._api:updateUser(user_id, updates, function(err)
                if not err then
                    self._cache:deleteState("pending_profile_update")
                    logger.warn("Tomo: pending profile update succeeded")
                end
            end)
        end
    end

    -- Refresh the user profile from the server.
    self._api:getUser(user_id, function(err, user)
        if not err and user then
            self.state.user = user
            -- Mirror user data to BOTH cache DB and LuaSettings.
            -- Both are outside the plugin directory, surviving OTA updates.
            self._cache:setState("auth_username", user.username)
            if type(user.haiku_bio) == "string" and user.haiku_bio ~= "" then
                self._cache:setState("auth_haiku_bio", user.haiku_bio)
            end
            pcall(function()
                local LS = require("luasettings")
                local DS = require("datastorage")
                local ts = LS:open(DS:getSettingsDir() .. "/tomo.lua")
                ts:saveSetting("username", user.username)
                if type(user.haiku_bio) == "string" and user.haiku_bio ~= "" then
                    ts:saveSetting("haiku_bio", user.haiku_bio)
                end
                ts:flush()
            end)
        end
    end)

    -- Load rooms from Supabase. On success, populate state.rooms from server.
    -- On failure (e.g. RLS recursion bug returns HTTP 500), fall back to the
    -- static genre room list so the UI is never empty.
    self._api:getRooms(function(err, rooms)
        if not err and rooms and #rooms > 0 then
            self.state.rooms = {}
            for _, r in ipairs(rooms) do
                self.state.rooms[#self.state.rooms + 1] = {
                    id        = r.id,
                    name      = r.name,
                    slug      = r.slug,
                    genre_tag = r.genre_tag,
                    kind      = r.kind,
                    isbn      = r.isbn,
                    has_new   = false,
                }
            end
        elseif #self.state.rooms == 0 then
            -- Fallback: populate with static genre rooms so the UI shows something.
            -- These have no server ID, so joining/messaging won't work until the
            -- RLS fix is applied (see supabase/migrations/003_fix_rls_recursion.sql).
            local fallback_genres = {
                { name = "Fantasy & Sci-Fi",   genre_tag = "fantasy-scifi" },
                { name = "Romance",            genre_tag = "romance" },
                { name = "Literary Fiction",   genre_tag = "literary" },
                { name = "Thriller & Mystery", genre_tag = "thriller" },
                { name = "Non-Fiction",        genre_tag = "nonfiction" },
                { name = "Horror",             genre_tag = "horror" },
                { name = "Historical Fiction", genre_tag = "historical" },
                { name = "Young Adult",        genre_tag = "ya" },
            }
            for _, g in ipairs(fallback_genres) do
                self.state.rooms[#self.state.rooms + 1] = {
                    id        = nil,
                    name      = g.name,
                    slug      = "genre-" .. g.genre_tag,
                    genre_tag = g.genre_tag,
                    kind      = "genre",
                    isbn      = nil,
                    has_new   = false,
                }
            end
        end
    end)

    -- Sync current reading presence and trigger bloom check.
    if self.state.current_book then
        self._sync:syncPresence(user_id, self.state.current_book)
        -- Trigger bloom check after presence is reported
        self._api:bloomRooms(self.state.current_book, function(err)
            if not err then
                local lg = require("logger")
                lg.warn("Tomo: bloom check completed")
            end
        end)
    end

    -- Ensure all genre rooms have real server IDs.
    -- Keeps retrying every 30s until all 8 are resolved.
    self:_ensureRoomIds()
end

-- Background polling to resolve nil room IDs on fallback genre rooms.
-- Wi-Fi may connect after Tomo launches; this picks up the IDs when available.
function Tomo:_ensureRoomIds()
    -- Check if all rooms already have IDs
    local has_nil = false
    for _, r in ipairs(self.state.rooms) do
        if r.kind == "genre" and not r.id then
            has_nil = true
            break
        end
    end
    if not has_nil then return end  -- all resolved

    local UIManager = require("ui/uimanager")
    local logger = require("logger")

    -- Cancel any existing timer
    if self._room_resolve_fn then
        UIManager:unschedule(self._room_resolve_fn)
    end

    self._room_resolve_fn = function()
        self._api:getRooms(function(err, rooms)
            if not err and rooms and #rooms > 0 then
                local resolved = 0
                for _, server_room in ipairs(rooms) do
                    for _, state_room in ipairs(self.state.rooms) do
                        if state_room.genre_tag == server_room.genre_tag and not state_room.id then
                            state_room.id = server_room.id
                            resolved = resolved + 1
                        end
                    end
                end
                if resolved > 0 then
                    logger.warn("Tomo: resolved " .. resolved .. " room IDs from server")
                end
                -- Check if still unresolved
                local still_nil = false
                for _, r in ipairs(self.state.rooms) do
                    if r.kind == "genre" and not r.id then still_nil = true; break end
                end
                if still_nil then
                    UIManager:scheduleIn(30, self._room_resolve_fn)
                else
                    logger.warn("Tomo: all room IDs resolved")
                    self._room_resolve_fn = nil
                end
            else
                -- Failed, retry in 30s
                UIManager:scheduleIn(30, self._room_resolve_fn)
            end
        end)
    end

    UIManager:scheduleIn(10, self._room_resolve_fn)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Teardown
-- ─────────────────────────────────────────────────────────────────────────────

function Tomo.teardown()
    if Tomo._room_resolve_fn then
        local ok_ui, UIManager = pcall(require, "ui/uimanager")
        if ok_ui then UIManager:unschedule(Tomo._room_resolve_fn) end
        Tomo._room_resolve_fn = nil
    end
    if Tomo._lib_watcher then
        Tomo._lib_watcher:stop()
        Tomo._lib_watcher = nil
    end
    if Tomo._sync then
        Tomo._sync:stopRoom()
    end
    if Tomo._cache then
        Tomo._cache:close()
        Tomo._cache = nil
    end
    if Tomo._recorder then
        Tomo._recorder.stop()
    end
end

return Tomo
